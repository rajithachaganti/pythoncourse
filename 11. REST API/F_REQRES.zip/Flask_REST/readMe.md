1. Install libraries  
     > python -m pip install -r requirements.txt
2. To deploy the application, execute below command in command prompt
     > C:\Users\madhu\PycharmProjects\Flask_REST>python app.py

    OR 
    Directly run app.py in pycharm 
    
  