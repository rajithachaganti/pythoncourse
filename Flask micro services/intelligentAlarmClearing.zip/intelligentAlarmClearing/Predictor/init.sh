#!/usr/bin/env bash
# Maintainer : Chiara Rampini
# Author Dayanne Lopez

# Pretty print
export COM_COLOR='\033[0;34m'
export OBJ_COLOR='\033[0;36m'
export OK_COLOR='\033[0;32m'
export ERROR_COLOR='\033[0;31m'
export WARN_COLOR='\033[0;33m'
export NO_COLOR='\033[m'

if [[ -z "$CONTEXT_DB_DNS" ]]; then
    # If context DB dns is not set
    #  create ssh tunnel
    # in django_dev_iac.settings.DATABASE
    # host = localhost
    # port = local forwarded port will be used
    #-------------------------------------
    # ssh tunneling
    sshpass -p $CONTEXT_DB_SSH_PASSWORD \
    ssh -vvv -o StrictHostKeyChecking=no \
    -L $CONTEXT_DB_PG_LOCAL_PORT:127.0.0.1:$CONTEXT_DB_PG_REMOTE_PORT \
    -N -f -l $CONTEXT_DB_SSH_LOGIN $CONTEXT_DB_HOST \
    && \
    echo -e "${OK_COLOR}[OK]${NO_COLOR} Tunneling DB orchestrator \n" \
            "${COM_COLOR}[..]${NO_COLOR} Starting server \n" \
     && \
    #-------------------------------------
    # start server
    python manage.py runserver 0.0.0.0:8000 ||\
    # if tunneling or running server is not working print error
    echo -e "${ERROR_COLOR}[ERROR]${NO_COLOR} iAc Context database tunneling \n" \
            "Used parameters: \n" \
            "   CONTEXT_DB_HOST=$CONTEXT_DB_HOST \n" \
            "   CONTEXT_DB_SSH_LOGIN=$CONTEXT_DB_SSH_LOGIN \n" \
            "   CONTEXT_DB_SSH_PASSWORD=$CONTEXT_DB_SSH_PASSWORD \n" \
            "   CONTEXT_DB_PG_REMOTE_PORT=$CONTEXT_DB_PG_REMOTE_PORT \n" \
            "   CONTEXT_DB_PG_LOCAL_PORT=$CONTEXT_DB_PG_LOCAL_PORT \n" \
            "   CONTEXT_DB_PG_LOGIN=$CONTEXT_DB_PG_LOGIN \n" \
            "   CONTEXT_DB_PG_PASSWORD=$CONTEXT_DB_PG_PASSWORD \n" \
        exit 1 \

else
    # if context DB dns is set
    # use remote port, dns, and postgres identifications
    # in django_dev_iac.settings.DATABASE
    # these parameters will be loaded if ENV VAR $CONTEXT_DB_DNS exist
    # host = dns
    # post = remote Postgres port
    echo -e "${OK_COLOR}[OK]${NO_COLOR} DNS found for Context DB \n "\
            "   CONTEXT_DB_DNS=$CONTEXT_DB_DNS \n" \
            "   CONTEXT_DB_PG_REMOTE_PORT=$CONTEXT_DB_PG_REMOTE_PORT \n" \
            "   CONTEXT_DB_PG_LOGIN=$CONTEXT_DB_PG_LOGIN \n" \
            "   CONTEXT_DB_PG_PASSWORD=$CONTEXT_DB_PG_PASSWORD \n" \
            "$COM_COLOR[..]$NO_COLOR Starting server \n" \
    python manage.py runserver 0.0.0.0:8000 \
; fi
