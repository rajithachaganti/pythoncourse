#!/usr/bin/env python
import os
import sys
#!/usr/bin/env python
import logging
import logging.handlers
import os

from iac_bundles.iac_bundles.ds_tools.logs import iAC_PREDICTOR_API_MESSAGE_LOGGER_NAME, iAC_KM_API_MESSAGE_LOGGER_NAME

def init_logger(lgrname):
    if 'logs' not in os.listdir(os.getcwd()):
        os.makedirs('logs')
    LOG_FILENAME = 'logs/'+lgrname + '.log'

    #TODO ENV
    logger = logging.getLogger(lgrname)
    logger.setLevel(logging.INFO)

    # TODO ENV
    scrnLgr = logging.StreamHandler()
    scrnLgr.setLevel(logging.INFO)

    # Add the log message handler to the logger
    filehandler = logging.handlers.RotatingFileHandler(
        LOG_FILENAME, maxBytes=52428800, backupCount=5)

    formatter = logging.Formatter(
        '%(asctime)s.%(msecs)03d | %(levelname)s | %(filename)s | %(funcName)s | %(thread)d | %(message)s',
        "%d-%b-%Y %H:%M:%S")
    formatter.default_msec_format = '%s.%03d'
    scrnLgr.setFormatter(formatter)
    filehandler.setFormatter(formatter)

    logger.addHandler(scrnLgr)
    logger.addHandler(filehandler)

if __name__ == '__main__':
    init_logger(iAC_PREDICTOR_API_MESSAGE_LOGGER_NAME)
    init_logger(iAC_KM_API_MESSAGE_LOGGER_NAME)
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'django_dev_iac.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        )
    execute_from_command_line(sys.argv)
