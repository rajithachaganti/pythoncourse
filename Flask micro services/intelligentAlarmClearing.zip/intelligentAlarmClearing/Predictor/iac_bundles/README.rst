Bundles information
*******************

Used in Intelligence Alarm Clearing application

Use package **iac_bundles.common** for : helper definition

Use package **iac_bundles.exc** for : define custom Error Classes

Bundle structure

.. code-block:: shell

    .
    ├── Makefile
    ├── README.rst
    ├── iac_bundles
    │   ├── __init__.py
    │   ├── common
    │   │   ├── __init__.py
    │   │   ├── db_helpers
    │   │   ├── json_helpers
    │   │   └── regex_helpers
    │   ├── exc
    │   │   ├── __init__.py
    │   │   └── __init__.pyc
    │   └── iac_parser
    │       ├── __init__.py
    │       ├── command_router
    │       └── re_dict
    ├── setup.py
    └── tests
        ├── http_tests
        │   ├── django_test.http
        │   └── parser_api
        └── py_tests
            └── test.py


Implementation
--------------

Add a new package: append package in folder : <repo root> / iac_bundles / <new package>
Specify install requirement for new package from Pypi - Python fondation repo :

.. code-block:: python

    # in setup.py
    # Line 42
    # Specify needed Pypi package in this list
    INSTALL_AND_REQUIRED_PACKAGE = ['regex']

    setup(
        name='iac_bundles',
        packages=find_packages(),
        version=VERSION,
        description='iac bundles',
        long_description=read('README.rst'),
        author='Nokia iAC DEV Team',
        author_email='rajesh.vaddi@nokia.com',
        url='https://gitlabe1.ext.net.nokia.com/vignshan/iac_bundles.git',
        download_url='http://url.version={ver}'.format(ver=VERSION),
        keywords=['alarm clearing app package'],
        install_requires=INSTALL_AND_REQUIRED_PACKAGE,
        requires=INSTALL_AND_REQUIRED_PACKAGE,
        )


Test
----

Use <repo root> /tests/http_tests to create REQUESTS tests files.

Use <repo root> /tests/py_tests to create Python tests script files.

Tests scripts and automation : append a new target in <repo root>/Makefile.


Build and deployment
--------------------

Use this all in one command to build and deploy without tests :

.. code-block:: shell

    # Artifactory/Pypi authentication will be requested
    # to deploy package
    # rewrite in same version is not allowed
    make deploy



Setup .env
-----------

To avoid prompt password, create **.env** file in <repo root>, and fill it like:

.. code-block:: shell

    LOGIN = "NOKIA SHORT ID"
    PASSWORD = "PASSWORD"

Add new line <**.env**> in **.gitignore** to avoid **push/share** your password in Git.

Uncomment <**include .env**> on top of **Makefile** eg: line 12 .

Comment LOGIN and PASSWORD variables in **Makefile**, line 36, 37.