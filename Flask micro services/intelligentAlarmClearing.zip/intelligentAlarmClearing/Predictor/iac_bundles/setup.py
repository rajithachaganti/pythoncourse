# Author : Shangmugathas Vigneswaran
# mail : vigneswaran.shanmugathas.ext@nokia.com
# +--------------------------------------------------------------------------------+
# | Single-sourcing package version                                                |
# | from : https://packaging.python.org/guides/single-sourcing-package-version/    |
# +--------------------------------------------------------------------------------+
import codecs
import os
import re
from setuptools import setup, find_packages

here = os.path.abspath(os.path.dirname(__file__))


def read(*parts):
    # intentionally *not* adding an encoding option to open, See:
    #   https://github.com/pypa/virtualenv/issues/201#issuecomment-3145690
    with codecs.open(os.path.join(here, *parts), 'r') as fp:
        return fp.read()


def find_version(*file_paths):
    version_file = read(*file_paths)
    version_match = re.search(
            r"^__version__ = ['\"]([^'\"]*)['\"]",
            version_file,
            re.M,
            )
    if version_match:
        return version_match.group(1)

    raise RuntimeError("Unable to find version string.")


# +--------------------------------------------------------------------------------+
# | Regular packaging script                                                       |
# +--------------------------------------------------------------------------------+
EXCLUDE_FROM_PACKAGES = ['']
# Change version in ./__init__.py var __version__
VERSION = find_version('iac_bundles', '__init__.py')
# Specify needed Pypi package in this list
INSTALL_AND_REQUIRED_PACKAGE = ['regex', 'django']


setup(
        name='iac_bundles',
        packages=find_packages(),
        version=VERSION,
        description='iac bundles',
        long_description=read('README.rst'),
        author='Nokia iAC DEV Team',
        author_email='rajesh.vaddi@nokia.com',
        url='https://gitlabe1.ext.net.nokia.com/vignshan/iac_bundles.git',
        download_url='http://url.version={ver}'.format(ver=VERSION),
        keywords=['alarm clearing app package'],
        install_requires=INSTALL_AND_REQUIRED_PACKAGE,
        requires=INSTALL_AND_REQUIRED_PACKAGE,
        )

