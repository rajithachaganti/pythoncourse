import sys
import os
import unittest
sys.path.append(os.path.abspath(os.path.join(os.path.dirname('__file__'), '..', '..', '..', '..', '..', 'iac_bundles')))
from iac_bundles.common import regex_helpers


class TestSeparate(unittest.TestCase):
    """
    Test case
    """

    def test_zeei(self):
        regex_pattern = '\d{5}\s\d{5}\sBTS-\d{4}\s{2}U\s(WO|BL-BTS)'
        text = """
        ZEEI:BCF=589;


        LOADING PROGRAM VERSION 37.10-0




        FlexiBSC  MSABSC4                   2018-03-03  04:18:46
        RADIO NETWORK CONFIGURATION IN BSC:
                                                                 E P  B
                                              F                  T R  C D-CHANNEL  BUSY
                              AD OP           R  ET- BCCH/CBCH/  R E  S O&M LINK  HR  FR
         LAC   CI         HOP ST STATE  FREQ  T  PCM ERACH/      X F  U NAME  ST DHR
                                                     ECBCCH                          /GP
        ===================== == ====== ==== == ==== =========== = = == ===== == === ===

        BCF-0589  FLEXI MULTI  U WO                                   5  B589  WO
         00063 12125 BTS-0589  U WO                                                0   0
         KLE0251         RF/-                                                      0
                                                                                       5
                      TRX-001  U WO      120  0  285 MBCCH+CBCH    P  4
                      TRX-002  U WO      100  0  285                  1
                      TRX-003  U WO       88  0  285                  3
         00063 22125 BTS-0590  U WO                                                0   0
         KLE0252         RF/-                                                      0
                                                                                       5
                      TRX-005  U WO      113  0  285 MBCCH+CBCH    P  4
                      TRX-006  U WO       77  0  285                  1
         00063 32125 BTS-0591  U BL-BTS                                            0   0
         KLE0253         RF/-                                                      0
                                                                                       0
                      TRX-009  U BL-BTS  109  0  285 MBCCH+CBCH    P  3
                      TRX-011  U BL-TRX   84  0  285                  4
                      TRX-012  U BL-TRX  103  0  285                  3


        COMMAND EXECUTED


        BASE STATION CONTROLLER HANDLING COMMAND <EE_>
        """
        assert_list = ['00063 12125 BTS-0589  U WO                                                0   0\n         '
                       'KLE0251         RF/-                                                      0\n                '
                       '                                                                       5\n                   '
                       '   TRX-001  U WO      120  0  285 MBCCH+CBCH    P  4\n                      TRX-002  U WO    '
                       '  100  0  285                  1\n                      TRX-003  U WO       88  0  285       '
                       '           3\n         '
            ,

                       '00063 22125 BTS-0590  U WO                                                0   0\n         '
                       'KLE0252         RF/-                                                      0\n                '
                       '                                                                       5\n                   '
                       '   TRX-005  U WO      113  0  285 MBCCH+CBCH    P  4\n                      TRX-006  U WO    '
                       '   77  0  285                  1\n         '
            ,

                       '00063 32125 BTS-0591  U BL-BTS                                            0   0\n        '
                       'KLE0253         RF/-                                                      0\n            '
                       '                                                                       0\n                '
                       '   TRX-009  U BL-BTS  109  0  285 MBCCH+CBCH    P  3\n                      TRX-011  U '
                       'BL-TRX   84  0  285                  4\n                      TRX-012  U BL-TRX  103  0  285 '
                       '                 3\n        \n        \n        COMMAND EXECUTED\n\n\n        BASE STATION '
                       'CONTROLLER HANDLING COMMAND <EE_>\n']

        output_list = regex_helpers.separate(re_pattern=regex_pattern, input_str=text)

        for i in zip(assert_list, output_list):
            self.assertEqual(len(i[0]), len(i[1]))
            # print(len(i[0]), len(i[1]))

    # Use this part of code to export exact split element
    # for i, text in enumerate(output_list):
    #     # with open('{i}.txt'.format(i=i), "w") as text_file:
    #     #    text_file.write(i)
    #
    #     with open('{i}.txt'.format(i=i), "w") as text_file:
    #         print('{i}'.format(i=text), file=text_file)

    def test_zoel(self):
        regex_pattern = '[A-Z0-9]*\s*BCF-\d{2,5}\s*BTS-\d{2,5}\s*QUAL\s*\d{4,5}-\d{2}-\d{2}\s{2}\d{2}:\d{2}:\d{' \
                        '2}\.\d{2}'

        text = """
        <ZEOL::NR=7767;
        LOADING PROGRAM VERSION 12.2-0
    
        BTS ALARM LISTING
    
        MSABSC4        BCF-589   BTS-591     QUAL      2018-03-03  17:09:44.54
        *** ALARM                         KLE0253
           (50012) 7767 BCCH MISSING
    
        MSABSC4        BCF-1370  BTS-1373    QUAL      2018-03-02  17:10:09.42
        *** ALARM                         BELOSURMER3
           (50026) 0001 OTHER ALARM FOR TESTING
    
        MSABSC4        BCF-1810  BTS-1813    QUAL      2018-03-02  09:16:18.42
        *** ALARM                         MAINTIRANO3
           (50593) 7767 BCCH MISSING
        """

        assert_list = ['MSABSC4        BCF-589   BTS-591     QUAL      2018-03-03  17:09:44.54\n        *** ALARM     '
                       '                    KLE0253\n           (50012) 7767 BCCH MISSING\n    \n        '
            ,

                       'MSABSC4        BCF-1370  BTS-1373    QUAL      2018-03-02  17:10:09.42\n        *** ALARM     '
                       '                    BELOSURMER3\n           (50026) 0001 OTHER ALARM FOR TESTING\n    \n      '
                       '  '
            ,
                       'MSABSC4        BCF-1810  BTS-1813    QUAL      2018-03-02  09:16:18.42\n        *** '
                       'ALARM                         MAINTIRANO3\n           (50593) 7767 BCCH MISSING\n      '
                       '  ']

        output_list = regex_helpers.separate(re_pattern=regex_pattern, input_str=text)

        for i in zip(assert_list, output_list):
            self.assertEqual(len(i[0]), len(i[1]))
            # self.assertIn(i[0], i[1])


if __name__ == '__main__':
    unittest.main()
