import os
import sys
# Append iac_bundles path to this modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname('__file__'), '..', '..', '..',
                                             '..', '..', 'iac_bundles')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname('__file__'), '..', '..', '..',
                                             '..', '..', 'parser_api')))
from iac_bundles.iac_parser import zeei
from models import *


string = """
ZEEI:BCF=589;


LOADING PROGRAM VERSION 37.10-0




FlexiBSC  MSABSC4                   2018-03-03  04:18:46
RADIO NETWORK CONFIGURATION IN BSC:
                                                         E P  B
                                      F                  T R  C D-CHANNEL  BUSY
                      AD OP           R  ET- BCCH/CBCH/  R E  S O&M LINK  HR  FR
 LAC   CI         HOP ST STATE  FREQ  T  PCM ERACH/      X F  U NAME  ST DHR
                                             ECBCCH                          /GP
===================== == ====== ==== == ==== =========== = = == ===== == === ===

BCF-0589  FLEXI MULTI  U WO                                   5  B589  WO
 00063 12125 BTS-0589  U WO                                                0   0
 KLE0251         RF/-                                                      0
                                                                               5
              TRX-001  U WO      120  0  285 MBCCH+CBCH    P  4 
              TRX-002  U WO      100  0  285                  1 
              TRX-003  U WO       88  0  285                  3 
 00063 22125 BTS-0590  U WO                                                0   0
 KLE0252         RF/-                                                      0
                                                                               5
              TRX-005  U WO      113  0  285 MBCCH+CBCH    P  4 
              TRX-006  U WO       77  0  285                  1 
 00063 32125 BTS-0591  U BL-BTS                                            0   0
 KLE0253         RF/-                                                      0
                                                                               0
              TRX-009  U BL-BTS  109  0  285 MBCCH+CBCH    P  3 
              TRX-011  U BL-TRX   84  0  285                  4 
              TRX-012  U BL-TRX  103  0  285                  3 


COMMAND EXECUTED


BASE STATION CONTROLLER HANDLING COMMAND <EE_>
"""
output = zeei.main_parse(string, RegexDB, 'nokia', 'bcch missing fault')
