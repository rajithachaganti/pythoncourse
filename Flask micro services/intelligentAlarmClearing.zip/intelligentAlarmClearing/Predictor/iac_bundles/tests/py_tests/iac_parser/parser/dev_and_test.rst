Make test and dev with Django models
************************************


Enter in Django shell

.. code-block:: shell

    # python manage.py shell -i ipython


Import iac_bundles decencies and django app models ORM

.. code-block:: python

    import os
    import sys
    import regex as re
    from parser_api.models import RegexDB, RegexList
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname('__file__'), '..','..','iac_bundles')))
    from iac_bundles.iac_bundles.iac_parser import zeei_bcf, zoel_nr_7767
    from iac_bundles.iac_bundles.common import regex_helpers


Do some parsing tests

.. code-block:: python

    text = "some test"
    output = zeei_bcf.main_parser(**kwargs) # refer to docstring
