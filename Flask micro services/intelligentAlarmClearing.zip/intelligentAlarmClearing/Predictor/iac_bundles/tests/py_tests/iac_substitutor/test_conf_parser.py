# With django shell

import unittest

from iac_bundles.iac_bundles.iac_substitutor.conf_parser import get_last_command_output, parse_from_ticket, get_param

config = {
    "param0":
        {"source": "ticket",
         "key_map": ["AdditionalFields", "BTS-ID"],
         "force_integer": True
         }
}

alarm_ticket = {
    "AlarmName": "ALARM_TEST",
    "NodeVendor": "nokia",
    "AdditionalFields": {"BTS-ID": "BTS-54451"},
    "History":
        {
            "cmd_list": [
                "ZAHO:ET,549;",
                "ZYEF:ET,549;",
                "ZEQS:BTS=591:U;",
                "ZEFR:445"
            ],
            "output_list": [
                "\r\nLOADING PROGRAM VERSION 6.14-0\r\n\r\nBSC3i Allahganj 2018-07-04 13:59:47\r\n\r\nALARMS CURRENTLY "
                "ON\r\n\r\n\r\nEND OF ALARMS CURRENTLY ON\r\n\t\r\n\r\nCOMMAND EXECUTED\r\n\r\n\r\nALARM HISTORY "
                "HANDLING "
                "COMMAND <AH_>\r\n, \r\nLOADING PROGRAM VERSION 9.3-0\r\n\r\nBSC3i Allahganj 2018-07-04 "
                "\t13:59:54\r\n\r\nPCM "
                "SERVICE STATE PAGE 1\r\n\r\nET-549 PCM OK\r\n\r\n\r\nCOMMAND "
                "EXECUTED\r\n\r\n\r\n\r\nZRCI:SEA=4:ETPCM=549;\r\n\r\nBSC3i \tAllahganj 2018-07-04 "
                "14:00:33\r\n\r\nCIRCUIT( "
                "S)\r\n\r\nCGR : 11 NCGR : WBAMR ETPCM-TCPCM-TSL : 549-1-1\r\nORD : 241 CTRL : Y LSI : AINA1 HGR : "
                "1-\t241\r\nSTATE : WO-EX NET",
                "LOADING PROGRAM VERSION 36.20-0\n\n   NOTE! BTS LOCK/UNLOCK WILL TAKE MAXIMUM OF 7 "
                "MINUTES\n\n\nEXECUTION "
                "STARTED\n\n\nFlexiBSC  MSABSC4                   2018-03-03  04:19:24\n\nBTS ADMINISTRATIVE STATE "
                "CHANGED:\n=================================\n\nSEG-0591   KLE0253        \nBCF-0589   BTS-0591   "
                "KLE0253 "
                "\n-------------------------------------\nBTS ADMINISTRATIVE STATE ... LOCKED\nBTS OPERATIONAL STATE "
                "...... BL-USR\n\n\nBSC DATABASE UPDATED\n\nCOMMAND EXECUTED",
                "LOADING PROGRAM VERSION 36.20-0\n\n   NOTE! BTS LOCK\/UNLOCK WILL TAKE MAXIMUM OF 7 "
                "MINUTES\n\n\nEXECUTION "
                "STARTED\n\n\nFlexiBSC  MSABSC4                   2018-03-03  04:19:24\n\nBTS ADMINISTRATIVE STATE "
                "CHANGED:\n=================================\n\nSEG-0591   KLE0253        \nBCF-0589   BTS-0591   "
                "KLE0253 "
                "\n-------------------------------------\nBTS ADMINISTRATIVE STATE ... LOCKED\nBTS OPERATIONAL STATE "
                "...... BL-USR\n\n\nBSC DATABASE UPDATED\n\nCOMMAND EXECUTED",
                "LOADING PROGRAM VERSION 36.3-0\n\n\n\n\nFlexiBSC  NBSC6                     2018-04-01  "
                "03:26:11\nRADIO "
                "NETWORK CONFIGURATION IN BSC:\n                                                         E P  B\n "
                "F                  T R  C D-CHANNEL  BUSY\n                      AD OP           R "
                "ET- BCCH\/CBCH\/  R E  S O&M LINK  HR  FR\n LAC   CI         HOP ST STATE  FREQ  T  PCM ERACH       "
                "X F  U "
                "NAME  ST DHR\n                                                                             "
                "\/GP\n===================== == ====== ==== == ==== =========== = = == ===== == === ===\n\nBCF-0560  "
                "FLEXI "
                "MULTI  U WO                                   0  B560  WO\n 20005 51161 BTS-0561  U WO "
                "0   0\n ANALALAVA1      RF\/- "
                "0\n                                                                               4\n              "
                "TRX-001 "
                "U WO       83  0  121 MBCCH+CBCH    P  0 \n              TRX-003  U WO      116  0  122              "
                "    0 "
                "\n 20005 51162 BTS-0562  U WO                                                0   0\n ANALALAVA2      "
                "RF\/- "
                "0\n "
                "4\n              TRX-005  U WO      121  0  121 MBCCH+CBCH    P  0 \n "
                "TRX-007  U WO      984  0  122                  0 \n              TRX-008  U WO      991  0  122 "
                "0 \n 20005 51163 BTS-0563  U WO                                                0   0\n ANALALAVA3 "
                "RF\/-                                                      0\n "
                "5\n              TRX-009  U WO      119  0  121 MBCCH+CBCH    P  0 \n "
                "      TRX-012  U WO       92  0  122                  0 \n\n\nCOMMAND EXECUTED "
            ]
        }
}

last_cmd = ("LOADING PROGRAM VERSION 36.3-0\n\n\n\n\nFlexiBSC  NBSC6                     2018-04-01  "
            "03:26:11\nRADIO "
            "NETWORK CONFIGURATION IN BSC:\n                                                         E P  B\n "
            "F                  T R  C D-CHANNEL  BUSY\n                      AD OP           R "
            "ET- BCCH\/CBCH\/  R E  S O&M LINK  HR  FR\n LAC   CI         HOP ST STATE  FREQ  T  PCM ERACH       "
            "X F  U "
            "NAME  ST DHR\n                                                                             "
            "\/GP\n===================== == ====== ==== == ==== =========== = = == ===== == === ===\n\nBCF-0560  "
            "FLEXI "
            "MULTI  U WO                                   0  B560  WO\n 20005 51161 BTS-0561  U WO "
            "0   0\n ANALALAVA1      RF\/- "
            "0\n                                                                               4\n              "
            "TRX-001 "
            "U WO       83  0  121 MBCCH+CBCH    P  0 \n              TRX-003  U WO      116  0  122              "
            "    0 "
            "\n 20005 51162 BTS-0562  U WO                                                0   0\n ANALALAVA2      "
            "RF\/- "
            "0\n "
            "4\n              TRX-005  U WO      121  0  121 MBCCH+CBCH    P  0 \n "
            "TRX-007  U WO      984  0  122                  0 \n              TRX-008  U WO      991  0  122 "
            "0 \n 20005 51163 BTS-0563  U WO                                                0   0\n ANALALAVA3 "
            "RF\/-                                                      0\n "
            "5\n              TRX-009  U WO      119  0  121 MBCCH+CBCH    P  0 \n "
            "      TRX-012  U WO       92  0  122                  0 \n\n\nCOMMAND EXECUTED ")


class TestConfParser(unittest.TestCase):

    def test_sub_from_ticket(self):

        self.assertEqual(get_last_command_output(alarm_ticket),
                         last_cmd)

        self.assertEqual(parse_from_ticket(config.get('param0'), alarm_ticket),
                         54451)

        self.assertEqual(list(get_param(config, alarm_ticket)),
                         [54451])

suite = unittest.TestLoader().loadTestsFromTestCase(TestConfParser)
unittest.TextTestRunner().run(suite)