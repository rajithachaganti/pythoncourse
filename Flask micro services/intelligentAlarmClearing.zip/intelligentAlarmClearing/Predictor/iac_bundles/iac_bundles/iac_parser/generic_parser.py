# Filter command output to ensure
# that output wil start with and end,
# with this kind of output
#
#   LOADING PROGRAM
#
#   ( command output text ... )
#
#   COMMAND EXECUTED

from iac_bundles.iac_bundles.common import json_helpers, regex_helpers, db_helpers
from iac_bundles.iac_bundles import exc
from django.db.models.base import ModelBase
import regex as re
from parse import *

NOKIA_CMD_FILTER = 'LOADING\sPROGRAM[\d\s\w\.\-\:*()/&=+!]*COMMAND\sEXECUTED'
ERICSSON_CMD_FILTER = ''

ALL_FILTER = regex_helpers.make_regex_flavor(
        [NOKIA_CMD_FILTER,
         ERICSSON_CMD_FILTER]
        )


class GenericParser(object):

    def __init__(self, _command_list_model: ModelBase, _parser_db_model: ModelBase):
        """
        Construct with Django ModelBase object

        :param _command_list_model:
        :param _parser_db_model:
        """

        self.command_list_model: ModelBase = _command_list_model
        self.parser_db_model: ModelBase = _parser_db_model
        self.process_values: dict
        self.vendor_type: str
        self.alarm_text: str
        self.last_cmd: str
        self.last_cmd_pattern: str
        self.last_cmd_output: str
        self.bcf_id: str
        self.parser_format_list: list
        self.parsed_results: dict
        self.format_pattern_list: list = []
        self.process_results = None
        self.process_status: bool = False
        self.parser_output: dict = {}
        self._id: int
        self.parser_format: str

    def set_process_values(self, _input_dict: dict):
        """
        Set needed attribute from  input dict (from JSON body)
        :param _input_dict:
        :return:
        """
        # Read from JSON
        self.process_values = json_helpers.get_process_values(_input_dict)
        # Set attributes
        self.vendor_type = self.process_values.get('vendor_type')
        self.alarm_text = self.process_values.get('alarm_text')
        self.last_cmd = self.process_values.get('last_cmd')
        self.last_cmd_pattern = json_helpers.get_last_exe_cmd_pattern(self.command_list_model, self.last_cmd)
        self.last_cmd_output = self.process_values.get('last_cmd_output')
        self.bcf_id = self.process_values.get('bcf_id')

    def fetch_parser_format(self):
        """
        Fetch from database parser format pattern
        :return:
        """

        print(self.last_cmd_pattern)
        print(self.vendor_type)
        print(self.alarm_text)
        self.parser_format_list = db_helpers.get_pattern_list(self.parser_db_model,
                                                              self.vendor_type,
                                                              self.alarm_text,
                                                              self.last_cmd_pattern)
        print(self.parser_format_list)
        if not self.format_pattern_list:
            raise exc.UnableToFindPatternInDB('Can not find format pattern in db',
                                              f'used process values ={self.process_values}, '
                                              f'cmd_pattern= {self.last_cmd_pattern}')

    def filter_cmd_output(self):
        """
        Apply filter to command output to keep only :
        eg Nokia command output
            LOADING PROGRAM
            ( command output text ... )
            COMMAND EXECUTED
        :return:
        """
        self.last_cmd_output: str = re.findall(ALL_FILTER, self.last_cmd_output, re.MULTILINE)[0]

    def do_parsing(self, _input_dict: dict, _filter: bool = False):
        """
        Do parsing

        :param _input_dict:
        :param _filter:
        :return:
        """
        # Set attribute from input dict
        self.set_process_values(_input_dict)
        # Get from database format string
        self.fetch_parser_format()
        # Apply filter by default
        if _filter:
            # override self.last_cmd_output
            # by filtering command output string
            self.filter_cmd_output()

        # Try with all parser format until find named key
        for format_ in self.parser_format_list:
            # Do parsing
            parsed = parse(format_.last_cmd_output)
            # Get named keys-values
            # break if dict available
            if parsed:
                self.parser_output = parsed.named
                print(self.parser_output)
                print("-----------------@@@@@@@ [PARSER OUTPUT ] @@@@@@@@-----------------")
                print(self.parser_output)

        if self.parser_output:
            return {'parsed_dict': self.parser_output,
                    '_meta':       {'process_values': self.process_values,
                                    'parser_specs':   {
                                        'format_pattern_list':       self.format_pattern_list,
                                        'process_status':            self.process_status}
                                    }
                    }

        if not self.parser_output:
            error_details = {'_meta': {'process_values':       self.process_values,
                                       'last_exe_cmd_pattern': self.last_cmd_pattern,
                                       'parser_specs':         {
                                           'format_pattern_list': self.format_pattern_list
                                           }}}

            raise exc.GenericParserError('Error in generic parser',
                                         f'used process values ={error_details}')
