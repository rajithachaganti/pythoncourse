# Generic hard coded parser for ZOEL command
# Build custom parsing pipeline from Regex Database
from iac_bundles.iac_bundles.common import regex_helpers
from parse import *


def main_parser(_input_str: str) -> dict:
    """
    Input command output string, split, try to parse with different parser format.
    If matching -> fill in dict, used key  unique counter key in enum split_text.

    :param _input_str:
    :return:
    """

    # Create a dict to fill output key-value
    output_dict = {}

    # Text splitting regex pattern
    # split_pattern = '[A-Z0-9]{7}\s{6}BCF-\d{3,7}'
    split_pattern = '(.*)[A-Z0-9]*\s*BCF-\d*'

    # Parser def
    parser_format = """{TAG_1}      {BCF_ID}  {BTS_ID}    {TAG_2}      {}  {}
    *   ALARM  {TRX_ID}               {TAG_3}
               {TAG_4}
       ({TAG_5}) {ALARM}"""

    parser_format2 = """{TAG_1}      {BCF_ID}  {BTS_ID}    {TAG_2}      {}  {}
*   ALARM  {TRX_ID}               {TAG_3}
   ({TAG_4}) {ALARM}
                {TAG_5}"""
    # Create a list of parsers format

    parser_format3 = """LOADING PROGRAM VERSION {PROGRAM_VERSION}

BTS ALARM LISTING

           {TAG_1}        {BCF_ID}  {BTS_ID}    QUAL      {DATE}  {HOUR}
*** ALARM                         IVATOVILLE2
   ({TAG_2}) {ALARM_TEXT}                                                    {}"""

    all_format = [
        parser_format,
        parser_format2,
        parser_format3]

    # Split input string
    split_text = regex_helpers.separate(split_pattern, _input_str)

    # Iterate in sliced text
    for i, elem in enumerate(split_text):
        # iterate in parser format
        for _format in all_format:
            # do parsing
            r = parse(_format, elem)
            # if  not none
            try:
                # update  output dict
                output_dict[i] = r.named
            except Exception:
                pass
    return {'parsed_dict': output_dict}
