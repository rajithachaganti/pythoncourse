# Build custom parsing pipeline from Regex Database
from django.db.models.base import ModelBase
from iac_bundles.iac_bundles.common import db_helpers
from iac_bundles.iac_bundles.common import regex_helpers
import regex as re


def main_parse(_model: ModelBase,  _vendor_type: str, _alarm_text: str, _full_bcf_id: str, _input_str: str):
    """
    Main parser for
    :param _input_str:
    :param _model:
    :param _vendor_type:
    :param _alarm_text:
    :param _full_bcf_id:
    :return:

    ----------------------------------------------------------------
    text used for testing
    ----------------------------------------------------------------
    <ZEOL::NR=7767;
    LOADING PROGRAM VERSION 12.2-0

    BTS ALARM LISTING

    MSABSC4        BCF-589   BTS-591     QUAL      2018-03-03  17:09:44.54
    *** ALARM                         KLE0253
       (50012) 7767 BCCH MISSING

    MSABSC4        BCF-1370  BTS-1373    QUAL      2018-03-02  17:10:09.42
    *** ALARM                         BELOSURMER3
       (50026) 0001 OTHER ALARM FOR TESTING

    MSABSC4        BCF-1810  BTS-1813    QUAL      2018-03-02  09:16:18.42
    *** ALARM                         MAINTIRANO3
       (50593) 7767 BCCH MISSING

    ----------------------------------------------------------------
    usage
    ----------------------------------------------------------------

    In [62]: parse(test_str, RegexDB, 'nokia', 'bcch missing fault', 'ZOEL::NR=7767;', 'BCF-589')
    Out[62]: True

    In [63]: parse(test_str, RegexDB, 'nokia', 'bcch missing fault', 'ZOEL::NR=7767;', 'BCF-1370')
    Out[63]: False
'
    In [63]: parse(test_str, RegexDB, 'nokia', 'bcch missing fault', 'ZOEL::NR=7767;', 'BCF-1810')
    Out[63]: True


    """

    # Collecting all needed regex pattern from database
    split_pattern = db_helpers.get_regex(_model, _vendor_type, _alarm_text,
                                         'ZOEL::NR=7767;', 'ALARM_SPLIT')
    alarm_detection_pattern = db_helpers.get_regex(_model, _vendor_type, _alarm_text,
                                                   'ZOEL::NR=7767;', 'ALARM_DETECTION')

    print('Parsing pipeline details ------------------')
    print('Split pattern = {pat}'.format(pat=split_pattern))
    print('Alarm detection pattern = {pat}'.format(pat=alarm_detection_pattern))
    print('[END] Parsing pipeline details ------------------')

    # Process to text split
    split_text = regex_helpers.separate(split_pattern, _input_str)

    # Iterate on split text
    for i in split_text:
        # Check if exist in this element
        if re.search(pattern=_full_bcf_id, string=i) and \
                re.search(pattern=alarm_detection_pattern, string=i):
            return True

    return False
