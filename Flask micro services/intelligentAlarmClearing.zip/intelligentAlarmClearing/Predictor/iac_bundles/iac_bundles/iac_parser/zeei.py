# Build custom parsing pipeline from Regex Database

from django.db.models.base import ModelBase
from iac_bundles.iac_bundles import exc
from iac_bundles.iac_bundles.common import db_helpers, regex_helpers
from parse import *
import regex as re


# def main_parse(_model: ModelBase,
#               _input_str: str, _vendor_type: str, _alarm_text: str):

def main_parser(_input_str: str):
    """
    Main parser for ZEEI:BCF=\d*; command

    To test this parser : use following command

    cd django project root

    python manage.py shell -i ipython

    import os
    import sys
    import regex as re
    from parser_api.models import RegexDB
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname('__file__'), '..','..','iac_bundles')))
    from iac_bundles.iac_bundles.iac_parser import zeei_bcf, zoel_nr_7767
    from iac_bundles.iac_bundles.common import regex_helpers

    text = "SOME COMMAND OUTPUT"
    output = zeei.main_parser(text)

    :param _input_str: str
    :return:
    """

    # +-------------------------------------------------------------------------+
    # | Collecting all needed regex patterns/parser_format from database        |
    # +-------------------------------------------------------------------------+
    # split_pattern_bts_element = db_helpers.get_regex(_model, _vendor_type, _alarm_text,
    #                                                 'ZEEI:BCF=\d*;', 'split_bts_elements')

    # split_pattern_trx_element = db_helpers.get_regex(_model, _vendor_type, _alarm_text,
    #                                                 'ZEEI:BCF=\d*;', 'split_trx_elements')

    # get_pattern_bts_full_id = db_helpers.get_regex(_model, _vendor_type, _alarm_text,
    #                                              'ZEEI:BCF=\d*;', 'get_bts_full_id')

    # get_pattern_trx_full_id = db_helpers.get_regex(_model, _vendor_type, _alarm_text,
    # 'ZEEI:BCF=\d*;', 'get_trx_full_id')

    # trx_parser_1 = db_helpers.get_regex(_model, _vendor_type, _alarm_text,
    #                                   'ZEEI:BCF=\d*;', 'parse_trx_elements_1')

    # trx_parser_2 = db_helpers.get_regex(_model, _vendor_type, _alarm_text,
    #                                    'ZEEI:BCF=\d*;', 'parse_trx_elements_2')

    # trx_parser_3 = db_helpers.get_regex(_model, _vendor_type, _alarm_text,
    #                                    'ZEEI:BCF=\d*;', 'parse_trx_elements_3')

    split_pattern_bts_element = r'\d{4,6}\s\d{4,6}\sBTS-\d{2,6}'
    split_pattern_trx_element = r'TRX(.*)'
    get_pattern_bts_full_id = r'BTS-\d*'
    get_pattern_trx_full_id = r'TRX-\d*'
    get_pattern_bts_op_state = r'(?:BTS-\d*\s*\w\s*)(WO|BL-BTS|BL-TRX|BL-RSL|BL-BCF)'

    trx_parser_1 = '{TRX_ID}  {AD_ST} {OP_STATE}   {FREQ}  {FRT}  {ET_PCM} {BCCH_CBCH_ERACH_ECBCCH}    {PREF}  {BCSU}'
    trx_parser_2 = '{TRX_ID}  {AD_ST} {OP_STATE}  {FREQ}  {FRT}  {ET_PCM}                  {BCSU}'
    trx_parser_3 = '{TRX_ID}  {AD_ST} {OP_STATE}   {FREQ}  {FRT} {ET_PCM} {BCCH_CBCH_ERACH_ECBCCH}    {PREF}  {BCSU}'
    trx_parser_4 = '{TRX_ID}  {AD_ST} {OP_STATE}  {FREQ}  {FRT} {ET_PCM}                  {BCSU}'

    # Create list of parser format to try all of them
    trx_parser_list = [
        trx_parser_1,
        trx_parser_2,
        trx_parser_3,
        trx_parser_4
        ]

    # +----------------------------------------------------------+
    # | Print to debug                                           |
    # +----------------------------------------------------------+
    print('[START] Parsing pipeline details ------------------')
    print('Pattern bts element listing = {pat}'.format(pat=split_pattern_bts_element))
    print('Pattern trx element listing = {pat}'.format(pat=split_pattern_trx_element))
    print('Pattern full bts id = {pat}'.format(pat=get_pattern_bts_full_id))
    print('Pattern full trx id = {pat}'.format(pat=get_pattern_trx_full_id))
    print('Pattern (parser format 1) trx details = {pat}'.format(pat=trx_parser_1))
    print('Pattern (parser format 2) trx details = {pat}'.format(pat=trx_parser_2))
    print('Pattern (parser format 3) trx details = {pat}'.format(pat=trx_parser_3))
    print('[END] Parsing pipeline details ------------------')

    # +----------------------------------------------------------+
    # | Process parsing                                          |
    # +----------------------------------------------------------+
    # Create a dict to contain all parsed key-value
    parsed_dict = {}
    # Create a list contain nested trx list
    output_trx_elements = []
    # Process to text split = bts element
    split_bts_elements = regex_helpers.separate(split_pattern_bts_element, _input_str)
    # Iterate on split text
    for i, bts_elem in enumerate(split_bts_elements):
        # Get BTS-ID
        bts_id = regex_helpers.get_re_group_match(get_pattern_bts_full_id, bts_elem)[0]
        # Create empty dict with BTS-ID key value
        parsed_dict[bts_id] = {}
        parsed_dict[bts_id] = {'OP_STATE': re.findall(get_pattern_bts_op_state,
                                                      bts_elem)[0]
                               }

        # Split TRX element on this BTS-ID
        split_trx_elements = regex_helpers.get_re_group_match(split_pattern_trx_element, bts_elem)
        # Iterate on split text
        for j, trx_elem in enumerate(split_trx_elements):
            output_trx_elements.append(trx_elem)
            # Get TRX-ID
            trx_id = regex_helpers.get_re_group_match(get_pattern_trx_full_id, trx_elem)[0]
            # Try to parse with all format
            for trx_parser in trx_parser_list:
                # Parse TRX elements
                trx_parsed_dict = parse(trx_parser, trx_elem)
                # If parser is outputting something
                if trx_parsed_dict:
                    # Create key with this TRX ID and append parsed element
                    parsed_dict[bts_id][trx_id] = trx_parsed_dict.named
    # +----------------------------------------------------------+
    # | Process to checking and return values                    |
    # +----------------------------------------------------------+
    if parsed_dict and split_bts_elements and split_trx_elements:
        print('[OK] Parsing finished without error')
        return {
            'parsed_dict': parsed_dict,
            '_meta':       {
                'split_bts_elements': split_bts_elements,
                'split_trx_elements': output_trx_elements,
                'parser_formats':     {'trx_parser_1': trx_parser_1,
                                       'trx_parser_2': trx_parser_2,
                                       'trx_parser_3': trx_parser_3,
                                       'trx_parser_4': trx_parser_4
                                       }
                }
            }
    else:
        raise exc.ParserError('Error in parser', 'Please check parser step from output dictionary')

