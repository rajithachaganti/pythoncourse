# Filter command output to ensure
# that output wil start with and end,
# with this kind of output
#
#   LOADING PROGRAM
#
#   ( command output text ... )
#
#   COMMAND EXECUTED

import regex as re
from django.db.models.base import ModelBase
from parse import *

from iac_bundles.iac_bundles import exc
from iac_bundles.iac_bundles.common import json_helpers, regex_helpers
from iac_bundles.iac_bundles.iac_parser.generic_parser import GenericParser
from iac_bundles.iac_bundles.iac_parser import zeol_generic, zeei

struct = {
    'parsed': {
        'complex': {
            'alarm_detection': None,
            'threshold':       {
                'key1': 'value1'
                }
            },
        'generic': {
            'key1': 'value1'  # parsed generic_parser.Process()
            }

        }

    }
# Define command output filter
# /\ Don't grouped regex constructor in filter /\
NOKIA_CMD_FILTER = 'LOADING\sPROGRAM[\d\s\w\.\-\:*()/&=+!]*COMMAND\sEXECUTED'
ERICSSON_CMD_FILTER = ''
# Create or condition  with all of filters
ALL_FILTER = regex_helpers.make_regex_flavor([NOKIA_CMD_FILTER,
                                              ERICSSON_CMD_FILTER]
                                             )


class ParserHandler:
    """
    Main class to handle parsing process.
    Check if complex command or not. Use specific parser
        Constructor:
            - class Generic Parser
            - class django ModelBase CommandList from parser_api.models
            - class django ModelBase ParserDB from parser_api.models

        Main method : do_parsing(input_dic) ->
    """

    def __init__(self, _command_list_model: ModelBase, _complex_command_list_model: ModelBase,
                 _parser_db_model: ModelBase):
        # Instantiate generic parser = call for no complex alarm
        self.command_list_model: ModelBase = _command_list_model
        self.complex_command_list_model: ModelBase = _complex_command_list_model
        self.generic_parser: GenericParser = GenericParser(_command_list_model, _parser_db_model)
        self.complex_command_list: list
        self.process_values: dict
        self.vendor_type: str
        self.alarm_text: str
        self.last_cmd: str
        self.last_cmd_pattern: str
        self.last_cmd_output: str
        self.bts_id: str
        self.parsed_results: dict
        self.is_generic: bool = False
        self.is_historic_empty: bool = False

    def set_process_values(self, _input_dict: dict):
        """
        Set needed attribute from  input dict (from JSON body)
        :param _input_dict:
        :return:
        """
        # Read from JSON
        self.process_values = json_helpers.get_process_values(_input_dict)
        # Set attributes
        self.vendor_type = self.process_values.get('vendor_type')
        self.alarm_text = self.process_values.get('alarm_text')
        self.last_cmd = self.process_values.get('last_cmd')
        self.last_cmd_output = self.process_values.get('last_cmd_output')
        self.bts_id = self.process_values.get('bts_id')
        # Do pattern finding helper there is something in history key
        if self.last_cmd or self.last_cmd_output == 'no_history':
            self.last_cmd_pattern = None
        else:
            self.last_cmd_pattern = json_helpers.get_last_exe_cmd_pattern(self.command_list_model, self.last_cmd)

    def filter_cmd_output(self):
        """
        Apply filter to command output to keep only :
        eg Nokia command output
            LOADING PROGRAM
            ( command output text ... )
            COMMAND EXECUTED
        :return:
        """
        self.last_cmd_output: str = re.findall(ALL_FILTER, self.last_cmd_output, re.MULTILINE)[0]

    def fetch_complex_cmds_list(self):
        """
        Fetch complex alarm listing from ComplexCommandList table
        :return:
        """
        # Reset self.complex_command_list
        self.complex_command_list: list = []
        # Update self.complex_command_list from db
        for i in self.complex_command_list_model.objects.all():
            self.complex_command_list.append(i.name.name)

    def do_parsing(self, _input_dict: dict, _filter: bool = False):
        """
        Main method to do parsing:
            - use generic method if command is not a complex one
            - call complex_parser_handler() to handle complex

        :param _input_dict:
        :param _filter:
        :return:
        """
        # Set process values
        self.set_process_values(_input_dict)
        # Fetch complex alarm list from database
        self.fetch_complex_cmds_list()

        # Handle no History key inside json
        # if self.last_cmd or self.last_cmd_output == 'no_history':
        #    return None

        # If command output filter is activated
        if _filter:
            self.filter_cmd_output()

        # Check if last_cmd_pattern is not a complex one
        if self.last_cmd_pattern not in self.complex_command_list:
            self.is_generic = True
            # Call generic_parser
            self.parsed_results = self.generic_parser.do_parsing(_input_dict, _filter)
            # Return method called result
            return self.parsed_results
        else:
            self.is_generic = False
            return self.complex_parser_handler(_input_dict)

    def complex_parser_handler(self, _input_dict: dict):
        """
        Complex command router -
        :param _input_dict:
        :return:
        """
        if self.last_cmd_pattern in ['ZEEI:BCF=\d*;']:
            # Call ZEEI parser
            self.parsed_results = zeei.main_parser(self.last_cmd_output)
            return self.parsed_results

        elif self.last_cmd_pattern in ['ZEOL::NR=7767;']:
            self.parsed_results = zeol_generic.main_parser(self.last_cmd_output)
            return self.parsed_results

        else:
            # check if in complex database
            print(self.last_cmd_pattern)
            print(self.last_cmd)
            print(f'Is generic {self.is_generic}')

            raise exc.UnknownComplexCommand('This complex is not yet handled by ParserHandler',
                                            'need implementation')
