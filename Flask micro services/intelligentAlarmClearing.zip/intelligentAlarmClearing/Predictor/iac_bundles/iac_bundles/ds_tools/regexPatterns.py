import re

def RobotUID_pattern():
    pattern = re.compile(r"[0-9A-Z]{8}-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{12}")
    return pattern

def splitting_pattern_list():
    zaho_type_pattern = re.compile(r"([<]{1,}[ ]*Z[ACDEFJORUWYZ]{1}[a-zA-Z]{2}[:;., a-zA-Z0-9=\r]*[\n])")
    allip_like_pattern = re.compile(
        r"(\n[<>]{1}[a-zA-Z0-9\"= ,.!_;^:\|\-\r]{1,}\n)")
    splitting_pattern_list = [zaho_type_pattern, allip_like_pattern]
    return splitting_pattern_list


def zaho_like_splitting_pattern():
    pattern = re.compile(r"([<]{1,}[ ]*Z[ACDEFJORUWYZ]{1}[a-zA-Z]{2}[:;., a-zA-Z0-9=\r]*[\n])")
    #pattern2 = re.compile("[<]{1,}[ ]*(Z[ACDEFJORUWYZ]{1}[a-zA-Z]{2})")
    return pattern


def allip_like_splitting_pattern():
    pattern = re.compile(
        r"(\n[<>]{1}[a-zA-Z0-9\"= ,.!_;^:\|\-\r]{1,}\n)")  # |[A-Za-z]*>[a-zA-Z0-9\"= ,.!_;^:\|\-\r]{1,}\n)")
    #pattern2 = re.compile("\n[<>]{1}[ ]*([a-zA-Z ]*)[0-9\"=,.!_;^:\|\-]*[a-zA-Z0-9\"= ,.!_;^:\|\-\r]*\n")
    return pattern


def extract_base_cmd_pattern():
    pattern = re.compile(r"\n[<>]{1}[ ]*([a-zA-Z ]*)[0-9\"=,.!_;^:\|\-]*[a-zA-Z0-9\"= ,.!_;^:\|\-\r]*\n")
    return pattern


def cmd_togeneric_pattern():
    pattern = re.compile(r"([=\"]+)[0-9A-Za-z._-]+($|[\"<>:, =.;]+)|([\"<>:,=. _]+)[0-9.]+($|[\"<>:, =.; _$]+)")
    #pattern = re.compile(r"([<>:,=. ]+)[0-9]+($|[<>:, =.; ]+)")#added spaces
    return pattern







