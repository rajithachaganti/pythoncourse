import pysolr
import json
import requests
import pandas as pd
import re



# TO DO:
# Add check on solr schema if a field already exists but has not the right parameters
# Check all the status for request responses


def split_df(df, chunk_size):
    df_list = list()
    number_chunks = len(df) // chunk_size + 1
    for i in range(number_chunks):
        df_list.append(df[i * chunk_size:(i + 1) * chunk_size])
    return df_list


def jaccard_based_score(str1, str2):
    print("JACCARD BASED SIMILARITY SCORE CALCULATION")
    list1 = set(str1.split(' '))
    str1 = re.sub('newline', '', str1)
    str2 = re.sub('newline', '', str2)
    list1 = set(re.split(r'[\s]+', str1))
    #print(list1)
    list2 = set(str2.split(' '))
    list2 = set(re.split(r'[\s]+', str2))
    #print(list2)
    inter = len(list(list1.intersection(list2)))
    # print(list(list1.intersection(list2)))
    union = len(list1) + len(list2) - inter
    # print(len(list1) + len(list2) - inter)
    return round((float(inter) / union), 2) * 100


def word_sim(str1, str2):
    print("WORD SIMILARITY SCORE CALCULATION")
    str1 = re.sub('newline', '', str1)
    str2 = re.sub('newline', '', str2)
    word_list4 = set(re.split(r'[\s]+', str1))
    word_list3 = set(re.split(r'[\s]+', str2))
    #print(word_list4)
    #print(word_list3)
    word_list3_copy = word_list3.copy()
    inter_word_list = []
    # intersection of words
    for i in word_list4:
        if i in word_list3_copy:
            word_list3_copy.remove(i)
            inter_word_list.append(i)
    word_inter = len(inter_word_list)
    word_union = len(word_list3) + len(word_list4) - word_inter
    # get similarity on words of non matching tokens
    words_sim = round((float(word_inter) / word_union), 2) * 100
    return words_sim


def jaccard_based_score2(text_to_compare, str2):
    print("JACCARD2 BASED SIMILARITY SCORE CALCULATION")
    #print(str2)
    #print(jaccard_based_score(str1, str2))
    #print(word_sim(text_to_compare, str2))
    # generate tokens using newlien and spaces
    list1 = re.split("[\s]*newline[\s]*", text_to_compare)
    list1 = [i for i in list1 if i != '']
    #print("list1", list1)
    list2 = re.split("[\s]*newline[\s]*", str2)
    list2 = [i for i in list2 if i != '']
    list2_copy = list2.copy()
    #print("list2", list2)
    inter_list = []
    # create intersection comparing each token (repeating token are considered multiple times)
    for i in list1:
        if i in list2_copy:
            list2_copy.remove(i)
            inter_list.append(i)
    # get intersection and union length
    inter = len(inter_list)
    #print(inter)
    #print(len(list1))
    #print(len(list2))
    union = len(list1) + len(list2) - inter
    print(union)
    # calculate similarity on tokens
    if union != 0:
        tokens_sim = round((float(inter) / union), 2) * 100
        print(tokens_sim)
        if tokens_sim < 100:
            # generate a list of words of non matching tokens (tokens of list1 which are not in the intersection list)
            list3 = [i for i in list1 if i not in inter_list]
            #print('list3', list3)
            word_list3 = re.split(r'[\s]+', " ".join(list3))
            word_list3_copy = word_list3.copy()
            #print('w3', word_list3)
            # generate a list of words of non matching tokens (tokens of list2 which are not in the intersection list)
            list4 = [i for i in list2_copy if i not in inter_list]
            #print('list4', list4)
            word_list4 = re.split(r'[\s]+', " ".join(list4))
            #print('w4', word_list4)
            inter_word_list = []
            # intersection of words
            for i in word_list4:
                if i in word_list3_copy:
                    word_list3_copy.remove(i)
                    inter_word_list.append(i)
            word_inter = len(inter_word_list)
            word_union = len(word_list3) + len(word_list4) - word_inter
            # get similarity on words of non matching tokens
            words_sim = round((float(word_inter) / word_union), 2) * (100 - tokens_sim)
            #print([i for i in list3 if i not in inter_word_list])
            return tokens_sim + words_sim
        else:
            return tokens_sim
    else:
        tokens_sim = 0
        return tokens_sim


#str1 = "loading program version <num>.<num> <num> newline newlinebts alarm listing newline newline node bcf <num> bts <num> qual <num> <num> <num> <num> <num> <num>.<num> newline alarm mbs<num> newline <num> <num> bcch missing newline newline newline <nodename> bcf <num> bts <num> qual <num> <num> <num> <num> <num> <num>.<num> newline alarm mbs<num> newline <num> <num> bcch missing newline newline newline newlineend of bts alarm listing newline newlinecommand executed newline newlinebase transceiver station alarms handling command <eo > newline<"
#str2 = "loading program version <num>.<num> <num> newline newlinebts alarm listing newline newline <nodename> bcf <num> bts <num> qual <num> <num> <num> <num> <num> <num>.<num> newline alarm mbs<num> newline <num> <num> bcch missing newline newline newline <nodename> bcf <num> bts <num> qual <num> <num> <num> <num> <num> <num>.<num> newline alarm mbs<num> newline <num> <num> bcch missing newline newline newline newlineend of bts alarm listing newline newlinecommand executed newline newlinebase transceiver station alarms handling command <eo > newline<"
#print(jaccard_based_score2(str1, str2))


class SolrInstance:

    def __init__(self, conf_path):
        with open(conf_path) as f:
            data = json.load(f)
        self.host = data['SOLR']['HOST']
        self.port = data['SOLR']['PORT']
        self.core = data['SOLR']['CORE']
        # self.core = "iac_demo_core"
        self.chunk_size = data['SOLR']['CHUNK_SIZE']
        self.ava = data['SOLR']['AVA']

    def get_basic_url(self):
        if self.ava:
            return 'https://' + self.host + '/solr'
        else:
            return 'https://' + self.host + ':' + str(self.port) + '/solr'

    def create_core(self, core_name):
        request_http1 = self.get_basic_url() + '/admin/cores?action=STATUS&core=' + core_name
        print(request_http1)
        response1 = requests.get(request_http1)
        # if core does not exist raise create request
        print(response1.json())
        if not response1.json()['status'][core_name]:
            request_http2 = self.get_basic_url() + '/admin/cores?action=CREATE&name=' + core_name + '&instanceDir=' + core_name + '&configSet=_default'
            response2 = requests.get(request_http2)
            print(response2.json())
            # if core creation doesn't go well fatal error
            if response2.json()['responseHeader']['status'] != 0:
                # raise fatal error
                return 'fatal error: core not created'
            return 0
        return 0

    def get_core_url(self):
        return self.get_basic_url() + '/' + self.core

    def connect(self):
        return pysolr.Solr(self.get_core_url() + '/', timeout=20)

    def index_data(self, json_data):
        self.connect().add(json_data)
        self.reload_core()

    def close_connection(self):
        self.connect().get_session().close()

    def reload_core(self):
        request_http = self.get_basic_url() + '/admin/cores?action=RELOAD&core=' + self.core
        return requests.get(request_http)

    def delete_all_docs(self):
        headers = {'Content-type': 'text/xml'}
        url = self.get_core_url() + '/update'
        querystring = {"commit": "true"}
        payload = "<delete><query>*:*</query></delete>"
        requests.request("POST", url, data=payload, headers=headers, params=querystring)

    def get_field_information(self, field_name):
        request_http = self.get_core_url() + '/schema/fields?fl=' + field_name
        response = requests.get(request_http)
        return response.json()

    def check_field_existence(self, field_name):
        field_json = self.get_field_information(field_name)
        if len(field_json['fields']) == 1:
            return True
        return False

    def add_string_field(self, field_name):
        if not self.check_field_existence(field_name):
            print("adding field request")
            headers = {'Content-type': 'application/json'}
            data1 = {"add-field": {"name": field_name, "type": "string", "stored": "true", "indexed": "true"}}
            data = json.dumps(data1)
            requests.post(self.get_core_url() + '/schema', headers=headers, data=data)

    def delete_field(self, field_name):
        headers = {'Content-type': 'application/json'}
        data1 = {"delete-field": {"name": field_name}}
        data = json.dumps(data1)
        requests.post(self.get_core_url() + '/schema', headers=headers, data=data)

    def index_df(self, df):
        # split data frame into batches to avoid indexing too many data at a time
        for df_batch in split_df(df, self.chunk_size):
            print(len(df_batch))
            if len(df_batch) > 0:
                data_to_index = df_batch.to_dict(orient='records')
                j = json.dumps(data_to_index)
                j = json.loads(j)
                self.index_data(j)

    def check_allow_stream_property(self):
        # to activate possibility of using schema api
        request_http = self.get_core_url() + '/config/overlay'
        response = requests.get(request_http)
        conf = response.json()
        # try:
        # conf['overlay']['props']['requestDispatcher']['requestParsers']['enableStreamBody']
        # conf['overlay']['props']['requestDispatcher']['requestParsers']['enableRemoteStreaming']
        headers = {'Content-type': 'application/json'}
        data1 = {"set-property": {"requestDispatcher.requestParsers.enableRemoteStreaming": "true"},
                 "set-property": {"requestDispatcher.requestParsers.enableStreamBody": "true"}}
        data = json.dumps(data1)
        print(data)
        requests.post('http://' + self.host + '/api/cores/' + self.core + '/config', headers=headers, data=data)
        self.reload_core()

    def add_iac_copy_text_field(self):
        add_field_type = {"add-copy-field": {
                "source": "generic_output",
                "dest": "generic_output_solr_text"}
        }
        headers = {'Content-type': 'application/json'}
        data1 = add_field_type
        data = json.dumps(data1)
        print(data)
        requests.post(self.get_core_url() + '/schema', headers=headers, data=data)

    def add_iac_text_field(self):
        splitting_pattern = "[\s]*newline[\s]*"  # "[\n,\s+]"
        add_field_type = {"add-field-type": {
            "name": "IacOutputText",
            "class": "solr.TextField",
            "autoGeneratePhraseQueries": "false",
            "indexAnalyzer": {
                "tokenizer": {"class": "solr.SimplePatternSplitTokenizerFactory", "pattern": splitting_pattern}},
            "queryAnalyzer": {
                "tokenizer": {"class": "solr.SimplePatternSplitTokenizerFactory", "pattern": splitting_pattern}}
        },
            "add-copy-field": {
                "source": "generic_output",
                "dest": "generic_output_solr_text"}
        }
        headers = {'Content-type': 'application/json'}
        data1 = add_field_type
        data = json.dumps(data1)
        print(data)
        requests.post(self.get_core_url() + '/schema', headers=headers, data=data)

    def replace_iac_text_field(self):
        splitting_pattern = "[\s]*newline[\s]*"  # [\s\n]*[\n]+[\s\n]*
        add_field_type = {"replace-field-type": {
            "name": "IacOutputText",
            "class": "solr.TextField",
            "autoGeneratePhraseQueries": "false",
            "similarity": {"class": "solr.TFIDFSimilarityFactory"},
            "indexAnalyzer": {"tokenizer": {"class": "solr.PatternTokenizerFactory", "pattern": splitting_pattern},
                              "filter": {"class": "solr.LowerCaseFilterFactory"}},
            "queryAnalyzer": {"tokenizer": {"class": "solr.PatternTokenizerFactory", "pattern": splitting_pattern},
                              "filter": {"class": "solr.LowerCaseFilterFactory"}}
        }}
        headers = {'Content-type': 'application/json'}
        data1 = add_field_type
        data = json.dumps(data1)
        print(data)
        requests.post(self.get_core_url() + '/schema', headers=headers, data=data)

    def check_update_default_schema(self, solr_schema):
        # this function check if the fields in solr default schema config file are all present in the Solr schema
        # if one of the field is not present in the Solr schema it is created
        with open(solr_schema) as f:
            d = json.load(f)
        for j in d['SOLR']['SOLR_FIELDS'].keys():
            dataj = d['SOLR']['SOLR_FIELDS'][j]
            for name in dataj['field_names']:
                print(name)
                if not self.check_field_existence(name):
                    print(name)
                    add_field = {"add-field": {"name": name}}
                    for param in dataj['params'].keys():
                        add_field["add-field"][param] = dataj['params'][param]
                    # add field if not found in schema
                    headers = {'Content-type': 'application/json'}
                    data1 = add_field
                    data = json.dumps(data1)
                    print(data)
                    requests.post(self.get_core_url() + '/schema', headers=headers, data=data)

    def solr_query(self, query, filter_list):
        # filter_query = select_query + '&fq=' + field_list[i] + ':' + value_list[i]
        # self.get_core_url() + '''/ select?q = *:*''' + filter_query + '&fl=mmloutput'
        return pd.DataFrame(self.connect().search(query, fq=filter_list, fl="score", rows=1).docs)

    def check_scenario_exists(self, solr_filter_field_list, dic, seq_num, sequence_str, generic_output,
                              scenario_resolution_summary_string, rulesresults_seq):
        solr_filter_field_list.append('alarmname:' + "\"" + dic["alarmname"] + "\"")
        solr_filter_field_list.append('nodevendor:' + "\"" + dic["nodevendor"] + "\"")
        solr_filter_field_list.append('customer:' + "\"" + dic["customer"] + "\"")
        solr_filter_field_list.append('nodetype:' + "\"" + dic["nodetype"] + "\"")
        solr_filter_field_list.append('seq_num:' + str(seq_num))
        solr_filter_field_list.append('rulesresults_seq:\"' + rulesresults_seq + '\"')
        # solr_filter_field_list.append('scenario_len:[' + str(seq_num + 1) + ' TO *]')
        solr_filter_field_list.append('sequence_str:' + "\"" + sequence_str + "\"")
        solr_filter_field_list.append(
            'scenario_resolution_summary_string:' + "\"" + scenario_resolution_summary_string + "\"")
        # solr_filter_field_list.append('set_generic_output:' + "\"" + set_generic_output+"\"")
        solr_filter_field_list.append('generic_output:' + "\"" + generic_output + "\"")
        solr_filter_field_list = set(solr_filter_field_list)
        print(solr_filter_field_list)
        query_q = '*:*'
        q = self.connect().search(query_q, fq=solr_filter_field_list, fl="iactoken, score, next_cmd")
        print(len(q.docs))
        if len(q.docs) >= 1:  # we got at least one result from solr
            return True
        else:
            return False

    def query_first_cmd(self, alarm_session):
        # solr_filter_field_list = alarm_session.get_solr_filter_field_list()
        solr_filter_field_list = []
        solr_filter_field_list.append('nodevendor:' + "\"" + alarm_session.get_nodevendor() + "\"")
        solr_filter_field_list.append('alarmname:\"' + str(alarm_session.get_alarmname()) + "\"")
        solr_filter_field_list.append('seq_num:1')
        field = alarm_session.get_first_cmd_search_field()
        print(field)
        params = dict()
        params['facet'] = 'on'
        params['facet.field'] = field
        params['facet.mincount'] = 1
        # get the first generic command of the incoming alarm
        # query Solr to get the distinct value of the first command along with their count
        # filter on the alarm_text to get only values belonging to that alarm
        # filter on seq_num = 1 to get returned only the first command
        print(solr_filter_field_list)
        try:
            print('try')
            q = self.connect().search('*:*', fq=solr_filter_field_list,
                                      fl="scenario_resolution_summary_list, resolutionstatus", **params)
            q_list = q.facets['facet_fields'][field]
            print(q_list)
            if len(q_list) > 0:  # we got at least one command from solr
                if len(q_list) > 2:  # we got more than one command
                    return 1
                    # if q_list[1] != q_list[3]:
                    #    first_cmd = q_list[0]
                    #    return first_cmd
                    # return "None" if the first two distinct commands have the same value of counts (= ambiguous result)
                else:
                    if q.docs[0]['scenario_resolution_summary_list'][-1] == q_list[0]:
                        resolution_summary = q_list[0]
                        resolution_status = q.docs[0]['resolutionstatus']
                        return {"alarmResolutionStatus": resolution_status,
                                "alarmResolutionSummary": resolution_summary}
                    else:
                        first_cmd = q_list[0]
                        return first_cmd
            else:
                # if no command is returned by solr
                return 2
        except Exception as e:
            print(str(e))
            return 2

    def query_next_cmd(self, alarm_session, seq_num, sequence_str, generic_output, set_generic_output):
        field = alarm_session.get_next_cmd_search_field()
        solr_filter_field_list = alarm_session.get_solr_filter_field_list()
        solr_filter_field_list.append('alarmname:' + "\"" + alarm_session.get_alarmname() + "\"")
        solr_filter_field_list.append('nodevendor:' + "\"" + alarm_session.get_nodevendor() + "\"")
        solr_filter_field_list.append('customer:' + "\"" + alarm_session.get_customer() + "\"")
        solr_filter_field_list.append('nodetype:' + "\"" + alarm_session.get_nodetype() + "\"")
        solr_filter_field_list.append('seq_num:' + str(seq_num))
        solr_filter_field_list.append('scenario_len:[' + str(seq_num + 1) + ' TO *]')
        solr_filter_field_list.append('sequence_str:' + "\"" + sequence_str + "\"")
        # solr_filter_field_list.append('set_generic_output:' + "\"" + set_generic_output+"\"")
        solr_filter_field_list.append('generic_output:' + "\"" + generic_output + "\"")
        params = dict()
        params['facet'] = 'on'
        params['facet.field'] = field
        params['facet.mincount'] = 1
        print(solr_filter_field_list)
        q = self.connect().search('*:*', fq=solr_filter_field_list,
                                  fl="scenario_resolution_summary_list, resolutionstatus", **params)
        # q = self.connect().search('*:*', fq=solr_filter_field_list, fl='next_cmd')
        # return pd.DataFrame(q.docs)
        q_list = q.facets['facet_fields'][field]
        print(q_list)
        if len(q_list) > 0:  # we got at least one command from solr
            if len(q_list) > 2:  # we got more than one command
                return 1
            else:
                if q.docs[0]['scenario_resolution_summary_list'][-1] == q_list[0]:
                    resolution_summary = q_list[0]
                    resolution_status = q.docs[0]['resolutionstatus']
                    return {"alarmResolutionStatus": resolution_status, "alarmResolutionSummary": resolution_summary}
                else:
                    next_cmd = q_list[0]
                    return next_cmd
        else:
            # if no command is returned by solr
            return 2

    def query_next_cmd_score(self, alarm_session, seq_num, sequence_str, generic_output, set_generic_output):
        field = alarm_session.get_next_cmd_search_field()
        solr_filter_field_list = alarm_session.get_solr_filter_field_list()
        solr_filter_field_list.append('alarmname:' + "\"" + alarm_session.get_alarmname() + "\"")
        solr_filter_field_list.append('nodevendor:' + "\"" + alarm_session.get_nodevendor() + "\"")
        solr_filter_field_list.append('customer:' + "\"" + alarm_session.get_customer() + "\"")
        solr_filter_field_list.append('nodetype:' + "\"" + alarm_session.get_nodetype() + "\"")
        solr_filter_field_list.append('seq_num:' + str(seq_num))
        solr_filter_field_list.append('scenario_len:[' + str(seq_num + 1) + ' TO *]')
        solr_filter_field_list.append('sequence_str:' + "\"" + sequence_str + "\"")
        # solr_filter_field_list.append('set_generic_output:' + "\"" + set_generic_output+"\"")
        solr_filter_field_list.append('generic_output:' + "\"" + generic_output + "\"")
        solr_filter_field_list = set(solr_filter_field_list)
        print(generic_output)
        params = dict()
        params['facet'] = 'on'
        params['facet.field'] = field
        params['facet.mincount'] = 1
        print(solr_filter_field_list)
        query_q = '*:*'
        q = self.connect().search(query_q, fq=solr_filter_field_list,
                                  fl="scenario_resolution_summary_list, resolutionstatus, score, generic_output, next_cmd",
                                  **params)
        # q = self.connect().search('*:*', fq=solr_filter_field_list, fl='next_cmd')
        # return pd.DataFrame(q.docs)
        q_list = q.facets['facet_fields'][field]
        if len(q_list) > 0:  # we got at least one command from solr
            if len(q_list) > 2:  # we got more than one command
                print("###############################")
                print(q_list)
                return 1, {"commands": q_list[0::2], "occurrences": q_list[1::2], "score": 100}
            else:
                # we got only one command
                # check if we are suggesting a resolution summary or only a command
                print('generic_ouput:', generic_output)
                if q.docs[0]['scenario_resolution_summary_list'][-1] == q_list[0]:
                    resolution_summary = q_list[0]
                    resolution_status = q.docs[0]['resolutionstatus']
                    return {"alarmResolutionStatus": resolution_status,
                            "alarmResolutionSummary": resolution_summary}, 100
                else:
                    next_cmd = q_list[0]
                    return next_cmd, 100
        else:
            # if no command is returned by solr with 100% matching then search for similar docs
            print("FREE SEARCH")
            query_q = 'generic_output:' + generic_output
            params = dict()
            params['df'] = 'generic_output'
            # solr_filter_field_list.remove('nodevendor:' + "\"" + alarm_session.get_nodevendor() + "\"")
            solr_filter_field_list.remove('generic_output:' + "\"" + generic_output + "\"")
            solr_filter_field_list.remove('customer:' + "\"" + alarm_session.get_customer() + "\"")
            solr_filter_field_list.remove('nodetype:' + "\"" + alarm_session.get_nodetype() + "\"")
            print(solr_filter_field_list)
            q = self.connect().search(query_q, fq=solr_filter_field_list,
                                      fl="scenario_resolution_summary_list, resolutionstatus, score, generic_output, next_cmd",
                                      **params)
            if q.docs:
                res = pd.DataFrame(q.docs)
                print(res)
                res['sim_score'] = res.generic_output.apply(lambda x: jaccard_based_score2(generic_output, x))
                print(res)
                solr_score = round(res['score'][0], 2)
                sim_score = jaccard_based_score2(generic_output, res['generic_output'][0])
                sim_score2 = word_sim(generic_output, res['generic_output'][0])
                sim_dict = {"similarityUI": sim_score2,
                            "solr_score": solr_score,
                            "jaccard_based_sim": sim_score,
                            "word_matching_sim": sim_score2}
                if res['scenario_resolution_summary_list'][0][-1] == res['next_cmd'][0]:
                    resolution_summary = res['next_cmd'][0]
                    resolution_status = res['resolutionstatus'][0]
                    return {"alarmResolutionStatus": resolution_status,
                            "alarmResolutionSummary": resolution_summary}, sim_dict
                else:
                    next_cmd = res['next_cmd'][0]
                    return next_cmd, sim_dict
            else:
                return 2, -1
