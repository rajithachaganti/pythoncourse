get_first_cmd_search_field
class alarmSession:

    def __init__(self, request):
        self.first_cmd_search_field = 'generic_cmd'
        self.next_cmd_search_field = 'next_cmd'
        input_json = request
        if "SimilarityThreshold" in request.keys():
            self.similarityThreshold = input_json['SimilarityThreshold']
        else:
            self.similarityThreshold = None
        # Parse JSON session id
        self.iactoken = input_json['iACToken']
        # Initialize response json
        self.debug = None
        self.traceback = None
        self.alarmResolutionSummary = None
        self.alarmResolutionStatus = None
        self.algorithmResponseInfo = None
        self.rules = []
        self.rulesResults = []
        self.mmlcommand = None
        self.genericOutput = None
        self.similarityScore = {"similarityUI": None}
        output_json = input_json
        output_json["PredictorOutput"] = {
            "debug": self.debug,
            "traceback": self.traceback,
            "resolutionSummary": self.alarmResolutionSummary,
            "resolutionStatus": self.alarmResolutionStatus,
            "algorithmResponseInfo": self.algorithmResponseInfo,
            "rules": self.rules,
            "rulesResults":self.rulesResults,
            "mmlCommand": self.mmlcommand,
            "similarityScore": self.similarityScore,
            "genericOutput": self.genericOutput
        }
        self.output_json = output_json
        # Parse JSON input
        self.alarmnumber = input_json['AlarmNumber']
        self.alarmname = input_json['AlarmName']
        self.additionalinfo = input_json['AdditionalInfo']
        self.additionalfields = input_json['AdditionalFields']
        self.nodeparent = input_json['NodeParent']
        self.nodename = input_json['NodeName']
        self.nodeid = input_json['NodeID']
        self.customer = input_json['Customer']
        self.eventtime = input_json['EventTime']
        self.nodevendor = input_json['NodeVendor']
        self.nodetype = input_json['NodeType']
        self.nodeversion = input_json['NodeVersion']
        self.history = input_json['History']
        if self.history:
            self.rules_seq = input_json['History']['rules_list']
            self.rulesresults_seq = " ".join(input_json['History']['rulesresults_list'])
            self.parser_list = input_json['History']['parser_list']
            self.cmd_list = input_json['History']['cmd_list']
            self.output_list = input_json['History']['output_list']
            self.output = self.output_list[-1]
        self.ParserOutput = input_json['ParserOutput']
        # generate list of field to be used for the 'fq' parameters on Solr
        solr_filter_field_list = []
        # add rules filter
        solr_filter_field_list.append('rulesresults_seq:\"'+self.rulesresults_seq+'\"')
        self.solrsearchcols = input_json['solrsearchcols']
        for col_name in self.solrsearchcols:
            solr_filter_field_list.append(col_name.lower() + ':\"' + eval("self."+col_name.lower())+"\"")
        self.solr_filter_field_list = solr_filter_field_list
        print (self.solr_filter_field_list)

    # Set methods

    def set_genericOutput(self, value):
        self.genericOutput = value
        self.output_json['PredictorOutput']['genericOutput'] = value

    def set_debug(self, debug_type, traceback_info):
        self.debug = debug_type
        self.traceback = traceback_info
        self.output_json['PredictorOutput']['debug'] = debug_type
        self.output_json['PredictorOutput']['traceback'] = traceback_info

    def set_algorithmResponseInfo(self, value):
        self.algorithmResponseInfo = value
        self.output_json['PredictorOutput']['algorithmResponseInfo'] = value

    def set_mmlcommand(self, value):
        self.mmlcommand = value
        self.output_json['PredictorOutput']['mmlCommand'] = value

    def set_rules(self, value):
        self.rules = value
        self.output_json['PredictorOutput']['rules'] = value

    def set_rulesResults(self, value):
        self.rulesResults = value
        self.output_json['PredictorOutput']['rulesResults'] = value

    def set_alarmResolutionSummary(self, summary, status):
        self.alarmResolutionSummary = summary
        self.alarmResolutionStatus = status
        self.output_json['PredictorOutput']['resolutionSummary'] = summary
        self.output_json['PredictorOutput']['resolutionStatus'] = int(status)

    def set_resolutionStatus_manual_intervention(self):
        self.output_json['PredictorOutput']['resolutionStatus'] = 8
        #self.output_json['PredictorOutput']['resolutionSummary'] = "Manual intervention"

    def set_resolutionStatus_execute_mmlcommand(self):
        self.output_json['PredictorOutput']['resolutionStatus'] = 0
        #self.output_json['PredictorOutput']['resolutionSummary'] = "Execute command"

    def set_similarity_score(self, sim_score):
        self.similarityScore["similarityUI"] = sim_score
        self.output_json['PredictorOutput']['similarityScore'] = self.similarityScore

    # Get methods

    def get_additionalfields(self):
        return self.additionalfields

    def get_mmlcommand(self):
        return self.mmlcommand

    def get_alarmname(self):
        return self.alarmname

    def get_nodename(self):
        return self.nodename

    def get_nodevendor(self):
        return self.nodevendor

    def get_nodeparent(self):
        return self.nodeparent

    def get_nodeid(self):
        return self.nodeid

    def get_customer(self):
        return self.customer

    def get_id(self):
        return self.iactoken

    def get_output_json(self):
        return self.output_json

    def get_history(self):
        return self.history

    def get_first_cmd_search_field(self):
        return self.first_cmd_search_field

    def get_next_cmd_search_field(self):
        return self.next_cmd_search_field

    def get_solr_filter_field_list(self):
        return self.solr_filter_field_list

    def get_cmd_list(self):
        return self.cmd_list

    def get_output(self):
        return self.output

    def get_nodetype(self):
        return self.nodetype

    def get_ParserOutput(self):
        return self.ParserOutput