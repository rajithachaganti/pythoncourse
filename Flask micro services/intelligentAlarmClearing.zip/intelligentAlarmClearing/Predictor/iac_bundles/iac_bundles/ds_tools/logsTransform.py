import re
from iac_bundles.iac_bundles.ds_tools.regexPatterns import splitting_pattern_list, cmd_togeneric_pattern
from iac_bundles.iac_bundles.common.regex_helpers import set_param_number
import pandas as pd


def split_logs(pattern_list, cleaned_text):
    # usplit logs text into cmd and output and store them into two separate list that are returned
    for pattern in pattern_list:
        if pattern.search(cleaned_text):
            t = re.split(pattern, "^" + cleaned_text)
            c = t[1:]
            complete_cmd = [i for i in c if re.match(pattern, i)]
            output = [i for i in c if not re.match(pattern, i)]
            if len(complete_cmd) != len(output):
                output = output + ["None"]
            if output[-1] == "":
                output = output[:-1] + ["None"]
        else:
            complete_cmd = ["None"]
            output = [cleaned_text]
    return complete_cmd, output


def get_cleaned_text(text, dict_sub):
    sub_text = text
    if dict_sub:
        for k, v in dict_sub.items():
            print(type(k),type(v))
            if v.strip():
                sub_text = re.sub(str(v), "<"+str(k)+">", sub_text)
    # retain only characters presents in the regex to avoid including special characters
    # at this stage newline char is kept because it is useful for future splitting function (split into cmd and output)
    text_to_keep = re.sub("[^a-zA-Z0-9 .,\/#&!$%\*;:{}=\-_`'~\^<>()@\[\]|\\\r\n\t\"]", " ", sub_text)
    # remove multiple spaces eventually created at the previous step
    cleaned_text = re.sub("[ ]+", " ", text_to_keep)
    return cleaned_text


def get_basic_cmd(complete_cmd_list, pattern):
    cmd = [re.search(pattern, i).group(1) if re.search(pattern, i) else i for i in complete_cmd_list]
    string_cmd = " ".join(cmd)
    num_cmd = len(cmd)
    return cmd, string_cmd, num_cmd


def get_cleaned_cmd(cmd):
    # remove "<", ">", "\n" and "\r" from the command
    # strip the string to remove spaces at the beginning and at the end of the string
    cleaned_cmd = re.sub("[<>\n\r]", "", cmd).strip()
    return cleaned_cmd


def get_generic_cmd(pattern, complete_cmd, dict_sub):
    # apply the function "get_cleaned_cmd" on the complete command before getting the generic command
    cleaned_cmd = get_cleaned_cmd(get_cleaned_text(complete_cmd, dict_sub))
    generic_cmd = cleaned_cmd
    # substitute numbers included if they are found between two chars amongst "<" ">" ":" "," "=" and "."
    if re.search(pattern, cleaned_cmd):
        if re.search(pattern, cleaned_cmd).group(1) and re.search(pattern, cleaned_cmd).group(3):
            generic_cmd = pattern.sub("\g<1><param>\g<2>", cleaned_cmd)
            generic_cmd = pattern.sub("\g<3><param>\g<4>", generic_cmd)
        elif re.search(pattern, cleaned_cmd).group(1):
            generic_cmd = pattern.sub("\g<1><param>\g<2>", cleaned_cmd)
        elif re.search(pattern, cleaned_cmd).group(3):
            generic_cmd = pattern.sub("\g<3><param>\g<4>", cleaned_cmd)
    else:
        generic_cmd = cleaned_cmd
    generic_cmd = set_param_number(generic_cmd)
    return generic_cmd


print(get_generic_cmd(cmd_togeneric_pattern(),'afpls -ls BILLING |findstr -i failed',{}))
print(get_generic_cmd(cmd_togeneric_pattern(),'ZEOL::NR=7602;',{}))
print(get_generic_cmd(cmd_togeneric_pattern(),'ipac_traceroute -z 10.3.129.131 -d 10.16.6.35 -c 10',{}))
print(get_generic_cmd(cmd_togeneric_pattern(),'ihpri:ipport=IP-2-2,rip="10.76.154.37";',{}))
print(get_generic_cmd(cmd_togeneric_pattern(),'get IpAccessHostGpb=MAIN-6_172.25.58.130_172.25.58.162',{}))
print(get_generic_cmd(cmd_togeneric_pattern(),'ZEFR:1660;',{}))
print(get_generic_cmd(cmd_togeneric_pattern(),'ZEFR:180;',{}))


def get_generic_output(output, cmd, dict_sub):
    splits = output.split(cmd)
    if len(splits)>1:
        output = "".join(splits[1:])
    # replace all digits with "<num>"
    output = get_cleaned_text(output, dict_sub)
    output = re.sub(r"[0-9]+", "<num>", output).strip()
    output = re.sub(r"[^a-zA-Z<>.\n]", " ", output).strip()
    # replace all newline char with " "
    generic_output = re.sub(r"[\r]+", " ", output).strip()
    # remove multiple spaces eventually created at the previous step
    generic_output_nomultiple_spaces = re.sub("[ ]+", " ", generic_output).strip()
    generic_output_newline = re.sub("\n+", "newline", generic_output_nomultiple_spaces).strip()
    return generic_output_newline.lower()


print (get_generic_output("\r\n/*** EXCESSIVE INPUT DELAY ***/\r\n\r\nEND OF DIALOGUE SESSION\r\n\b\nConnection closed by foreign host.\r\r\n[ribhcsaa@vm10 ~]$ ZEEI:BCF=40;\r\n-bash: ZEEI:BCF=40: command not found\r\n[ribhcsaa@vm10 ~]$ \r\n[ribhcsaa@vm10 ~]$ ", "ZEEI:BCF=40;",{}))


# function to generate dataset from contextDB data
def generate_dataset_context_db(df, cmd_col_name, output_col_name):
    # obtain generic command column from command column
    # d['a'] = d.apply(lambda x: re.sub(x.b, "*", x.a) if x.b else x.a, axis=1)
    dict_sub = {}
    df['generic_cmd'] = df.apply(lambda x: get_generic_cmd(cmd_togeneric_pattern(), x[cmd_col_name], {}), axis=1)
    #df['generic_output'] = df[output_col_name].apply(lambda x: get_generic_output(x, dict_sub))
    print (df.columns)
    df['generic_output'] = df.apply(lambda x: get_generic_output(x[output_col_name], x[cmd_col_name],
                                                                 x.additionalfields.update(
                                                                 {"nodename":x.nodename,
                                                                  "nodeid":x.nodeid,
                                                                  "nodeparent":x.nodeparent})), axis=1)
    print(df)
    df['set_generic_output'] = df['generic_output'].apply(lambda x: '\n'.join(sorted(set(x.split('\n')))))
    # scenario_list = list(df[['generic_cmd', 'iactoken']].groupby('iactoken').agg(lambda x: list(x))['generic_cmd'])[0]
    # scenario_string = " ".join(scenario_list)
    # df['scenario_list'] = [scenario_list]*(df.shape[0])
    # df['scenario_string'] = scenario_string
    mmlcmd_series = df[[cmd_col_name, 'iactoken']].groupby('iactoken').agg(lambda x: list(x))[cmd_col_name]
    print(mmlcmd_series)
    df['mmlcommand_list'] = df['iactoken'].apply(lambda x: mmlcmd_series[x])
    df['mmlcommand_resolution_summary_list'] = df['mmlcommand_list'] + df['resolutionsummary'].apply(lambda x: [x])
    df['next_mmlcommand'] = df.apply(lambda row: row.mmlcommand_resolution_summary_list[row.seq_num], axis=1)
    cmd_series = df[['generic_cmd', 'iactoken']].groupby('iactoken').agg(lambda x: list(x))['generic_cmd']
    df['scenario_list'] = df['iactoken'].apply(lambda x: cmd_series[x])
    df['scenario_string'] = df['scenario_list'].apply(lambda x: ' '.join(x))
    df['sequence_str'] = df.apply(lambda row: ' '.join(row.scenario_list[:row.seq_num]), axis=1)
    df['scenario_resolution_summary_list'] = df['scenario_list'] + df['resolutionsummary'].apply(lambda x: [x])
    df['scenario_resolution_summary_string'] = df['scenario_resolution_summary_list'].apply(lambda x: " ".join(x))
    df['next_cmd'] = df.apply(lambda row: row.scenario_resolution_summary_list[row.seq_num], axis=1)
    df['scenario_len'] = df['scenario_resolution_summary_list'].apply(lambda x: len(x))
    return df


# Function used only for processing data read from excel files provided on S3
def generate_dataset_s3(dataset):
    # Clean logs body text and add it as new column
    dict_sub = {}
    dataset['cleaned_text'] = dataset['logs_body'].apply(lambda x: get_cleaned_text(x, dict_sub))
    # split logs text into cmd and output
    # save into a new column a tuple containing two lists obtained after splitting the cleaned body text into commands and outputs:
    # one list contains the commands
    # one list contains the outputs
    dataset['tuple_cmd_output'] = dataset['cleaned_text'].apply(lambda x: split_logs(splitting_pattern_list(), x))
    # extract the list of commands from the tuple and save it into a column
    dataset['complete_cmd_list'] = dataset['tuple_cmd_output'].apply(lambda x: map(lambda y: get_cleaned_cmd(y), x[0]))
    dataset['output'] = dataset['tuple_cmd_output'].apply(lambda x: x[1])
    # remove column containing the tuple of commands and output
    col_to_filter = ['tuple_cmd_output', 'eventTime']
    dataset = dataset[[i for i in dataset.columns if i not in col_to_filter]]
    # generate the scenario list and string starting from the complete_cmd_list
    dataset['scenario_list'] = dataset['complete_cmd_list'].apply(lambda x: list(map(lambda y: get_generic_cmd(cmd_togeneric_pattern(), y, {}), x)))
    dataset['scenario_string'] = dataset['scenario_list'].apply(lambda x: " ".join(x))
    # add the resolution summary to the scenario list and create a new column with its value
    dataset['scenario_resolution_summary_list'] = dataset['scenario_list'] + dataset['ResolutionSummary'].apply(
        lambda x: [x])
    dataset['scenario_len'] = dataset['scenario_resolution_summary_list'].apply(lambda x: len(x))
    # explode output list
    dataset_explosed = dataset['output'].apply(pd.Series).stack().reset_index(level=1, drop=True).to_frame('output')
    dataset = dataset.drop("output", axis=1).merge(dataset_explosed, left_index=True, right_index=True)
    # extract the list of outputs from the tuple and save it into a column after cleaning it
    dataset['generic_output'] = dataset['output'].apply(lambda x: get_generic_output(x, {}))
    dataset['set_generic_output'] = dataset['generic_output'].apply(lambda x: '\n'.join(sorted(set(x.split('\n')))))
    # calculate seq_num
    dataset["seq_num"] = dataset.groupby(['robotUID', 'scenario_len']).cumcount() + 1
    # calculate the actual command
    dataset["cmd"] = dataset.apply(lambda row: row.complete_cmd_list[row.seq_num - 1], axis=1)
    dataset["generic_cmd"] = dataset.apply(lambda row: row.scenario_list[row.seq_num - 1], axis=1)
    dataset["sequence_str"] = dataset.apply(lambda row: " ".join(row.scenario_list[:row.seq_num]), axis=1)
    # add next command column
    dataset['next_cmd'] = dataset.apply(lambda row: row.scenario_resolution_summary_list[row.seq_num], axis=1)
    return dataset
