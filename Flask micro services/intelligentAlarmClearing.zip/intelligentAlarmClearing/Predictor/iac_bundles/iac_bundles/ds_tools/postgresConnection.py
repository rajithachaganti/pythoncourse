import json
import psycopg2
import pandas as pd


class pgInstance:

    def __init__(self, conf_path):
        with open(conf_path) as f:
            data = json.load(f)
        self.host = data['POSTGRES']['HOST']
        self.port = data['POSTGRES']['PORT']
        self.user = data['POSTGRES']['USER']
        self.psw = data['POSTGRES']['PSW']
        self.database = data['POSTGRES']['DATABASE']
        self.alarm_table = data['POSTGRES']['ALARM_TABLE']['NAME']
        self.alarm_table_col = data['POSTGRES']['ALARM_TABLE']['COLUMNS']
        self.alarm_cycle_table = data['POSTGRES']['ALARM_CYCLE_TABLE']['NAME']
        self.alarm_cycle_table_col = data['POSTGRES']['ALARM_CYCLE_TABLE']['COLUMNS']
        self.alarm_info_table = data['POSTGRES']['ALARM_INFO_TABLE']['NAME']
        self.alarm_info_table_col = data['POSTGRES']['ALARM_INFO_TABLE']['COLUMNS']
        self.conn = psycopg2.connect(
            host=self.host,
            port=self.port,
            user=self.user,
            password=self.psw,
            database=self.database)
        # self.ava = data['']

    def get_connection(self):
        return self.conn

    def to_print(self):
        print(self.conn)

    def query(self, statement):
        cur = self.conn.cursor()
        cur.execute(statement)
        result = cur.fetchall()
        cur.close()
        return result

    def insert_new_alarm(self, dict):
        cur = self.conn.cursor()
        query = "INSERT INTO "+self.alarm_table+"("+",".join(self.alarm_table_col)+") VALUES ("
        for i in range(len(self.alarm_table_col)):
            query = query + "%s,"
        #for col in self.alarm_table_col:
        #    query = query + """(%"""+col+""")s,"""
        query = query[:-1] + ");"
        cur.execute(query, dict)
        cur.close()
        self.conn.commit()

    def disconnect(self):
        self.get_connection().close()

    def check_alarm_exists(self):
        return 1

    def retrieve_alarm_key_columns(self, iactoken):
        # retrieve alarm key columns for a particular iactoken
        query = '''select mandatorycols from alarmkeycolumns where iacalarmid = (select CAST(iacalarmid as int) from ''' + self.alarm_info_table + ''' where iactoken = \'''' + iactoken + '''\')'''
        res = self.query(query)[0][0]
        return res

    def retrieve_solr_search_columns(self, iactoken):
        # retrieve alarm key columns for a particular iactoken
        query = '''select solrseachcols from alarmkeycolumns where iacalarmid = (select CAST(iacalarmid as int) from ''' + self.alarm_info_table + ''' where iactoken = \'''' + iactoken + '''\')'''
        res = self.query(query)[0][0]
        return res

    def retrieve_scenarios_contextDB_old(self, iactoken, alarm_key_columns_list):
        # collect alarm information from contextDB for a particular iactoken
        # remove joining column from one of the table so that in the final join it will appear only once
        alarm_cycle_cols = [col for col in self.alarm_cycle_table_col if col != 'iactoken']
        cycle_select_col = " a."+", a.".join(alarm_cycle_cols)
        info_select_col = " b."+", b.".join(self.alarm_info_table_col)
        select_col = info_select_col + "," + cycle_select_col
        query = '''select ''' + select_col + ''', ROW_NUMBER () OVER (ORDER BY a.tasktime) from ''' + self.alarm_cycle_table + ''' as a join ''' + self.alarm_info_table+''' as b on a.iactoken = b.iactoken ''' + '''where a.iactoken = \'''' + iactoken + '''\' and tasktype in ('MML Output') order by a.tasktime ASC'''
        # print query in log: print query
        df = pd.DataFrame(self.query(query))
        df.columns = self.alarm_info_table_col + alarm_cycle_cols + ['seq_num']
        resolution_summary = self.query('''select resolution_summary from ''' + self.alarm_cycle_table + ''' where iactoken = \'''' + iactoken + '''\' and tasktype = 'Cycle End' ''')[0][0]
        df['resolution_summary'] = resolution_summary
        return df

    def retrieve_scenarios_contextDB(self, iactoken, alarm_key_columns_list):
        # collect alarm information from contextDB for a particular iactoken
        # remove joining column from one of the table so that in the final join it will appear only once
        alarm_cycle_cols = [col for col in self.alarm_cycle_table_col if col != 'iactoken']
        cycle_select_col = " a." + ", a.".join(alarm_cycle_cols)
        info_select_col = " b." + ", b.".join(self.alarm_info_table_col)
        sel_json = [' additionalfields ->> \''+i+'\' as '+i for i in alarm_key_columns_list if i not in self.alarm_info_table_col ]
        sel_json_col = ','+', '.join(sel_json)
        select_col = info_select_col + "," + cycle_select_col
        query = '''select ''' + select_col + sel_json_col + ''', ROW_NUMBER () OVER (ORDER BY a.tasktime) from ''' + self.alarm_cycle_table + ''' as a join ''' + self.alarm_info_table + ''' as b on a.iactoken = b.iactoken ''' + '''where a.iactoken = \'''' + iactoken + '''\' and tasktype in ('MML Output') order by a.tasktime ASC'''
        df = pd.DataFrame(self.query(query))
        df.columns = self.alarm_info_table_col + alarm_cycle_cols + alarm_key_columns_list + ['seq_num']
        resolution_summary = self.query(
            '''select resolution_summary from ''' + self.alarm_cycle_table + ''' where iactoken = \'''' + iactoken + '''\' and tasktype = 'Cycle End' ''')[
            0][0]
        df['resolution_summary'] = resolution_summary
        return df



