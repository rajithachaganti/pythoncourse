# source
# https://stackoverflow.com/questions/1319615/proper-way-to-declare-custom-exceptions-in-modern-python

class Error(Exception):
    """Base class for exceptions in this module."""
    pass


class UnknownExternalTable(Error):
    """Exception raised for errors in the input.

    Attributes:
        expression -- input expression in which the error occurred
        message -- explanation of the error
    """

    def __init__(self, expression, message):
        self.expression = expression
        self.message = message


class UnknownExternalColumn(Error):
    """Exception raised for errors in the input.

    Attributes:
        expression -- input expression in which the error occurred
        message -- explanation of the error
    """

    def __init__(self, expression, message):
        self.expression = expression
        self.message = message


class UnableToFindPatternInDB(Error):
    """
    Unable to find regex pattern with specified parameters
    Attributes:
        expression -- input expression in which the error occurred
        message -- explanation of the error
    """

    def __init__(self, expression, message):
        self.expression = expression
        self.message = message


class ParserError(Error):
    """
    Unable to find regex pattern with specified parameters
    Attributes:
        expression -- input expression in which the error occurred
        message -- explanation of the error
    """

    def __init__(self, expression, message):
        self.expression = expression
        self.message = message


class GenericParserError(Error):
    """
    Unable to find regex pattern with specified parameters
    Attributes:
        expression -- input expression in which the error occurred
        message -- explanation of the error
    """

    def __init__(self, expression, message):
        self.expression = expression
        self.message = message


class UnknownCommandPatternError(Error):
    """
    Unable to find regex pattern with specified parameters
    Attributes:
        expression -- input expression in which the error occurred
        message -- explanation of the error
    """

    def __init__(self, expression, message):
        self.expression = expression
        self.message = message


class ParserHandlerError(Error):
    """
    Unable to find regex pattern with specified parameters
    Attributes:
        expression -- input expression in which the error occurred
        message -- explanation of the error
    """

    def __init__(self, expression, message):
        self.expression = expression
        self.message = message


class UnknownComplexCommand(Error):
    """
    Unable to find regex pattern with specified parameters
    Attributes:
        expression -- input expression in which the error occurred
        message -- explanation of the error
    """

    def __init__(self, expression, message):
        self.expression = expression
        self.message = message


class UnableToFindSubstitutorRules(Error):
    """
    Unable to find regex pattern with specified parameters
    Attributes:
        expression -- input expression in which the error occurred
        message -- explanation of the error
    """

    def __init__(self, expression, message):
        self.expression = expression
        self.message = message


class UnableToFindCommandList(Error):
    """<
    Unable to find regex pattern with specified parameters
    Attributes:
        expression -- input expression in which the error occurred
        message -- explanation of the error
    """

    def __init__(self, expression, message):
        self.expression = expression
        self.message = message
