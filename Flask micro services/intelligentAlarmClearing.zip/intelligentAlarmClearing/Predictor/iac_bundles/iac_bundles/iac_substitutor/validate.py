# Author Shanmugathas Vigneswaran
# contact vigneswaran.shanmugathas.ext@nokia.com

# Substitutor configuration validation class
# check if param exist
# check if param is enumerated from 0 to 0+1
# check if source key exist param
#   if source=ticket check if key_map exist
#   if source ='alarm command' check if command is exist in database
#        if command exist in database, check if key regex_pattern exist
#
# main method : validate(config_dict) -> bool
#
#  Small case
# pred_output = {"PredictorOutput": {
#     "debug": None,
#     "traceback": None,
#     "alarmResolutionSummary": None,
#     "alarmResolutionStatus": None,
#     "algorithmResponseInfo": None,
#     "mmlCommand": "ZEQS:BTS=<param0>:<param1>;<param2> L;",
#     "similarityScore": {
#         "solr_score": 18.53,
#         "jaccard_based_sim": 82.96,
#         "word_matching_sim": 74.0
#     }}
# }
#
# (not real case) Example of a good configuration to substitute:
# - param0 = BTS-ID
# - param1 = some regex pattern , from last ZEEI:BCF
# - param2 = regex pattern to get TRX ID, from last ZERM
#
# config_sample = {
#
#     "param0": {
#         'source': 'ticket',
#         'key_map': ["AdditionalFields", "BTS-ID"]
#     },
#
#     "param1": {
#         'source': 'ZEEI:BCF=\d*;',
#         'regex_pattern': 'ALARM-[A-Z0-9]*'
#     },
#
#     "param2": {
#         'source': 'ZERM:BCF=\d*;',
#         'regex_pattern': 'TRX-\d*'
#     }
# }


import regex as re
from django.db.models.base import ModelBase


class ConfValidator:
    """

    Configuration validation class

    configuration will start with config like that:
    {
    "paramO":
        {"source": "ticket",
        "key_list: ["AdditionalInfos", 'BTS-ID"]}
    "param1":
        {"source": "Command output ",
        "regex_pattern: "some regex pattern"}
    }

    Validation process:
        1/ check if main key level 0 are like : param1, param2 , param3 ...
        2/ check if param key if key='source' exist
        3/

    """

    def __init__(self, _cmd_list_model: ModelBase):
        """

        :param _cmd_list_model: CommandList Django db Model
        """
        self.conf: dict
        self.param_pattern: str = 'param'
        self.cmd_model: ModelBase = _cmd_list_model

    def get_cmd_list(self) -> list:
        """
        Get  existing command list from database
        from Model: parser_api.models.regex.CommandList
        :return:
        """
        for _ in self.cmd_model.objects.all():
            yield _.name

    def check_dict(self) -> bool:
        """
        Check if all first keys
        in dict are "param1", "param2" ...
        if keys != 'paramX' return False
        if all keys == 'paramX' return True
        :return:
        """
        # iteration on dict keys name
        for i, key in enumerate(self.conf.keys()):

            # if param1, param2 [...] not found in all
            # keys = check failed, return False
            if not re.findall(self.param_pattern, key):
                raise KeyError('Strange key found key = {}'.format(key))

        return True

    def check_param_order(self) -> bool:
        # iteration on dict keys name
        for i, key in enumerate(self.conf.keys()):

            # if param1, param2 [...] not found in all
            # keys = check failed, return False

            param_id = int(re.findall(r'\d+', key)[0])

            if i != param_id:
                raise KeyError('"{}" => param number mismatch'.format(key))

        return True

    def check_source(self) -> bool:
        """
        Check if source key is set for each param
        :return:
        """
        # iteration on dict keys
        for i, param in enumerate(self.conf.keys()):
            if not 'source' in self.conf.get(param):
                raise KeyError('Not key "source" for param{}'.format(i))

        return True

    def check_param(self) -> bool:
        """

        :return:
        """
        # iteration on dict keys name
        for i, param in enumerate(self.conf.keys()):
            # check if source is ticket
            if self.conf.get(param).get('source') == 'ticket':
                # check if key_map exit for ticket source
                if not 'key_map' in self.conf.get(param).keys():
                    raise KeyError('param source=ticket with '
                                   'no key_map, param conf = {}'.format(param))
            # If source is not ticket
            else:
                # Check if source exist database list (source = executed command)
                source = self.conf.get(param).get('source')
                if not source in list(self.get_cmd_list()):
                    raise KeyError('param source not found '
                                   'in ORM-Model CommandList, param source = {}'.format(source))
                else:
                    if not 'regex_pattern' in self.conf.get(param).keys():
                        raise KeyError('param source !=ticket with '
                                       'no "regex_pattern" key in {}'.format(param))

        return True

    def validate(self, _dict: dict) -> bool:
        """
        Main method to validate json configuration
        :param _dict:
        :return:
        """
        self.conf = _dict
        self.check_dict()
        self.check_param_order()
        self.check_source()
        self.check_param()
        return True
