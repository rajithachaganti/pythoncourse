import regex as re

from iac_bundles.iac_bundles.common.db_helpers import sub
from iac_bundles.iac_bundles.common.json_helpers import get_last_command_output


def set_parameters(_param_list: list, _raw_predicted_cmd: str):
    """
    Replace raw predictor output <param0> ... by contextual(s) parameter(s)
    :param _param_list:
    :param _raw_predicted_cmd:
    :return:
    """
    for i in range(len(re.findall('param', _raw_predicted_cmd))):
        _raw_predicted_cmd: str = _raw_predicted_cmd.replace(f'<param{i}>', str(_param_list[i]))

    return _raw_predicted_cmd


def parse_from_ticket(_param_conf: dict, _alarm_dict: dict) -> int:
    """
    Get value from alarm ticket
    :param _alarm_dict:
    :param _param_conf:
    :return:

    >>> config = {
    >>>"param0":
    >>>    {"source": "ticket",
    >>>     "key_map": ["AdditionalFields", "BTS-ID"],
    >>>     "force_integer": True }}

    >>>alarm_ticket = {"AdditionalFields": {"BTS-ID": "BTS-54451"}}
    >>>parse_from_ticket(config, alarm_ticket)
    >>>54451
    """
    # Get mapping list to find value through JSON
    map_list: list = _param_conf.get('key_map')

    # Force integer
    force_int: bool = _param_conf.get('force_integer')

    # Get value from dict by using mapping list in config
    value: str = sub.get_from_dict(_alarm_dict, map_list)

    # Convert str to int of force_integer is True
    if force_int:
        # Get string and convert to int
        value: int = int(re.findall(r'\d+', value)[0])

    return value


def parse_last_cmd_output(_param_conf: dict, _alarm_dict: dict) -> int:
    """
    Parse data from last command output
    :param _param_conf:
    :param _alarm_dict:
    :return:
    """
    # Get regex pattern from conf dict
    regex_pattern: str = _param_conf.get('regex_pattern')
    # Force integer
    force_int = _param_conf.get('force_integer')

    # Get last command output without command output filter
    last_cmd_output: str = get_last_command_output(_alarm_dict, False)

    # Get value by using regular expression
    value: str = re.findall(regex_pattern, last_cmd_output)[0]

    if force_int:
        value: int = int(re.findall(r'\d+', value)[0])

    return value


def get_cmd_output_from_source(_source: str, _alarm_dict: dict) -> str:
    """
    Get good command output from source set in configuration : param-> source
    :param _source: regex flavor command (digit parameter replaced by r'\d*'
    :param _alarm_dict:
    :return:
    """
    cmd_list: list = _alarm_dict.get('History').get('cmd_list')
    cmd_output_list: list = _alarm_dict.get('History').get('output_list')

    for cmd, output in zip(reversed(cmd_list), reversed(cmd_output_list)):
        if re.findall(_source, cmd):
            return output

    raise ValueError(f'Can not find command output from this source {_source}')


def parse_from_cmd(_param_conf: dict, _alarm_dict: dict) -> int:
    """
    Parse data from last command output
    :param _param_conf:
    :param _alarm_dict:
    :return:
    """

    # Get source (ZEEI:BTS=\d* [...])
    cmd_source: str = _param_conf.get('source')
    # Get regex pattern from conf dict
    regex_pattern: str = _param_conf.get('regex_pattern')
    force_int: bool = _param_conf.get('force_integer')
    # Set output parameter as none
    # avoid index error in case of found value
    value: str = None

    # Get command output from mentioned source in configuration file for a param
    last_cmd_output: str = get_cmd_output_from_source(cmd_source, _alarm_dict)

    # Get value by using regular expression
    try:
        value: str = re.findall(regex_pattern, last_cmd_output)[0]
    except IndexError:
        # If not value found r
        pass

    if value and force_int:
        value: int = int(re.findall(r'\d+', value)[0])

    return value


def get_param(_conf_dict: dict, _alarm_dict: dict) -> list:
    """
    Main function to fetch all needed parameter
    :param _alarm_dict:
    :param _conf_dict:
    :return:
    """

    # Iteration in each param
    for param in _conf_dict.keys():

        # Get source (ticket/or command name)
        source = _conf_dict.get(param).get('source')

        # If param source if coming from ticket
        if source == 'ticket':
            yield parse_from_ticket(_conf_dict.get(param), _alarm_dict)
        else:
            yield parse_from_cmd(_conf_dict.get(param), _alarm_dict)
