from colorama import init, Fore

init()


class ColorPrint:

    # +---------------------------+
    # | Input json                |
    # +---------------------------+
    @staticmethod
    def reading_post():
        print(f'{Fore.YELLOW}[..]{Fore.RESET} Consuming POST/GET body/data')

    @staticmethod
    def get_data():
        print(f'{Fore.GREEN}[OK]{Fore.RESET} Post data read')

    @staticmethod
    def history_found():
        print(f'{Fore.GREEN}[OK]{Fore.RESET} History in command: {Fore.GREEN}true{Fore.RESET}')

    @staticmethod
    def history_not_found():
        print(f'{Fore.GREEN}[OK]{Fore.RESET} {Fore.RED}No{Fore.RESET} History command')

    # +---------------------------+
    # | Predictor                 |
    # +---------------------------+
    @staticmethod
    def posting_to_predictor():
        print(f'{Fore.YELLOW}[..]{Fore.RESET} Posting to predictor')

    @staticmethod
    def response_from_predictor():
        print(f'{Fore.GREEN}[Ok]{Fore.RESET} Response from predictor')

    @staticmethod
    def response_from_predictor_no_mml():
        print(f'{Fore.YELLOW}[OK]{Fore.RESET} No command predictor output')

    # +---------------------------+
    # | Substitutor               |
    # +---------------------------+
    @staticmethod
    def posting_to_substitutor():
        print(f'{Fore.YELLOW}[..]{Fore.RESET} Posting to substitutor')

    @staticmethod
    def response_from_substitutor():
        print(f'{Fore.GREEN}[OK]{Fore.RESET} Response from substitutor')

    @staticmethod
    def response_from_substitutor_none():
        print(f'{Fore.YELLOW}[WARNING]{Fore.RESET} None param(s) found from substitutor output')

    # +---------------------------+
    # | Orchestrator              |
    # +---------------------------+
    @staticmethod
    def posting_to_orchestrator():
        print(f'{Fore.YELLOW}[..]{Fore.RESET} Posting to orchestrator')

    @staticmethod
    def success_post_to_orchestrator():
        print(f'{Fore.GREEN}[OK]{Fore.RESET} Post to orchestrator')

    @staticmethod
    def error_post_to_orchestrator():
        print(f'{Fore.RED}[ERROR]{Fore.RESET} Post to orchestrator')
