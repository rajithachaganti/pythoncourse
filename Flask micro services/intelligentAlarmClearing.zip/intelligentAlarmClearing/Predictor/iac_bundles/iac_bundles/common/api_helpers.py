import requests
import ujson


def post_to_predictor(_payload: dict, _token: str = '', _headers: dict = None, _uri: str = 'localhost',
                      _port: str = '1235', _resource: str = 'get_next_cmd'):
    """
    Post to Predictor helper 
    :param _headers: 
    :param _payload: 
    :param _token: 
    :param _uri: 
    :param _port: 
    :param _resource: 
    :return: 
    """
    if _headers is None:
        _headers = {
            'Content-Type':  "application/json",
            'cache-control': "no-cache",
            'Postman-Token': "c0869952-712c-4db3-9e83-368b5388aa44"
            }

    url = f'http://{_uri}:{_port}/{_resource}/'

    if type(_payload) == 'dict':
        _payload = ujson.dump(_payload)

    response = requests.request("POST", url, data=_payload, headers=_headers)

    print(response.text)
