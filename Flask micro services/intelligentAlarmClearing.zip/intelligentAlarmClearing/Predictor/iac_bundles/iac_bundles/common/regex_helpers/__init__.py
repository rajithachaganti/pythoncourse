# Regex common tools
# Author: Shanmugathas Vigneswaran
# contact : vigneswaran.shanmugathas.ext@nokia.com

import regex as re


def set_param_number(_str):
    # Search all <param> tag
    for i in range(len(re.findall('<param>', _str))):
        # replace first occurrence only with loop index
        # and save in old variable, repeat until param exist
        _str = _str.replace('<param>', '<param{}>'.format(i), 1)

    return _str


def get_re_group_match(re_pattern, input_str):
    # type: (str, str) -> list
    """
    Return list of match group Regex finditer method
    :param re_pattern:
    :param input_str:
    :return:
    """
    matches = re.finditer(re_pattern, input_str)
    list_prov = []
    for match_num, match in enumerate(matches):
        list_prov.append(match.group())
    return list_prov


def check_exist(re_pattern, input_str):
    # type: (str, str) -> bool
    """
    Check if pattern exist in string
    :param re_pattern:
    :param input_str:
    :return:
    """

    # Define regex expression
    regexp = re.compile(re_pattern)
    # Do verification
    if regexp.search(input_str):
        # if regexp founded
        return True
    else:
        # if regexp not founded
        return False


def get_elements_id(regex_pattern, input_str):
    """

    :param regex_pattern:
    :param input_str:
    :return:
    """
    # If single string
    if type(input_str) is str:
        try:
            # Get raw bts - id ...
            raw_bts_id = get_re_group_match(regex_pattern, input_str)
            # Return only string of digits
            return get_re_group_match(r'\d*', raw_bts_id[0])[0]
        except IndexError:
            return None

    # If list
    elif type(input_str) is list:
        # Empty container
        prov_list = []
        # Make iteration on index
        for i in input_str:
            try:
                # Get raw bts/bcf/trx - id ...
                raw_bts_id = get_re_group_match(regex_pattern, i)
                # Return only string of digits
                prov_list.append(get_re_group_match(r'\d*', raw_bts_id[0])[0])
            except IndexError:
                prov_list.append(None)
        # Return list of string of digit
        return prov_list


def make_regex_flavor(input_list):
    """
    function return grouped regex
    :param input_list:
    :return:
    """

    # type (list) -> raw string

    # Empty variable to group all regex pattern
    regex_group = ""
    # Group all pattern into regex_group
    for re_pattern in input_list:
        regex_group = regex_group + r"({re_pattern})|".format(re_pattern=re_pattern)

    # Remove last 'or' anchor -> "|"
    regex_group = regex_group[:-1]
    return regex_group


def separate(re_pattern, input_str):
    """

    Separate text bu using regex pattern as pivot.

    Details :
        Separate element by collecting cursor index at start and end of a txt,
        and join them with matched group.

    1/ do find re.finditer
        capture matching group : list with string
        capture matching start and end index: tuple with (start index, end index)

    2/ create index couple list
        combine end index of n number of match_list_cursor
        with start index of n+1 number of match_list_cursor
        It's start and ending of not matching elements

    3/ create list with not matched string by using index couple list

    4/ join captured match group and not matched string
        return list of match + not matched

    :param re_pattern:
    :param input_str:
    :return:
    """
    # use finditer to match
    matches = re.finditer(re_pattern, input_str, re.MULTILINE)

    # def match list
    match_group_list: list = []
    match_list_cursor: list = []

    # first match in case of unique element
    first_match_cursor: int
    for match_num, match in enumerate(matches, start=1):
        match_group_list.append(match.group())
        match_list_cursor.append((match.start(), match.end()))
        first_match_cursor = match.start()

    #  break common way if match list = 1
    if len(match_group_list) == 1:
        # return list of this unique matching element
        return [input_str[first_match_cursor:len(input_str)]]
    # If  element > 1 do
    else:
        # def couple of list with not matched text (between matched group)
        # tuple of list with couple with elem[1] last cursor
        # en elem[i+1] first cursor
        couple_list = []
        for i, elem in enumerate(match_list_cursor):
            try:
                couple_list.append((elem[1], match_list_cursor[i + 1][0]))
            except IndexError:
                pass

        # get text between match_group_list element
        sub_element_str = []
        for i in couple_list:
            start_at = i[0]
            end_at = i[1]
            sub_element_str.append(input_str[start_at:end_at])

        # split element to return
        return_list = []
        for i in zip(match_group_list, sub_element_str):
            header = i[0]
            content = i[1]
            return_list.append(header + content)

        # Append last residual text
        try:
            start_cursor = couple_list[-1][1]
            end_cursor = len(input_str)
            residual_text = input_str[start_cursor: end_cursor]
            return_list.append(residual_text)
        except IndexError:
            pass

        return return_list
