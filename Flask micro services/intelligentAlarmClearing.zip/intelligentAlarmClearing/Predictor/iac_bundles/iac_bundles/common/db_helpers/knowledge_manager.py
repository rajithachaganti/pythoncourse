# Database helper module
# Author chiara rampini
# mail : chiara.rampini@nokia.com

from django.db import connection
import pandas as pd

data_tables = {"POSTGRES": {
    "ALARM_CYCLE_TABLE": {
      "NAME": "alarmcycle",
      "COLUMNS": [
        "iactoken",
        "tasktype",
        "mmlcommand",
        "mmloutput"
      ]
    },
    "ALARM_INFO_TABLE" : {
      "NAME": "alarminfo",
      "COLUMNS": [
        "iactoken",
        "customer",
        "nodevendor",
        "nodetype",
        "nodeversion",
        "alarmnumber",
        "alarmname",
        "nodeid",
        "nodename",
        "nodeparent",
        "additionalinfo",
        "additionalfields",
        "scope",
        "status",
        "parentalarm",
        "ticketid",
        "iacalarmid"
      ]
    }
  }
}

def my_custom_sql(query):
    with connection.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchall()
    return result
"""
query3 = '''select inputjson -> 'PredictorOutput' ->> 'rulesResults' as rulesResults, sequencenum, 
    ROW_NUMBER () OVER (ORDER BY b.sequencenum)
    from inputjsondetails a join 
    (select inputreceived, sequencenum 
    from alarmcycle where tasktype = '2' and iactoken =\'12342222\' order by sequencenum) b 
    on a.jsonid = b.inputreceived'''
print ([_row[1] for _row in my_custom_sql(query3)])
print ([[_row[1] for _row in my_custom_sql(query3)]] *3)
"""

def get_mandatory_cols(_iactoken: str):
    """
    Helper to get solr search columns and mandatory column from Alarmcycletable
    """
    data = data_tables
    alarm_info_table = data['POSTGRES']['ALARM_INFO_TABLE']['NAME']
    query = '''select mandatorycols from alarmkeycolumns where iacalarmid = (select CAST(iacalarmid as int) from '''\
            + alarm_info_table + ''' where iactoken = \'''' + _iactoken + '''\')'''
    result =  my_custom_sql(query)[0][0]
    print(result)
    return result


def get_iactoken_scenario(_iactoken: str, alarm_key_columns_list):
    """
    Helper to get solr search columns and mandatory column from Alarmcycletable
    """
    data = data_tables
    alarm_cycle_table = data['POSTGRES']['ALARM_CYCLE_TABLE']['NAME']
    alarm_cycle_table_col = data['POSTGRES']['ALARM_CYCLE_TABLE']['COLUMNS']
    alarm_info_table = data['POSTGRES']['ALARM_INFO_TABLE']['NAME']
    alarm_info_table_col = data['POSTGRES']['ALARM_INFO_TABLE']['COLUMNS']
    # collect alarm information from contextDB for a particular iactoken
    # remove joining column from one of the table so that in the final join it will appear only once
    alarm_cycle_cols = [col for col in alarm_cycle_table_col if col != 'iactoken']
    print('alarm_cycle_cols\n', alarm_cycle_cols )
    cycle_select_col = " a." + ", a.".join(alarm_cycle_cols)
    print('cycle_select_col\n', cycle_select_col)
    info_select_col = " b." + ", b.".join(alarm_info_table_col)
    print ('info_select_col\n', info_select_col)
    sel_json = [' additionalfields ->> \'' + i + '\' as ' + i.lower() for i in alarm_key_columns_list if
                i.lower() not in alarm_info_table_col]
    sel_json_list = [ i.lower() for i in alarm_key_columns_list if i.lower() not in alarm_info_table_col]
    print('sel_json\n', sel_json)
    select_col = info_select_col + "," + cycle_select_col
    if sel_json:
        sel_json_col = ',' + ', '.join(sel_json)
        query = '''select ''' + select_col + sel_json_col + ''', ROW_NUMBER () OVER (ORDER BY a.tasktime) from ''' \
                + alarm_cycle_table + ''' as a join ''' + alarm_info_table + ''' as b on a.iactoken = b.iactoken ''' \
                + '''where a.iactoken = \'''' + _iactoken + '''\' and tasktype in (\'5\') order by a.tasktime ASC'''
    else:
        query = '''select ''' + select_col + ''', ROW_NUMBER () OVER (ORDER BY a.tasktime) from ''' \
                + alarm_cycle_table + ''' as a join ''' + alarm_info_table + ''' as b on a.iactoken = b.iactoken ''' \
                + '''where a.iactoken = \'''' + _iactoken + '''\' and tasktype in (\'5\') order by a.tasktime ASC''' #5 for 'MML Output'
    print (query)
    df = pd.DataFrame(my_custom_sql(query))
    print (alarm_info_table_col + alarm_cycle_cols + sel_json_list + ['seq_num'])
    df.columns = alarm_info_table_col + alarm_cycle_cols + sel_json_list + ['seq_num']
    query2 = '''select resolutionsummary as resolution_summary, resolutioncode as resolutionstatus from ''' \
             + alarm_cycle_table + ''' where iactoken = \'''' + _iactoken + '''\' and tasktype = \'8\' ''' # 8 for 'Cycle End'
    print(query2)
    resolution_summary = my_custom_sql(query2)[0][0]
    resolutionstatus = my_custom_sql(query2)[0][1]
    print (resolution_summary)
    df['resolutionsummary'] = resolution_summary
    df['resolutionstatus'] = resolutionstatus
    df.rename(columns={"mmloutput": "mmlcommandoutput"}, inplace=True)
    query3 = '''select inputjson -> 'PredictorOutput' ->> 'rulesResults' as rulesResults, 
    inputjson -> 'PredictorOutput' ->> 'rules' as rules, sequencenum, 
    ROW_NUMBER () OVER (ORDER BY b.sequencenum)
    from inputjsondetails a join 
    (select inputreceived, sequencenum 
    from alarmcycle where tasktype = '2' and iactoken =\'''' + _iactoken + '''\' order by sequencenum) b 
    on a.jsonid = b.inputreceived'''
    print (query3)
    print(df.shape)
    print(df.to_string())
    print(my_custom_sql(query3))
    _rules = [_row[1] if _row[1] else [] for _row in my_custom_sql(query3)][:-1]
    _rulesres = [_row[0] if _row[0] else [] for _row in my_custom_sql(query3)][:-1]
    print(_rules)
    print(_rulesres)
    print(0)
    df['rules'] = _rules
    print(1)
    df['rules_list'] = [_rules] * df.shape[0]
    print(2)
    df['rules_seq'] =  df.apply(lambda row : " ".join(str(row.rules_list[:row.seq_num])), axis = 1)
    print(3)
    df['rulesResults'] = _rulesres
    print(4)
    df['rulesResults_list'] = [_rulesres] * df.shape[0]
    print(5)
    df['rulesresults_seq'] = df.apply(lambda row : " ".join(str(row.rulesResults_list[:row.seq_num])), axis = 1)
    print(df.columns)
    return df