# Database helper module
# Author Vigneswaran Shanmugathas
# mail : vigneswaran.shanmugathas.ext@nokia.com

from iac_bundles.iac_bundles import exc
from django.db.models.base import ModelBase


def get_regex(_model: ModelBase,
              _vendor_type: str, _alarm_text: str, _cmd_name: str,
              _pattern_tag: str):
    """
    Helper to get regex pattern from database 
    :param _model:
    :param _vendor_type:
    :param _alarm_text:
    :param _cmd_name:
    :param _pattern_tag:
    :return:
    """
    _filter = {
        '_vendor_type': _vendor_type,
        '_alarm_text':  _alarm_text,
        '_cmd_name':    _cmd_name,
        '_pattern_tag': _pattern_tag
        }

    r = _model.objects \
        .filter(vendor__name=_vendor_type) \
        .filter(alarm__name=_alarm_text) \
        .filter(command__name=_cmd_name) \
        .filter(pattern_tag__name=_pattern_tag)

    if r.exists():
        found_pattern = r[0].pattern.pattern

        if found_pattern:
            return found_pattern
        else:
            raise exc.UnableToFindPatternInDB('Unable to find regex pattern',
                                              'Check filter criteria : {}'.format(_filter))
    else:
        raise exc.UnableToFindPatternInDB('Unable to find regex pattern',
                                          'Check filter criteria : {}'.format(_filter))