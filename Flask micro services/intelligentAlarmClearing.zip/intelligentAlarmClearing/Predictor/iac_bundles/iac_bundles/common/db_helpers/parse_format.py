# Database helper module
# Author Vigneswaran Shanmugathas
# mail : vigneswaran.shanmugathas.ext@nokia.com

from iac_bundles.iac_bundles import exc
from django.db.models.base import ModelBase
from django.db.models.query import QuerySet


def get_pattern_list(_model: ModelBase,
                     _vendor_type: str, _alarm_text: str, _cmd_name: str) -> list:
    """
    Helper to get  parser format  from database

    Note :
        for a vendor, for an alarm text, for a command name,
        many parsing format can be added.
        All of these parsing format will be tested until get output

    :param _model:
    :param _vendor_type:
    :param _alarm_text:
    :param _cmd_name:
    :return:
    """
    return_list: list = []

    # Create dict with used filters
    _filter: dict = {
        '_vendor_type': _vendor_type,
        '_alarm_text':  _alarm_text,
        '_cmd_name':    _cmd_name,
        }

    # Create a request in database
    r: QuerySet = _model.objects \
        .filter(vendor__name=_vendor_type) \
        .filter(alarm__name=_alarm_text) \
        .filter(command__name=_cmd_name)[0].pattern.values_list()

    #  Check if there is result from database
    if r.exists():
        # unpack tuple id, and pattern to save pattern
        # to return list Ò
        for i, pattern, in r:
            return_list.append(pattern)

        return return_list
    else:
        raise exc.UnableToFindPatternInDB('No result from database '
                                          'vendor type / alarm text / command pattern',
                                          'Check filter criteria : {}'.format(_filter))
