# Database helper module
# Author Vigneswaran Shanmugathas
# mail : vigneswaran.shanmugathas.ext@nokia.com

from iac_bundles.iac_bundles import exc
from django.db.models.base import ModelBase


def get_cmd_list(_model: ModelBase,
                 _vendor: str,
                 _alarm_text: str) -> list:
    """
    Helper to get regex pattern from database
    :param _vendor:
    :param _alarm_text:
    :param _model:
    :return:
    """
    _filter = {'_alarm_text': _alarm_text,
               '_vendor': _vendor}

    r = _model.objects \
        .filter(vendor__name__iexact=_vendor) \
        .filter(alarm__name__iexact=_alarm_text)

    if r.exists():
        if type(eval(eval(r[0].command_list.values))) is list:
            return eval(eval(r[0].command_list.values))
        else:
            return eval(eval(eval(r[0].command_list.values)))
    else:
        raise exc.UnableToFindCommandList('Unable to find command list',
                                          'Check filter criteria : {}'.format(_filter))
