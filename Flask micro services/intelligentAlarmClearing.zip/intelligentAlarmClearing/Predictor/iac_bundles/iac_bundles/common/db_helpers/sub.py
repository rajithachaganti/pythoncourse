# Database helper module
# Author Vigneswaran Shanmugathas
# mail : vigneswaran.shanmugathas.ext@nokia.com

from functools import reduce  # forward compatibility for Python 3
import operator
from iac_bundles.iac_bundles import exc
from django.db.models.base import ModelBase


def get_sub_config(_model: ModelBase,
                   _vendor: str,
                   _alarm_text: str,
                   _predictor_raw_output: str) -> dict:
    """
    Helper to get regex pattern from database
    :param _vendor:
    :param _alarm_text:
    :param _predictor_raw_output:
    :param _model:
    :return:
    """
    _filter = {
        '_predictor_raw_output': _predictor_raw_output,
        '_alarm_text': _alarm_text,
        '_vendor': _vendor
    }

    r = _model.objects \
        .filter(vendor__name__iexact=_vendor) \
        .filter(alarm__name__iexact=_alarm_text) \
        .filter(predictor_command__name__iexact=_predictor_raw_output)

    if r.exists():
        return r[0].parsing_conf.rule
    else:
        raise exc.UnableToFindSubstitutorRules('Unable to find sub config',
                                               'Check filter criteria : {}'.format(_filter))


def get_from_dict(_data_dict: dict, _map_list: list):
    """
    Get value from key value from map list
    source : https://stackoverflow.com/questions/14692690/access-nested-dictionary-items-via-a-list-of-keys
    :param _data_dict:
    :param _map_list:
    :return:
    """
    return reduce(operator.getitem, _map_list, _data_dict)
