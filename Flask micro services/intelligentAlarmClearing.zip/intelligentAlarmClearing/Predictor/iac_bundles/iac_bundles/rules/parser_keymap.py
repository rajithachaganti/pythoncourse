import re
# Function which retrieves data from ParserOutput dictionary based on keymap column value for a particular pair of
# alarmname, generic_cmd


def recursive_items(dictionary):
    # source https://stackoverflow.com/questions/39233973/get-all-keys-of-a-nested-dictionary
    # Here is the program that will alows you to loop through key-value pair of a dict with unlimited number of
    # nesting levels (more generic approach):
    # That is relevant if you are interested only in key-value pair on deepest level (when value is not dict)
    for key, value in dictionary.items():
        if type(value) is dict:
            yield (key, value)
            yield from recursive_items(value)
        else:
            yield (key, value)

def recursive_items_value(dictionary):
    # source https://stackoverflow.com/questions/39233973/get-all-keys-of-a-nested-dictionary
    # If you are also interested in key-value pair where value is dict
    for key, value in dictionary.items():
        if type(value) is dict:
            yield from recursive_items(value)
        else:
            yield (key, value)

def get_keymap_value(parser_output_dict, parsed_output_keymap):
    # keymap values should be separated with '_' as for example BTS_TRX
    # the function will get the value of parser_output_dict['BTS']['TRX'] and return it
    if parsed_output_keymap == "keys":
        # if we only want to get the values of parserOutput dictionary keys
        _value = parser_output_dict.keys()
    else:
        _keys = parsed_output_keymap.split('_')
        _value = []
        print ("KEYS:   ",_keys)
        if len(_keys) == 1:
            for k, v in recursive_items(parser_output_dict):
                print ("KEY_VALUE = ", "k=", k, "v=",v)
                if re.compile(_keys[0]).match(k):
                    _value.append(v)
        if len(_keys) > 1:
            _value1 = []
            for k, v in parser_output_dict.items():
                if re.compile(_keys[0]).match(k):
                    _value1.append(parser_output_dict[k])
            _value = _value1
            for i in range(len(_keys))[1:]:
                _value = [j[k] for j in _value for k in j.keys() if re.compile(_keys[i]).match(k)]
    return _value

#test1
keymap = 'BTS'
_dict = {'BTS':{'TRX':{'ABC':'test'}}}
print(get_keymap_value(_dict,keymap))


#test2
keymap = r'BTS-.*_OPSTATE'
_dict = {'BTS-1':{'OPSTATE':"WO",'TRX':[1,2]}, 'BTS-2':{'OPSTATE':"WO",'TRXL':[3,4]}}
print(get_keymap_value(_dict,keymap))
