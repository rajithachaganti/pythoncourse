from iac_bundles.iac_bundles.rules.parser_keymap import *

def loop(_rules, i, ParserOutput_dict):
    _keymap = list(_rules.get('keymap'))[i]
    _condition = list(_rules.get('condition'))[i]
    _valuetocheck = list(_rules.get('value'))[i]
    _keymapval = get_keymap_value(ParserOutput_dict, _keymap)
    if _condition:
        _res = [j for j in _keymapval if eval('\''+str(j)+'\''+_condition + '\''+str(_valuetocheck)+'\'')]
    else:
        _res = _keymapval
    return len(_res)

def threshold(_rules, i, ParserOutput_dict):
    print(_rules.get('keymap'))
    _keymap = list(_rules.get('keymap'))[i]
    _condition = list(_rules.get('condition'))[i]
    _valuetocheck = list(_rules.get('value'))[i]
    _keymapval = get_keymap_value(ParserOutput_dict, _keymap)
    print("keymapvalue = ", _keymapval)
    print (["T" if eval(str(j)+_condition+str(_valuetocheck)) else "F" for j in _keymapval])
    _res = list(set(["T" if eval(str(j)+_condition+str(_valuetocheck)) else "F" for j in _keymapval]))
    print(_res)
    return _res

def external_file(x):

    return x

def timecheck(x):

    return x
