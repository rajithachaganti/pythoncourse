from iac_bundles.iac_bundles.rules.table import get_rules_info
from iac_bundles.iac_bundles.rules.rules import *

def check_rule(alarmname, generic_cmd, ParserOutput):
    _rules = get_rules_info(alarmname, generic_cmd)
    res = []
    if _rules:
        _rule = list(_rules.get('rule'))
        print (len(_rule))
        for i in range(len(_rule)):
            _fz = _rule[i]
            print("RULE = ", _fz)
            res.append(globals()[_fz](_rules, i, ParserOutput))
    return list(_rule), res

_dict = {"BTS-1":
             {"OPSTATE":"WO",
              "TRX":[1,2]},
         "BTS-2":
             {"OPSTATE":"WO",
              "TRXL":[3,4]}}
print(check_rule('BCCH Missing Fault','ZEEI:BCF=<param0>;', _dict))


_dict = {"1":{'PLOAD':60},"2":{'PLOAD':90}}
print(check_rule('Size alteration','plldp;', _dict))