import pandas as pd

rules_table = pd.DataFrame(
    {'alarmname':['BCCH Missing Fault', 'Size alteration', 'Size alteration'],
     'parser_cmd': ['ZEEI', '', ''],
     'generic_cmd':['ZEEI:BCF=<param0>;', 'plldp;', 'plldp;'],
     'keymap':['BTS-.*_OPSTATE', '.*_PLOAD', '.*_PLOAD'],
     'rule':['loop', 'threshold', 'threshold'],
     'function':['', '', ''],
     'condition':['!=', '>', '>'],
     'value':['WO', '60', '80'],
     'output':['list', 'set(T,F)', 'set(T,F)']})

print(rules_table.to_string())
def get_rules_info(alarmname, generic_cmd):
    df = (rules_table['alarmname'] == alarmname) & (rules_table['generic_cmd'] == generic_cmd)
    _result = dict(rules_table[df])
    # returns a dictionary of series
    return _result

print ('\nGET RULE FOR BCCH Missing Fault : \n ', get_rules_info('BCCH Missing Fault','ZEEI:BCF=<param0>;'))
