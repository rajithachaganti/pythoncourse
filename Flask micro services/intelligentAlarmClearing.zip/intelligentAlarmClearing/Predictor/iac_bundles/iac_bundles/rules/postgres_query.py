from django.db import connection
import pandas as pd


def my_custom_sql(query):
    with connection.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchall()
    return result


def get_rule(alarmname, generic_cmd):
    """
    Helper to get solr search columns and mandatory column from Alarmcycletable
    """
    query = '''select from rules_table where generic_cmd = \''''\
            + generic_cmd + '''\' and alarmname = ''' + alarmname +'''\''''
    result =  my_custom_sql(query)#[0][0] first row first column
    print(result)
    return result