from django.urls import path

from . import views

urlpatterns = [
    path('get_next_command/', views.v1.async_predictor_api, name='get_next_command'),
    path('get_next_command_echo/', views.v1.get_next_command_echo, name='get_next_command_echo')]