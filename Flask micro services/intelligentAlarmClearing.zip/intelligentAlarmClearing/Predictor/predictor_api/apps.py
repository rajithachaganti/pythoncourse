from django.apps import AppConfig


class PredictorApiConfig(AppConfig):
    name = 'predictor_api'
