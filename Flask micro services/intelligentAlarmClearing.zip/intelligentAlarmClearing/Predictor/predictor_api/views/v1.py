import sys
import os
import requests
APP_ROOT = os.path.dirname(os.path.realpath(__file__))
import warnings, traceback
from concurrent.futures import ThreadPoolExecutor

from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response

# Append iac_bundles path to this view
sys.path.append(os.path.abspath(os.path.join(os.path.dirname('__file__'), '..', '..', 'iac_bundles')))

from iac_bundles.iac_bundles.ds_tools.solrIndex import SolrInstance
from iac_bundles.iac_bundles.ds_tools.logsTransform import get_generic_output
from iac_bundles.iac_bundles.ds_tools.alarmSession import alarmSession
from iac_bundles.iac_bundles.ds_tools.rules import check_rule
from iac_bundles.iac_bundles.ds_tools.solrIndex import ambiguity_check_first_command_query_execution
from iac_bundles.iac_bundles.ds_tools.solrIndex import ambiguity_check_next_command_query_execution

import logging
from iac_bundles.iac_bundles.ds_tools.logs import iAC_PREDICTOR_API_MESSAGE_LOGGER_NAME

msglogr = logging.getLogger(iAC_PREDICTOR_API_MESSAGE_LOGGER_NAME)
msglogr.info(f"Predictor api started")

warnings.filterwarnings("ignore")
json_path = APP_ROOT+ "/"

worker_pool1  = ThreadPoolExecutor(10)

# Resources/API definition
if os.environ.get('SUBS_API_FULL_URL'):
    SUBSTITUTOR_RESOURCE_URL = os.environ.get('SUBS_API_FULL_URL')
    msglogr.info(f"Substitutor URL set to {SUBSTITUTOR_RESOURCE_URL}")
else:
    #TODO ENV
    SUBSTITUTOR_RESOURCE_URL = 'http://192.168.0.7:5052/ps/substitute/'
    msglogr.info(f"Substitutor URL set to {SUBSTITUTOR_RESOURCE_URL}")


def post_to_resource(_resource_url, _dict):
    """
    Mai
    :param _resource_url:
    :param _dict:
    :return:
    """
    try:
        r = requests.post(_resource_url, json=_dict)
        msglogr.debug(f"JSON to send : {_dict}")
        msglogr.info(f"sending request to {_resource_url}")
        if r.ok:
            msglogr.info(f"Successfully sent json to {_resource_url}, r.ok")
            return True
        else:
            msglogr.info(f"Successfully sent json to {_resource_url}, not r.ok")
    except:
        msglogr.error(f'[INTERNAL NETWORK ERROR] check connection '
              f'with this resource {_resource_url}')

    return False



def get_next_command(_alarm_data: dict):
    # read dict from  HTTP JSON Body
    # 0. PARSE JSON
    try:
        msglogr.info(f"START Get next command")
        alarm_session = alarmSession(_alarm_data)
        msglogr.debug(f"JSON received : \n{_alarm_data}")
    except Exception as e:
        _alarm_data["PredictorOutput"] = {
            "debug": "error",
            "traceback": "Incorrect JSON format: " + str(e) + traceback.format_exc(),
            "errorstack": traceback.format_stack(),
            "iacstatus" : "Failed",
            "iacerrordetails" : "Incorrect input JSON format: " + str(e)
        }
        msglogr.error(f"{_alarm_data.get('PredictorOutput')}")
        post_to_resource(SUBSTITUTOR_RESOURCE_URL, _alarm_data)
        return None

    try:
        if alarm_session.ParserOutput_status == "Failed":
            msglogr.info(f"ParserOutput iacstatus = Failed")
            alarm_session.set_resolutionStatus_manual_intervention()
            alarm_session.set_iacstatus_failed()
            alarm_session.set_iacerrordetails("Paser iacstatus Failed")
            post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
            msglogr.debug(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
            alarm_session.output_json.get('PredictorOutput')
            msglogr.info(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
            return None
    except Exception as e:
        alarm_session.set_debug("error", "Error while connecting to Solr: " + str(e) + traceback.format_exc())
        alarm_session.set_resolutionStatus_manual_intervention()
        alarm_session.set_iacerrordetails(str(e))
        msglogr.error(f"{alarm_session.output_json.get('PredictorOutput')}")
        post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
        return None

    try:
        # CREATE SOLR INSTANCE
        msglogr.debug(f"Solr instance initialization for iactoken {alarm_session.iactoken}")
        instance = SolrInstance(json_path+'config.json')
        msglogr.info(f"Initialize Solr instance for iactoken {alarm_session.iactoken}: "
                     f"HOST={instance.host}, "
                     f"PORT={instance.port}, "
                     f"CORE={instance.core}, "
                     f"AVA={instance.ava}, "
                     f"CHUNK SIZE={instance.chunk_size}, "
                     f"CORE TYPE={instance.coretype}")
        msglogr.debug(f"Solr instance initialized for iactoken {alarm_session.iactoken}")
    except Exception as e:
        alarm_session.set_iacstatus_failed()
        alarm_session.set_iacerrordetails(str(e))
        alarm_session.set_debug("error", "Error while connecting to Solr: " + str(e) + traceback.format_exc())
        alarm_session.set_resolutionStatus_manual_intervention()
        msglogr.error(f"{alarm_session.output_json.get('PredictorOutput')}")
        post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
        return None

    try:
        # 1.1 CHECK IF WE NEED TO PREDICT THE FIRST COMMAND OR THE NEXT COMMAND
        #      1.1.1 CALCULATE FIRST COMMAND
        if not alarm_session.history:
            msglogr.debug(f"No history found for iactoken {alarm_session.iactoken}")
            msglogr.debug(f"START first command prediction for iactoken {alarm_session.iactoken}")
            try:
                first_cmd_res, next_real_cmd = instance.query_first_cmd(alarm_session)
                alarm_session.set_KMmmlcommand(next_real_cmd)
                if first_cmd_res not in [1, 2]:
                    msglogr.debug(f"Exactly one distinct first command found for the alarm {alarm_session.alarmname} iactoken {alarm_session.iactoken}")
                    if isinstance(first_cmd_res, dict):
                        msglogr.debug(f"First command is resolution summary for the alarm {alarm_session.alarmname} iactoken {alarm_session.iactoken}")
                        alarm_session.set_alarmResolutionSummary(first_cmd_res['alarmResolutionSummary'],
                                                                 first_cmd_res['alarmResolutionStatus'])
                        post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
                        msglogr.debug(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                        alarm_session.output_json.get('PredictorOutput')
                        msglogr.info(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                        return None

                    else:
                        alarm_session.set_mmlcommand(first_cmd_res)
                        alarm_session.set_resolutionStatus_execute_mmlcommand()
                        post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
                        msglogr.debug(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                        alarm_session.output_json.get('PredictorOutput')
                        msglogr.info(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                        return None

                if first_cmd_res == 1:
                    # if more than one distinct command found for the actual alarmText and they have same count value

                    res_status, cmd_to_excecute, res_dict = ambiguity_check_first_command_query_execution(alarm_session,
                                                                                                  alarm_session.commands_occurences_difference_threshold,
                                                                                                  next_real_cmd)

                    # We should always keep the dict information
                    alarm_session.set_algorithmResponseInfo(res_dict)

                    if res_status == 1:
                        # commands_occurences_difference_threshold was respected. Only one command will be executed
                        msglogr.debug(
                            f"Multiple commands were found, the command with higher occurrences was selected iactoken {alarm_session.iactoken}")
                        if isinstance(cmd_to_excecute, dict):
                            msglogr.debug(
                                f"First command is resolution summary for the alarm {alarm_session.alarmname} iactoken {alarm_session.iactoken}")
                            alarm_session.set_alarmResolutionSummary(cmd_to_excecute['alarmResolutionSummary'],
                                                                     cmd_to_excecute['alarmResolutionStatus'])
                            post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
                            msglogr.debug(
                                f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                            alarm_session.output_json.get('PredictorOutput')
                            msglogr.info(
                                f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                            return None

                        else:
                            alarm_session.set_mmlcommand(cmd_to_excecute)
                            alarm_session.set_resolutionStatus_execute_mmlcommand()
                            post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
                            msglogr.debug(
                                f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                            alarm_session.output_json.get('PredictorOutput')
                            msglogr.info(
                                f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                            return None

                    elif res_status == 2:
                        # commands_occurrences_difference_threshold was not respected. all commands (in dict) will be proposed to end user
                        alarm_session.set_iacerrordetails(
                            "Multiple records observed at knowledge model matching that scenario. Commands occurrences difference threshold was not respected.")
                        alarm_session.set_iacstatus_ambiguous()
                        alarm_session.set_resolutionStatus_manual_intervention()
                        # "debug": "warning"
                        post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
                        msglogr.debug(
                            f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                        alarm_session.output_json.get('PredictorOutput')
                        msglogr.info(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                        return None

                if first_cmd_res == 2:
                    # nothing found on Solr for this alarm and customer
                    alarm_session.set_algorithmResponseInfo(
                        "Alarm path not found")
                    alarm_session.set_resolutionStatus_manual_intervention()
                    post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
                    msglogr.debug(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                    alarm_session.output_json.get('PredictorOutput')
                    msglogr.info(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                    return None

            except Exception as e:
                alarm_session.set_iacstatus_failed()
                alarm_session.set_iacerrordetails(str(e))
                alarm_session.set_debug("error", "Error during first command prediction: " + str(e) + traceback.format_exc())
                alarm_session.set_resolutionStatus_manual_intervention()
                msglogr.error(f"{alarm_session.output_json.get('PredictorOutput')}")
                post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
                return None

            finally:
                instance.close_connection()
        #  1.1.2 CALCULATE THE NEXT COMMAND
        else:
            #  1.1.2.1 DATA PREPARATION
            try:
                seq_num = len(alarm_session.cmd_list)
                generic_cmd_list = alarm_session.command_format_list
                #generic_cmd_list = [get_generic_cmd(cmd_togeneric_pattern(), x, {}) for x in alarm_session.get_cmd_list()]
                sequence_str = ' '.join(generic_cmd_list)
                generic_output = get_generic_output(alarm_session.output, alarm_session.cmd_list[-1],
                                                    alarm_session.additionalfields.update(
                                                    {"alarmname":alarm_session.alarmname,
                                                     "nodename": alarm_session.nodename,
                                                     "nodeid": alarm_session.nodeid,
                                                     "nodeparent": alarm_session.nodeparent}), alarm_session.additionalinfo)
                alarm_session.set_genericOutput(generic_output)
                msglogr.debug(f"Generic_output: {generic_output}")
                set_generic_output = ' newline '.join(sorted(set(generic_output.split(' newline '))))
                msglogr.debug(f"Set generic_output: {set_generic_output}")
            except Exception as e:
                alarm_session.set_iacstatus_failed()
                alarm_session.set_iacerrordetails(str(e))
                alarm_session.set_debug("error", "data preparation error: " + str(e) + traceback.format_exc())
                alarm_session.set_resolutionStatus_manual_intervention()
                msglogr.error(f"{alarm_session.output_json.get('PredictorOutput')}")
                post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
                return None

            finally:
                instance.close_connection()
            # CHECK IF A RULE SHOULD BE APPLIED
            try:
                _rule_res = check_rule(alarm_session.ParserOutput)
                if _rule_res[0]:
                    alarm_session.set_rules(_rule_res[0])
                    alarm_session.set_rulesResults(_rule_res[1])
            except Exception as e:
                alarm_session.set_iacstatus_failed()
                alarm_session.set_iacerrordetails(str(e))
                alarm_session.set_debug("error", "Rules check error: " + str(e) + traceback.format_exc())
                alarm_session.set_resolutionStatus_manual_intervention()
                msglogr.error(f"{alarm_session.output_json.get('PredictorOutput')}")
                post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
                return None

            # 1.1.2.2 QUERY SOLR TO GET NEXT GENERIC COMMAND VALUE
            try:
                next_cmd_res, sim_score, next_real_cmd = instance.query_next_cmd_score(alarm_session, seq_num, sequence_str,
                                                                        generic_output, set_generic_output)
                alarm_session.set_KMmmlcommand(next_real_cmd)
                if next_cmd_res not in [1, 2]:
                    # if only one distinct command found for the actual alarmText
                    if isinstance(next_cmd_res, dict):
                        alarm_session.set_alarmResolutionSummary(next_cmd_res['alarmResolutionSummary'],
                                                                 next_cmd_res['alarmResolutionStatus'])
                        alarm_session.set_similarity_score(sim_score)
                        post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
                        msglogr.debug(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                        alarm_session.output_json.get('PredictorOutput')
                        msglogr.info(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                        return None

                    else:
                        alarm_session.set_mmlcommand(next_cmd_res)
                        alarm_session.set_similarity_score(sim_score)
                        if alarm_session.similarityThreshold:
                            if sim_score['similarityUI'] > alarm_session.similarityThreshold:
                                alarm_session.set_resolutionStatus_execute_mmlcommand()
                            else:
                                alarm_session.set_resolutionStatus_manual_intervention()
                        else:
                            alarm_session.set_resolutionStatus_execute_mmlcommand()
                        post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
                        msglogr.debug(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                        alarm_session.output_json.get('PredictorOutput')
                        msglogr.info(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                        return None

                if next_cmd_res == 1:
                    # if more than one distinct command found for the actual alarmText and they have same count value
                    res_status, cmd_to_excecute, res_dict = ambiguity_check_next_command_query_execution(alarm_session,
                                                                                                 alarm_session.commands_occurences_difference_threshold,
                                                                                                 sim_score["commands"])
                    # We should always keep the dict information
                    alarm_session.set_algorithmResponseInfo(res_dict)

                    if res_status == 1:
                        # commands_occurences_difference_threshold was respected. Only one command will be executed
                        msglogr.debug(
                            f"Multiple commands were found, the command with higher occurrences was selected iactoken {alarm_session.iactoken}")
                        if isinstance(cmd_to_excecute, dict):
                            # if cmd_to_excecute is a dict
                            alarm_session.set_alarmResolutionSummary(cmd_to_excecute['alarmResolutionSummary'],
                                                                     cmd_to_excecute['alarmResolutionStatus'])
                            post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
                            msglogr.debug(
                                f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                            alarm_session.output_json.get('PredictorOutput')
                            msglogr.info(
                                f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                            return None

                        else:
                            # if cmd_to_excecute is a command
                            alarm_session.set_mmlcommand(cmd_to_excecute)
                            alarm_session.set_resolutionStatus_execute_mmlcommand()
                            post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
                            msglogr.debug(
                                f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                            alarm_session.output_json.get('PredictorOutput')
                            msglogr.info(
                                f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                            return None


                    elif res_status == 2:
                        # commands_occurrences_difference_threshold was not respected. all commands (in dict) will be proposed to end user
                        alarm_session.set_iacerrordetails(
                            "Multiple records observed at knowledge model matching that scenario. Commands occurrences difference threshold was not respected.")
                        alarm_session.set_iacstatus_ambiguous()
                        alarm_session.set_resolutionStatus_manual_intervention()
                        # "debug": "warning"
                        post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
                        msglogr.debug(
                            f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                        alarm_session.output_json.get('PredictorOutput')
                        msglogr.info(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                        return None

                if next_cmd_res == 2:
                    alarm_session.set_algorithmResponseInfo("Resolution path not handled by the system")
                    alarm_session.set_similarity_score(sim_score)
                    alarm_session.set_resolutionStatus_manual_intervention()
                    post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
                    msglogr.debug(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                    alarm_session.output_json.get('PredictorOutput')
                    msglogr.info(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                    return None

            except Exception as e:
                alarm_session.set_iacstatus_failed()
                alarm_session.set_iacerrordetails(str(e))
                alarm_session.set_debug("error", "Error during next command prediction: " + str(e) + traceback.format_exc())
                alarm_session.set_resolutionStatus_manual_intervention()
                msglogr.error(f"{alarm_session.output_json.get('PredictorOutput')}")
                post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
                return None

            finally:
                instance.close_connection()

    except Exception as e:
        alarm_session.set_iacstatus_failed()
        alarm_session.set_iacerrordetails(str(e))
        alarm_session.set_debug("error", "Error in command prediction: " + str(e) + traceback.format_exc())
        alarm_session.set_resolutionStatus_manual_intervention()
        msglogr.error(f"{alarm_session.output_json.get('PredictorOutput')}")
        post_to_resource(SUBSTITUTOR_RESOURCE_URL, alarm_session.output_json)
        return None

@api_view(['POST'])
def get_next_command_echo(request):
    # read dict from  HTTP JSON Body
    # 0. PARSE JSON
    if request.method == 'POST':
        try:
            # Read from post
            msglogr.debug("PREDICTOR ECHO REQUEST RECEIVED")
            msglogr.debug("Reading incoming data")
            _alarm_data = request.data
            msglogr.debug("Read incoming data")
        except Exception as e:
            msglogr.debug(f"error in JSON: "+ str(e) + traceback.format_exc())
            return Response({
                "iacstatus" : "Failed",
                "iacerrordetails": "Incorrect input data format: " + str(e),
                "error": "error in JSON: "+ str(e) + traceback.format_exc()}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        try:
            msglogr.info(f"START Get next command")
            alarm_session = alarmSession(_alarm_data)
            msglogr.debug(f"JSON received : \n{_alarm_data}")
        except Exception as e:
            _alarm_data["PredictorOutput"] = {
                "debug": "error",
                "traceback": "Incorrect JSON format: " + str(e) + traceback.format_exc(),
                "errorstack": traceback.format_stack(),
                "iacstatus" : "Failed",
                "iacerrordetails": "Incorrect input JSON format: " + str(e)
            }
            msglogr.error(f"{_alarm_data.get('PredictorOutput')}")
            return Response(_alarm_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        try:
            if alarm_session.ParserOutput_status == "Failed":
                msglogr.info(f"ParserOutput iacstatus = Failed")
                alarm_session.set_resolutionStatus_manual_intervention()
                alarm_session.set_iacstatus_failed()
                alarm_session.set_iacerrordetails("Paser iacstatus Failed")
                msglogr.debug(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                return Response(alarm_session.output_json, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        except Exception as e:
            alarm_session.set_debug("error", "Error while connecting to Solr: " + str(e) + traceback.format_exc())
            alarm_session.set_resolutionStatus_manual_intervention()
            alarm_session.set_iacerrordetails(str(e))
            msglogr.error(f"{alarm_session.output_json.get('PredictorOutput')}")
            return Response(alarm_session.output_json, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        try:
            # CREATE SOLR INSTANCE
            msglogr.debug(f"Solr instance initialization for iactoken {alarm_session.iactoken}")
            instance = SolrInstance(json_path+'config.json')
            msglogr.info(f"Initialize Solr instance for iactoken {alarm_session.iactoken}: "
                         f"HOST={instance.host}, "
                         f"PORT={instance.port}, "
                         f"CORE={instance.core}, "
                         f"AVA={instance.ava}, "
                         f"CHUNK SIZE={instance.chunk_size}, "
                         f"CORE TYPE={instance.coretype}")
            msglogr.debug(f"Solr instance initialized for iactoken {alarm_session.iactoken}")
        except Exception as e:
            alarm_session.set_iacstatus_failed()
            alarm_session.set_iacerrordetails(str(e))
            alarm_session.set_debug("error", "Error while connecting to Solr: " + str(e) + traceback.format_exc())
            alarm_session.set_resolutionStatus_manual_intervention()
            msglogr.error(f"{alarm_session.output_json.get('PredictorOutput')}")
            return Response(alarm_session.output_json, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        try:
            # 1.1 CHECK IF WE NEED TO PREDICT THE FIRST COMMAND OR THE NEXT COMMAND
            #      1.1.1 CALCULATE FIRST COMMAND
            if not alarm_session.history:
                msglogr.debug(f"No history found for iactoken {alarm_session.iactoken}")
                msglogr.debug(f"START first command prediction for iactoken {alarm_session.iactoken}")
                try:
                    first_cmd_res, next_real_cmd = instance.query_first_cmd(alarm_session)
                    alarm_session.set_KMmmlcommand(next_real_cmd)
                    if first_cmd_res not in [1, 2]:
                        msglogr.debug(f"Exactly one distinct first command found for the alarm {alarm_session.alarmname} iactoken {alarm_session.iactoken}")
                        if isinstance(first_cmd_res, dict):
                            msglogr.debug(f"First command is resolution summary for the alarm {alarm_session.alarmname} iactoken {alarm_session.iactoken}")
                            alarm_session.set_alarmResolutionSummary(first_cmd_res['alarmResolutionSummary'],
                                                                     first_cmd_res['alarmResolutionStatus'])
                            msglogr.debug(
                                f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                            return Response(alarm_session.output_json, status=status.HTTP_200_OK)

                        else:
                            alarm_session.set_mmlcommand(first_cmd_res)
                            alarm_session.set_resolutionStatus_execute_mmlcommand()
                            msglogr.debug(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                            return Response(alarm_session.output_json, status=status.HTTP_200_OK)

                    if first_cmd_res == 1:
                        # if more than one distinct command found for the actual alarmText and they have same count value
                        res_status, cmd_to_excecute, res_dict = ambiguity_check_first_command_query_execution(alarm_session,
                                                                                                      alarm_session.commands_occurences_difference_threshold,
                                                                                                      next_real_cmd)
                        # We should always keep the dict information
                        alarm_session.set_algorithmResponseInfo(res_dict)

                        if res_status == 1:
                            # commands_occurences_difference_threshold was respected. Only one command will be executed
                            msglogr.debug(
                                f"Multiple commands were found, the command with higher occurrences was selected iactoken {alarm_session.iactoken}")
                            if isinstance(cmd_to_excecute, dict):
                                msglogr.debug(
                                    f"First command is resolution summary for the alarm {alarm_session.alarmname} iactoken {alarm_session.iactoken}")
                                alarm_session.set_alarmResolutionSummary(cmd_to_excecute['alarmResolutionSummary'],
                                                                         cmd_to_excecute['alarmResolutionStatus'])

                                msglogr.debug(
                                    f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                                alarm_session.output_json.get('PredictorOutput')
                                msglogr.info(
                                    f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                                return Response(alarm_session.output_json, status=status.HTTP_200_OK)

                            else:
                                alarm_session.set_mmlcommand(cmd_to_excecute)
                                alarm_session.set_resolutionStatus_execute_mmlcommand()

                                msglogr.debug(
                                    f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                                alarm_session.output_json.get('PredictorOutput')
                                msglogr.info(
                                    f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                                return Response(alarm_session.output_json, status=status.HTTP_200_OK)

                        elif res_status == 2:
                            # commands_occurences_difference_threshold was not respected. all commands (in dict) will be proposed to end user
                            alarm_session.set_iacerrordetails(
                                "Multiple records observed at knowledge model matching that scenario. Commands occurrences difference threshold was not respected.")
                            alarm_session.set_iacstatus_ambiguous()
                            alarm_session.set_resolutionStatus_manual_intervention()
                            # "debug": "warning"

                            msglogr.debug(
                                f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                            alarm_session.output_json.get('PredictorOutput')
                            msglogr.info(
                                f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                            return Response(alarm_session.output_json, status=status.HTTP_200_OK)

                    if first_cmd_res == 2:
                        # nothing found on Solr for this alarm and customer
                        alarm_session.set_algorithmResponseInfo(
                            "Alarm path not found")
                        alarm_session.set_resolutionStatus_manual_intervention()
                        msglogr.debug(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                        return Response(alarm_session.output_json, status=status.HTTP_200_OK)

                except Exception as e:
                    alarm_session.set_iacstatus_failed()
                    alarm_session.set_iacerrordetails(str(e))
                    alarm_session.set_debug("error", "Error during first command prediction: " + str(e) + traceback.format_exc())
                    alarm_session.set_resolutionStatus_manual_intervention()
                    msglogr.error(f"{alarm_session.output_json.get('PredictorOutput')}")
                    return Response(alarm_session.output_json, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

                finally:
                    instance.close_connection()
            #  1.1.2 CALCULATE THE NEXT COMMAND
            else:
                #  1.1.2.1 DATA PREPARATION
                try:
                    seq_num = len(alarm_session.cmd_list)
                    generic_cmd_list = alarm_session.command_format_list
                    #generic_cmd_list = [get_generic_cmd(cmd_togeneric_pattern(), x, {}) for x in alarm_session.get_cmd_list()]
                    sequence_str = ' '.join(generic_cmd_list)
                    generic_output = get_generic_output(alarm_session.output, alarm_session.cmd_list[-1],
                                                        alarm_session.additionalfields.update(
                                                        {"alarmname":alarm_session.alarmname,
                                                         "nodename": alarm_session.nodename,
                                                         "nodeid": alarm_session.nodeid,
                                                         "nodeparent": alarm_session.nodeparent}), alarm_session.additionalinfo)
                    alarm_session.set_genericOutput(generic_output)
                    msglogr.debug(f"Generic_output: {generic_output}")
                    set_generic_output = ' newline '.join(sorted(set(generic_output.split(' newline '))))
                    msglogr.debug(f"Set generic_output: {set_generic_output}")
                except Exception as e:
                    alarm_session.set_iacstatus_failed()
                    alarm_session.set_iacerrordetails(str(e))
                    alarm_session.set_debug("error", "data preparation error: " + str(e) + traceback.format_exc())
                    alarm_session.set_resolutionStatus_manual_intervention()
                    msglogr.error(f"{alarm_session.output_json.get('PredictorOutput')}")
                    return Response(alarm_session.output_json, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

                finally:
                    instance.close_connection()
                # CHECK IF A RULE SHOULD BE APPLIED
                try:
                    _rule_res = check_rule(alarm_session.ParserOutput)
                    if _rule_res[0]:
                        alarm_session.set_rules(_rule_res[0])
                        alarm_session.set_rulesResults(_rule_res[1])
                except Exception as e:
                    alarm_session.set_iacstatus_failed()
                    alarm_session.set_iacerrordetails(str(e))
                    alarm_session.set_debug("error", "Rules check error: " + str(e) + traceback.format_exc())
                    alarm_session.set_resolutionStatus_manual_intervention()
                    msglogr.error(f"{alarm_session.output_json.get('PredictorOutput')}")
                    return Response(alarm_session.output_json, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

                # 1.1.2.2 QUERY SOLR TO GET NEXT GENERIC COMMAND VALUE
                try:
                    next_cmd_res, sim_score, next_real_cmd = instance.query_next_cmd_score(alarm_session, seq_num, sequence_str,
                                                                            generic_output, set_generic_output)
                    alarm_session.set_KMmmlcommand(next_real_cmd)
                    if next_cmd_res not in [1, 2]:
                        # if only one distinct command found for the actual alarmText
                        if isinstance(next_cmd_res, dict):
                            alarm_session.set_alarmResolutionSummary(next_cmd_res['alarmResolutionSummary'],
                                                                     next_cmd_res['alarmResolutionStatus'])
                            alarm_session.set_similarity_score(sim_score)
                            msglogr.debug(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                            return Response(alarm_session.output_json, status=status.HTTP_200_OK)

                        else:
                            alarm_session.set_mmlcommand(next_cmd_res)
                            alarm_session.set_similarity_score(sim_score)
                            if alarm_session.similarityThreshold:
                                if sim_score['similarityUI'] > alarm_session.similarityThreshold:
                                    alarm_session.set_resolutionStatus_execute_mmlcommand()
                                else:
                                    alarm_session.set_resolutionStatus_manual_intervention()
                            else:
                                alarm_session.set_resolutionStatus_execute_mmlcommand()
                            msglogr.debug(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                            return Response(alarm_session.output_json, status=status.HTTP_200_OK)

                    if next_cmd_res == 1:
                        # if more than one distinct command found for the actual alarmText and they have same count value
                        res_status, cmd_to_excecute, res_dict = ambiguity_check_next_command_query_execution(alarm_session,
                                                                                                     alarm_session.commands_occurences_difference_threshold,
                                                                                                     sim_score["commands"])
                        # We should always keep the dict information
                        alarm_session.set_algorithmResponseInfo(res_dict)

                        if res_status == 1:
                            # commands_occurences_difference_threshold was respected. Only one command will be executed
                            msglogr.debug(
                                f"Multiple commands were found, the command with higher occurrences was selected iactoken {alarm_session.iactoken}")
                            if isinstance(cmd_to_excecute, dict):
                                # if cmd_to_excecute is a dict
                                alarm_session.set_alarmResolutionSummary(cmd_to_excecute['alarmResolutionSummary'],
                                                                         cmd_to_excecute['alarmResolutionStatus'])
                                msglogr.debug(
                                    f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                                alarm_session.output_json.get('PredictorOutput')
                                msglogr.info(
                                    f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                                return Response(alarm_session.output_json, status=status.HTTP_200_OK)

                            else:
                                # if cmd_to_excecute is a command
                                alarm_session.set_mmlcommand(cmd_to_excecute)
                                alarm_session.set_resolutionStatus_execute_mmlcommand()
                                msglogr.debug(
                                    f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                                alarm_session.output_json.get('PredictorOutput')
                                msglogr.info(
                                    f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                                return Response(alarm_session.output_json, status=status.HTTP_200_OK)


                        elif res_status == 2:
                            # commands_occurrences_difference_threshold was not respected. all commands (in dict) will be proposed to end user
                            alarm_session.set_iacerrordetails(
                                "Multiple records observed at knowledge model matching that scenario. Commands occurrences difference threshold was not respected.")
                            alarm_session.set_iacstatus_ambiguous()
                            alarm_session.set_resolutionStatus_manual_intervention()
                            # "debug": "warning"
                            msglogr.debug(
                                f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                            alarm_session.output_json.get('PredictorOutput')
                            msglogr.info(
                                f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                            return Response(alarm_session.output_json, status=status.HTTP_200_OK)

                    if next_cmd_res == 2:
                        alarm_session.set_algorithmResponseInfo("Resolution path not handled by the system")
                        alarm_session.set_similarity_score(sim_score)
                        alarm_session.set_resolutionStatus_manual_intervention()
                        msglogr.debug(f"Output JSON PredictorOutput: {alarm_session.output_json.get('PredictorOutput')}")
                        return Response(alarm_session.output_json, status=status.HTTP_200_OK)

                except Exception as e:
                    alarm_session.set_iacstatus_failed()
                    alarm_session.set_iacerrordetails(str(e))
                    alarm_session.set_debug("error", "Error during next command prediction: " + str(e) + traceback.format_exc())
                    alarm_session.set_resolutionStatus_manual_intervention()
                    msglogr.error(f"{alarm_session.output_json.get('PredictorOutput')}")
                    return Response(alarm_session.output_json, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

                finally:
                    instance.close_connection()

        except Exception as e:
            alarm_session.set_iacstatus_failed()
            alarm_session.set_iacerrordetails(str(e))
            alarm_session.set_debug("error", "Error in command prediction: " + str(e) + traceback.format_exc())
            alarm_session.set_resolutionStatus_manual_intervention()
            msglogr.error(f"{alarm_session.output_json.get('PredictorOutput')}")
            return Response(alarm_session.output_json, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST', 'GET'])
def async_predictor_api(request):
    msglogr.info("Started async method")
    if request.method == 'GET':
        return Response({'nothing:''nothing to serve for HTTP/GET method -> use POST'},
                        status=status.HTTP_200_OK)
    if request.method == 'POST':
        try:
            # Read from post
            msglogr.debug("Reading incoming data")
            income_data = request.data
            msglogr.debug("Read incoming data")
            # If there JSON data
            # Call worker to process predictive job
            if income_data:
                worker_pool1.submit(get_next_command, income_data)
                msglogr.info('sending response asynch : Predictor process in progress')
                return Response({'debug': 'Predictor process in progress'})
            else:
                response_error = {'debug': 'No input data found'}
                msglogr.error(f"error: {response_error}")
                return Response(response_error,
                                status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        except AttributeError:
            response_error = {'debug': 'error', 'traceback': str(traceback.format_exc())}
            msglogr.error(f"error: {response_error}")
            return Response(response_error,
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)
