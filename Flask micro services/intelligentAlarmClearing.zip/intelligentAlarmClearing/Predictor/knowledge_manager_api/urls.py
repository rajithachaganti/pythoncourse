from django.urls import path

from . import views

urlpatterns = [
    path('index_scenario/', views.v1.async_knowledge_manager_api, name='async_knowledge_manager_api'),
    path('initialize_solr/', views.v1.initialize_solr, name='initialize_solr'),
    path('delete_scenario/', views.v1.delete_scenario, name='delete_scenario')
]