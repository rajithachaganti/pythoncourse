import sys
import os
APP_ROOT = os.path.dirname(os.path.realpath(__file__))
import warnings, traceback
import logging

from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from concurrent.futures import ThreadPoolExecutor
import requests

# Append iac_bundles path to this view
sys.path.append(os.path.abspath(os.path.join(os.path.dirname('__file__'), '..', '..', 'iac_bundles')))

from iac_bundles.iac_bundles.ds_tools.solrIndex import SolrInstance
from iac_bundles.iac_bundles.ds_tools.logsTransform import generate_dataset_context_db
from iac_bundles.iac_bundles.ds_tools.knowledge_manager import get_mandatory_cols, get_iactoken_scenario
from iac_bundles.iac_bundles.ds_tools.logs import iAC_KM_API_MESSAGE_LOGGER_NAME

msglogr = logging.getLogger(iAC_KM_API_MESSAGE_LOGGER_NAME)
msglogr.info(f"Knowledge manager api started")

warnings.filterwarnings("ignore")
json_path = APP_ROOT+ "/"
CONFIG_JSON_PATH = json_path + 'config.json'

worker_pool1 = ThreadPoolExecutor(10)

# Resources/API definition
if os.environ.get('ORCH_KM_FULL_URL'):
    ORCH_KM_RESOURCE_URL = os.environ.get('ORCH_KM_FULL_URL')
    msglogr.info(f"Orhcestrator URL set to {ORCH_KM_RESOURCE_URL}")
else:
    # TODO ENV
    ORCH_KM_RESOURCE_URL = 'http://192.168.0.30:5051/orch/api/km_response'
    msglogr.info(f"Orhcestrator URL set to {ORCH_KM_RESOURCE_URL}")

global GUI_RESOURCE_URL
if os.environ.get('GUI_FULL_URL'):
    GUI_RESOURCE_URL = os.environ.get('GUI_FULL_URL')
    msglogr.info(f"GUI URL set to {GUI_RESOURCE_URL}")
else:
    # TODO ENV
    GUI_RESOURCE_URL = "http://192.168.0.30:5051/gui_services/ctoken"
    msglogr.info(f"GUI URL set to {GUI_RESOURCE_URL}")

global NO_PROXY
NO_PROXY = {"http": None, "https": None,}
NewToken = None

def refresh_rpa_token():
    global NO_PROXY
    global GUI_RESOURCE_URL
    # TODO ENV
    # uname password
    r = requests.post(GUI_RESOURCE_URL, json={"uname":"predictor-app","pass":"iac@!451"}, headers={"Content-Type": "application/json"}, proxies=NO_PROXY)
    if r.status_code == 200:
        msglogr.info(f"Token is, {r.json()['data']['token']}")
        global NewToken
        NewToken=r.json()["data"]["token"]
        return NewToken
    else:
        msglogr.info(f"RPA Token Refresh failed code: {r.status_code} response:{r.content}")
        return None


def post_to_resource(_resource_url, _dict):
    """
    Mai
    :param _resource_url:
    :param _dict:
    :return:
    """
    try:
        msglogr.info(f"JSON to send : {_dict}")
        msglogr.info(f"sending request to {_resource_url}")
        global NO_PROXY
        global NewToken
        if not NewToken:
            NewToken = refresh_rpa_token()
        r = requests.post(_resource_url,headers={"Content-Type": "application/json","token":NewToken}, json=_dict,proxies=NO_PROXY)
        if r.ok:
            msglogr.info(f"Successfully sent json to {_resource_url}, r.ok")
            return True
        elif r.status_code == 401:
            msglogr.info("Status code 401, refreshing token")
            NewToken=refresh_rpa_token()
            if NewToken:
                r = requests.post(_resource_url, headers={"Content-Type": "application/json","token":NewToken}, json=_dict,proxies=NO_PROXY)
                if r.status_code==401:
                    msglogr.info(f"Failed sent json to {_resource_url}, code:{r.status_code}")
                elif r.status_code==200:
                    msglogr.info(f"Successfully sent json to {_resource_url},  code:{r.status_code}")
                else:
                    msglogr.info(f"Failed sent json to {_resource_url},  code:{r.status_code}, response: {r.content}")
            else:
                msglogr.info(f"Failed sent json to {_resource_url}, token refresh failed")

        else:
            msglogr.info(f"Failed sent json to {_resource_url}, code:{r.status_code} , response: {r.content}")
            # msglogr.info(f"Successfully sent json to {_resource_url}, not r.ok")
    except:
        msglogr.error(f'[INTERNAL NETWORK ERROR] check connection '
              f'with this resource {_resource_url} traceback: {traceback.print_exc()}')

    return False


def index_scenario(input_dict: dict):
        try:
            msglogr.debug(f"Index scenario start")
            msglogr.info(f"JSON received : {input_dict}")

            # 0. PARSE JSON
            try:
                iacTockenID_list = input_dict.get('iacTokenID')
                if len(iacTockenID_list) < 1:
                    response_error = {"iactoken" : None, "iacstatus": "Failed", "iacerrordetails": "data in list iacTokenID_list not found"}
                    msglogr.error(f"error: {response_error}")
                    post_to_resource(ORCH_KM_RESOURCE_URL, response_error)
                    return None

            except Exception as e:
                response_error = {"iactoken" : None, "iacstatus": "Failed", "iacerrordetails": "error JSON arguments: " + str(e),
                                  "errorstack": traceback.format_exc()}
                msglogr.error(f"error: {response_error}")
                post_to_resource(ORCH_KM_RESOURCE_URL, response_error)
                return None

            # 1. DATA EXTRACTION
            # 1.2 READ POSTGRES IAC TOKEN DATA FROM CONTEXT DB
            for token in iacTockenID_list:
                try:
                    msglogr.debug(f"Retrieve alarm key columns from alarmkeycolumns table for iactoken: {token}")
                    alarm_key_columns = get_mandatory_cols(_iactoken=token)
                    #alarm_key_columns = [i for i in alarm_key_columns if i.lower() not in ['alarmtext', 'vendortype']]
                    msglogr.info(f"Alarm key columns for {token}: {alarm_key_columns}")
                except Exception as e:
                    response_error = {"iactoken" : token, "iacstatus": "Failed",
                                      "iacerrordetails": "error in retrieving alarm key columns for token " + token + " : " + str(e),
                                      "errorstack": traceback.format_exc()}
                    msglogr.error(f"error: {response_error}")
                    if len(iacTockenID_list) == 1:
                        post_to_resource(ORCH_KM_RESOURCE_URL, response_error)
                        return None

                    else:
                        msglogr.info(f"continue for next token of {token} in the loop")
                        continue
                try:
                    msglogr.info(f"retrieve scenario for token {token} from alarm cycle table joined to alarm info table")
                    res_df = get_iactoken_scenario(token, alarm_key_columns)
                    if isinstance(res_df,str) and res_df=="Failed value in ParserOutput":
                        response_error = {"iactoken" : token, "iacstatus": "Failed",
                                      "iacerrordetails":  "Failed value in ParserOutput found",
                                      "errorstack": "Failed value in ParserOutput found"}
                        msglogr.error(f"error: {response_error}")
                        if len(iacTockenID_list) == 1:
                            post_to_resource(ORCH_KM_RESOURCE_URL, response_error)
                            return None
                        else:
                            continue

                except Exception as e:
                    response_error = {"iactoken" : token, "iacstatus": "Failed",
                                      "iacerrordetails":  "error Postgres in retrieving token " + token + " : " + str(e),
                                      "errorstack": traceback.format_exc()}
                    msglogr.error(f"error: {response_error}")
                    if len(iacTockenID_list) == 1:
                        post_to_resource(ORCH_KM_RESOURCE_URL, response_error)
                        return None
                    else:
                        continue
                try:
                    msglogr.info(f"Generate dataset from ContextDB for token {token} ")
                    logs_dataset = generate_dataset_context_db(res_df, 'mmlcommand', 'mmlcommandoutput')
                    msglogr.debug(f"Generate dataset from ContextDb for token {token} {logs_dataset.head()} ")
                except Exception as e:
                    response_error = {"iactoken" : token, "iacstatus": "Failed",
                                      "iacerrordetails": "error in data preparation: "+ str(e),
                                      "errorstack": traceback.format_exc()}
                    msglogr.error(f"error: {response_error}")
                    post_to_resource(ORCH_KM_RESOURCE_URL, response_error)
                    return None

                try:
                    msglogr.debug(f"Solr instance initialization for token {token}")
                    solr_instance = SolrInstance(CONFIG_JSON_PATH)
                    msglogr.debug(f"Solr instance initialized for token {token}")
                except Exception as e:
                    response_error = {"iactoken" : token, "iacstatus": "Failed",
                                      "iacerrordetails": "error connecting to Solr : "+ str(e),
                                      "errorstack": traceback.format_exc()}
                    msglogr.error(f"error: {response_error}")
                    post_to_resource(ORCH_KM_RESOURCE_URL, response_error)
                    return None

                try:
                    # 2. DATA PREPARATION
                    msglogr.debug(f"Dataset columns for token {token}: {logs_dataset.columns}")
                    msglogr.debug(f"Add column alarm_key_columns for token {token}")

                    # 2.1 ADD COLUMN Alarm_key_columns
                    msglogr.debug(f"Add column alarm_key_columns for token {token}")
                    logs_dataset['alarm_key_columns'] = [alarm_key_columns] * logs_dataset.shape[0]
                    msglogr.debug(f"Dataset columns for token {token}: {logs_dataset.columns}")
                    msglogr.debug(f"Dataset alarm_key_columns column for token {token}: {logs_dataset.alarm_key_columns}")

                    # 2.2 ADD COLUMN solr_filter_field_list
                    msglogr.debug(f"Add column Solr_filter_field_list for token {token}")
                    logs_dataset['solr_filter_field_list'] = logs_dataset.apply(
                        lambda x: [i.lower() + ':\"' + str(x[i.lower()]) + "\"" for i in x.alarm_key_columns], axis=1)
                    msglogr.debug(f"Solr filter field list for token {token}: {logs_dataset['solr_filter_field_list'][0]}")

                    # 2.3 ADD COLUMN dic
                    msglogr.debug(f"Add column dic for token {token}")
                    logs_dataset['dic'] = logs_dataset.apply(lambda x: dict(
                        {"alarmname": x.alarmname, "customer": x.customer, "nodetype": x.nodetype,
                         "nodevendor": x.nodevendor}), axis=1)

                    # 2.4 DROP SCENARIO DUPLICATES
                    duplicates_list = ["nodevendor", "alarmname", "customer", "nodetype", "seq_num",
                                       "sequence_str", "generic_output", "scenario_resolution_summary_string"]
                    msglogr.debug(f"Drop scenario duplicates for token {token} based on: {duplicates_list}")
                    logs_dataset = logs_dataset.drop_duplicates(duplicates_list)


                    # 3 INDEX SCENARIOS STEPS TO SOLR
                    # 3.1 CHECK FIELD EXISTENCE IN THE SOLR SCHEMA
                    msglogr.debug(f"Check field existence for token {token}")
                    fields_check = [solr_instance.check_field_existence(i.lower()) for i in alarm_key_columns]

                    # 3.2 CHECK SCENARIO EXISTENCE IN THE SOLR SCHEMA
                    # 3.2.1 ADD COLUMN scenario_exists
                    msglogr.debug(f"Check scenario existence for token {token}")
                    msglogr.debug(f"Add column scenario_exists for token {token}")
                    if [i for i in fields_check if not i ] :
                        logs_dataset['scenario_exists'] = False
                    else:
                        logs_dataset['scenario_exists'] = logs_dataset.apply(
                            lambda x: solr_instance.check_scenario_exists(
                                x.solr_filter_field_list, x.dic, x.seq_num, x.sequence_str, x.set_generic_output,
                                x.scenario_resolution_summary_string, x.rulesresults_seq, x.initial_rule_result), axis=1)
                    msglogr.debug(f"Check scenario existence dataset for token {token}: {logs_dataset}")

                    # 3.3 FILTER SCENARIO STEPS NOT EXISTING ON SOLR
                    logs_dataset_not_in_solr = logs_dataset[logs_dataset['scenario_exists'] == False]
                    if not logs_dataset_not_in_solr.empty:
                        msglogr.debug(f"Adding scenario steps for token {token}: {logs_dataset_not_in_solr}")

                        # 3.3.1 ADDING NON EXISTING FIELDS OF TYPE STRING TO SOLR SCHEMA
                        for field in alarm_key_columns:
                            if not solr_instance.check_field_existence(field.lower()):
                                msglogr.info(f"Adding field {field} to Solr schema for token {token}")
                                solr_instance.add_string_field(field)  # test over number field (retrieve the successful of the adding

                        # 3.3.2 DROP COLUMNS NOT NEEDED IN INDEXING TO SOLR
                        logs_dataset_not_in_solr = logs_dataset_not_in_solr.drop(
                            ['solr_filter_field_list', 'dic', 'scenario_exists'], 1)

                        # 3.4 INDEX NEW SCENARIO STEPS TO SOLR
                        msglogr.info(f"Indexing scenario steps to Solr for token {token}")
                        solr_instance.index_df(logs_dataset_not_in_solr)
                        msglogr.info(f"Indexing completed for token {token}")
                        solr_instance.reload_core()  # check if predictor will be able to retrieve data during core reloading
                        msglogr.debug(f"Core reloaded for token {token}")

                        response_dict = {"iactoken" : token, "iacstatus": "Success", "iacerrordetails": "Resolution added to Solr successfully"}
                        msglogr.info(f"Output JSON: {response_dict}")
                        post_to_resource(ORCH_KM_RESOURCE_URL, response_dict)
                        return None

                    else:
                        # IF ALL THE SCENARIOS STEPS ARE ALREADY ON SOLR
                        response_dict = {"iactoken" : token, "iacstatus": "Success", "iacerrordetails": "Scenario already on Solr"}
                        msglogr.info(f"Output JSON: {response_dict}")
                        post_to_resource(ORCH_KM_RESOURCE_URL, response_dict)
                        return None

                except Exception as e:
                    response_error = {"iactoken" : token, "iacstatus": "Failed",
                                      "iacerrordetails":  " indexing data on Solr for tokens " + " ".join(iacTockenID_list) + " : " + str(e),
                                      "errorstack": traceback.format_exc()}
                    msglogr.error(f"error: {response_error}")
                    post_to_resource(ORCH_KM_RESOURCE_URL, response_error)
                    return None

                finally:
                    if 'solr_instance' in locals():
                        msglogr.info("Finally closing Solr connection")
                        solr_instance.close_connection()

        except Exception as e:
            response_error = {"iactoken" : None, "iacstatus": "Failed", "iacerrordetails":  str(e),
                              "errorstack": traceback.format_exc()}
            msglogr.error(f"error: {response_error}")
            post_to_resource(ORCH_KM_RESOURCE_URL, response_error)
            return None


@api_view(['GET'])
def initialize_solr(request):
    msglogr.debug("START initializing Solr")
    if request.method == 'GET':
        try:
            # TODO ENV
            solr_instance = SolrInstance(CONFIG_JSON_PATH)
            msglogr.info(f"Initialize Solr instance: "
                         f"HOST={solr_instance.host}, "
                         f"PORT={solr_instance.port}, "
                         f"CORE={solr_instance.core}, "
                         f"AVA={solr_instance.ava}, "
                         f"CHUNK SIZE={solr_instance.chunk_size}, "
                         f"CORE TYPE={solr_instance.coretype}")
            msglogr.info(f"Creating {solr_instance.core}")
            if solr_instance.coretype=="collections":
                status_create = solr_instance.create_collection(solr_instance.core)
                msglogr.info(f"Creating collection. Collection name: {solr_instance.core}")
            else:
                status_create = solr_instance.create_core(solr_instance.core)
                msglogr.info(f"Creating core. Core name: {solr_instance.core}")
            msglogr.info(f"Creating collection {solr_instance.core}: status response = {status_create}")
            if status_create !=0:
                response_error = {"error": 'fatal error: collection not created'}
                msglogr.error(f"error: {response_error}")
                return Response(response_error, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            msglogr.debug(f"start reloading collection {solr_instance.core}")
            solr_instance.reload_core()
            solr_instance.check_allow_stream_property()
            msglogr.debug("add iac text field")
            solr_instance.add_iac_text_field()
            msglogr.debug("replace_iac_text_field")
            solr_instance.replace_iac_text_field()
            msglogr.debug("check update schema")
            solr_instance.check_update_default_schema(CONFIG_JSON_PATH)
            #msglogr.debug("add iac copy fields for generic_output to generic_output_str")
            #solr_instance.add_copy_generic_output_field()
            msglogr.debug("add iac copy fields for set_generic_output to set_generic_output_str")
            solr_instance.add_copy_set_generic_output_field()
            msglogr.info(f"close connection after creation of collection {solr_instance.core}")
            solr_instance.close_connection()
            response_dict = {"status": "Solr inizialization done"}
            msglogr.info(f"Output JSON : {response_dict}")
            return Response(response_dict, status=status.HTTP_200_OK)
        except Exception as e:
            response_error = {"error": str(e)}
            msglogr.error(f"error: {response_error}")
            return Response(response_error, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        finally:
            if 'solr_instance' in locals():
                msglogr.info("Finally closing Solr connection")
                solr_instance.close_connection()


@api_view(['POST', 'GET'])
def delete_scenario(request):
    if request.method == 'GET':
        return Response({'nothing:''nothing to serve for HTTP/GET method -> use POST'},
                        status=status.HTTP_200_OK)
    if request.method == 'POST':
        try:
            msglogr.debug("Reading incoming data")
            income_data = request.data
            msglogr.info(f"INPUT DATA: {income_data}")
            msglogr.debug("Read incoming data, iacTokenID")
            iactoken = income_data.get("iacTokenID")
        except Exception as e:
            response_error = {"iactoken" : None, "iacstatus": "Failed", "iacerrordetails":  str(e),
                              "errorstack": traceback.format_exc()}
            msglogr.error(f"error: {response_error}")
            return Response(response_error, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        try:
            solr_instance = SolrInstance(CONFIG_JSON_PATH)
            msglogr.debug(f"sending request to Solr to remove data related to iactoken: {iactoken}")
            solr_response = solr_instance.delete_scenario(iactoken)
            msglogr.info(f"Solr response for deleting {iactoken}: {solr_response}")
            msglogr.debug("Solr close connection")
            solr_instance.close_connection()
            msglogr.info("Solr connection closed")
            if solr_response == "0":
                response_dict = {"iactoken" : iactoken, "iacstatus": "Success", "iacerrordetails":  "Scenario successfully deleted"}
                msglogr.info(f"Output JSON : {response_dict}")
                return Response(response_dict, status=status.HTTP_200_OK)
            else:
                response_dict = {"iactoken": iactoken, "iacstatus": "Failed", "iacerrordetails": "Scenario not deleted. Response from Solr: "+str(solr_response)}
                msglogr.info(f"Output JSON : {response_dict}")
                return Response(response_dict,
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        except Exception as e:
            response_error = {"iactoken" : iactoken, "iacstatus": "Failed", "iacerrordetails":  str(e),
                              "errorstack": traceback.format_exc()}
            msglogr.error(f"error: {response_error}")
            return Response(response_error, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        finally:
            if 'solr_instance' in locals():
                msglogr.debug("Closing Solr connection")
                solr_instance.close_connection()
                msglogr.info("Finally close Solr connection")


@api_view(['POST', 'GET'])
def async_knowledge_manager_api(request):
    msglogr.info("Started async method")
    if request.method == 'GET':
        return Response({'nothing:''nothing to serve for HTTP/GET method -> use POST'},
                        status=status.HTTP_200_OK)
    if request.method == 'POST':
        try:
            # Read from post
            msglogr.debug("Reading incoming data")
            income_data = request.data
            msglogr.debug("Read incoming data")
            # If there JSON data
            # Call worker to process predictive job
            if income_data:
                worker_pool1.submit(index_scenario, income_data)
                msglogr.info('sending response asynch : Knowledge_manager process in progress')
                return Response({'debug': 'Knowledge_manager process in progress'})
            else:
                response_error = {'debug': 'No input data found'}
                msglogr.error(f"error: {response_error}")
                return Response(response_error,
                                status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        except AttributeError:
            response_error = {'debug': 'error', 'traceback': str(traceback.format_exc())}
            msglogr.error(f"error: {response_error}")
            return Response(response_error,
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)