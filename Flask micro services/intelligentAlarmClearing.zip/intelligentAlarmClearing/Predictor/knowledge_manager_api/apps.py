from django.apps import AppConfig


class KnowledgeManagerApiConfig(AppConfig):
    name = 'knowledge_manager_api'
