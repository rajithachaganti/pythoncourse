# Database helper module
# Author Vigneswaran Shanmugathas
# mail : vigneswaran.shanmugathas.ext@nokia.com

from functools import reduce  # forward compatibility for Python 3
import operator
import json
from common import iacexceptions
from django.db.models.base import ModelBase

def get_parser_rule(_model: ModelBase,
                   _customer: str,
                   _alarmname: str,
                   _commandname: str) :
    """
    Helper to get regex pattern from database
    :param _vendor:
    :param _alarm_text:
    :param _commandname:
    :param _model:
    :return:
    """
    _filter = {
        '_predictor_raw_output': _commandname,
        '_alarmname': _alarmname,
        '_customer': _customer
    }

    r = _model.objects \
        .filter(customer__iexact=_customer) \
        .filter(alarmname__iexact=_alarmname) \
        .filter(commandname__iexact=_commandname)

    print ('Value of r is ', r)
    if r.exists():
        prsrtyp = r[0].parserpath

        prsrrule = r[0].parserrule
        if isinstance(prsrrule, str) :
           prsrrule =  json.loads(r[0].parserrule)

        prstout = r[0].parseroutput
        if isinstance(prstout, str) :
           prstout =    json.loads(r[0].parseroutput)

        return prsrtyp, prsrrule, prstout
    elif _commandname == _alarmname+"_"+"First_Parser":
        return None,None,None
    else:
        raise iacexceptions.UnableToFindParserRules('Unable to find parser rules ',
                                               'Check filter criteria : {}'.format(_filter))


def get_substitutor_rule(_model: ModelBase,
                   _customer: str,
                   _alarmname: str,
                   _commandname: str) :
    _filter = {
        '_commandname': _commandname,
        '_alarmname': _alarmname,
        '_customer': _customer
    }

    r = _model.objects \
        .filter(customer__iexact=_customer) \
        .filter(alarmname__iexact=_alarmname) \
        .filter(commandname__iexact=_commandname)

    print ('Value of r is ', r)
    if r.exists():
        rulecode = r[0].rulecode
        if isinstance(rulecode, str) :
           rulecode =    json.loads(r[0].rulecode)

        return rulecode, r[0].commandformat
    else:
        return None, None

def get_staticfiledata(_model: ModelBase,
                   _filename: str) :
    _filter = {
        '_filename': _filename
    }

    r = _model.objects \
        .filter(filename__iexact=_filename)

    print ('Value of r is ', r)
    if r.exists():
        filecolumns = r[0].filecolumns
        filedata = r[0].filedata
        return filecolumns, filedata
    else:
        return None, None

def get_rs_substitutor_rule(_model: ModelBase,
                   _customer: str,
                   _alarmname: str,
                   _rsname: str) :
    _filter = {
        '_rsname': _rsname,
        '_alarmname': _alarmname,
        '_customer': _customer
    }

    r = _model.objects \
        .filter(customer__iexact=_customer) \
        .filter(alarmname__iexact=_alarmname) \
        .filter(rsname__iexact=_rsname)

    print ('Value of r is ', r)
    if r.exists():
        rulecode = r[0].rulecode
        if isinstance(rulecode, str) :
           rulecode =   json.loads(r[0].rulecode)

        return rulecode, r[0].rsformat
    else:
        return None, None


def get_from_dict(_data_dict: dict, _map_list: list):
    """
    Get value from key value from map list
    source : https://stackoverflow.com/questions/14692690/access-nested-dictionary-items-via-a-list-of-keys
    :param _data_dict:
    :param _map_list:
    :return:
    """
    try:
        if "History" in _map_list:
            for key in _map_list:
                if isinstance(_data_dict[key], list):
                    _data_dict = _data_dict[key][-1]
                else:
                    _data_dict = _data_dict[key]
            return _data_dict
        else:
            return reduce(operator.getitem, _map_list, _data_dict)
    except:
        return None

