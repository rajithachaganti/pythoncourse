import regex as re
from django.db.models.base import ModelBase
from common import iacexceptions


def get_last_executed_command(_input_data: dict):
    """
    Get last command name from input data
    :param _input_data:
    :return:
    """
    try:
        last_cmd = _input_data.get("History").get("command_list")[-1]
    except IndexError:
        last_cmd = None
    except AttributeError:
        last_cmd = None
    except TypeError:
        last_cmd = None

    return last_cmd


def get_last_executed_commandname(_input_data: dict):
    """
    Get last command name from input data
    :param _input_data:
    :return:
    """
    try:
        last_cmd = _input_data.get("History").get("commandname_list")[-1]
    except IndexError:
        last_cmd = None
    except AttributeError:
        last_cmd = None
    except TypeError:
        last_cmd = None

    return last_cmd

def get_last_command_output(_input_data: dict, _filter: bool = True):
    """
    Get last executed command output from input data
    :param _filter:
    :param _input_data:
    :return:
    """

    # Fetch last command output
    try:
        last_cmd_output = _input_data.get("History").get("output_list")[-1]
    except IndexError:
        last_cmd_output = None
    except AttributeError:
        last_cmd_output = None
    except TypeError:
        last_cmd_output = None

    if last_cmd_output:

        if _filter:
            # route to good filter for vendor type
            # if vendor type is Nokia
            if get_vendor_type(_input_data) == 'nokia':
                re_filter = r'LOADING\sPROGRAM\s*([A-Z0-9\.\-\s\w\n\W]*)'
            # If vendor type is Ericsson
            elif get_vendor_type(_input_data) == 'ericsson':
                # TODO ericsson filter
                re_filter = 'some ericsson filter'
            # If vendor type not exist, do not apply filter
            # return last command output
            else:
                return last_cmd_output

            try:
                filtred = str(list(filter(None, re.findall(re_filter, last_cmd_output)))[0])
                last_cmd_output = f'LOADING PROGRAM {filtred}'
            except IndexError:
                return last_cmd_output

        return last_cmd_output

    else:
        return last_cmd_output


def get_bcf_id(_input_data: dict):
    """

    :param _input_data:
    :return:
    """
    return _input_data.get('NodeID')


def get_vendor_type(_input_data: dict):
    """

    :param _input_data:
    :return:
    """
    return _input_data.get('NodeVendor').lower()


def get_customer_name(_input_data: dict):
    """

    :param _input_data:
    :return:
    """
    return _input_data.get('Customer')


def get_alarm_text(_input_data: dict):
    """

    :param _input_data:
    :return:
    """
    return _input_data.get('AlarmName')


def get_cmd_from_user(_input_dict: dict):
    """

    :param _input_dict:
    :return:
    """
    return _input_dict.get('UserProposed').get('command')


def get_cmdname_from_user(_input_dict: dict):
    """

    :param _input_dict:
    :return:
    """
    return _input_dict.get('UserProposed').get('commandname')


def get_process_values(_input_dict: dict):
    """
    Check if needed values are not None

    :param _input_dict:
    :return:
    """
    last_cmd: str = get_last_executed_command(_input_dict)
    last_cmd_output: str = get_last_command_output(_input_dict)
    vendor_type: str = get_vendor_type(_input_dict)
    alarm_text: str = get_alarm_text(_input_dict)
    bcf_id: str = get_bcf_id(_input_dict)

    if last_cmd and \
            last_cmd_output and \
            vendor_type and \
            alarm_text:

        return {
            'last_cmd': last_cmd,
            'last_cmd_output': last_cmd_output,
            'vendor_type': vendor_type,
            'alarm_text': alarm_text,
            'bcf_id': bcf_id
        }

    else:
        print({
            'last_cmd': last_cmd,
            'last_cmd_output': last_cmd_output,
            'vendor_type': vendor_type,
            'alarm_text': alarm_text,
            'bcf_id': bcf_id
        })
        raise Exception('values checks failed, can not get all mandatory values')


def get_last_exe_cmd_pattern(_command_list_model: ModelBase, _last_cmd: str):
    """
    Find executed command regex pattern from
    From last executed command,
    :param _command_list_model:
    :param _last_cmd:
    :return:
    """
    found_pattern: str

    # Get last executed command regex pattern
    for i in _command_list_model.objects.all():
        if re.search(pattern=i.name, string=_last_cmd):
            found_pattern = i.name

    if found_pattern:
        return found_pattern
    else:
        raise iacexceptions.UnknownCommandPatternError('unable to find last used command',
                                             'last_cmd: {}'.format(_last_cmd))
