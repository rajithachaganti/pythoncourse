import requests, json, traceback
from concurrent.futures import ThreadPoolExecutor

iAC_PARSER_MESSAGE_LOGGER_NAME = 'iACPrsrMsgLog'
iAC_SUBS_MESSAGE_LOGGER_NAME   = 'iACSubsMsgLog'

ignoreproxies = {
  "http": None,
  "https": None,
}

# +-----------------------------------------+
# | concurrent.futures worker pools def     |
# +-----------------------------------------+
# Pool for session
prsr_subs_worker_pool = ThreadPoolExecutor(max_workers=20)




def get_object(name):
    """Retrieve a python object, given its dotted.name."""
    obj = name
    if obj:
        try:
            parts = name.split('.')
            parts_copy = parts[:]
            while parts_copy:
                try:
                    module = __import__('.'.join(parts_copy))
                    break
                except ImportError:
                    del parts_copy[-1]
                    if not parts_copy: raise
            parts = parts[1:]

            obj = module
            for part in parts:
                parent, obj = obj, getattr(obj, part)
        except:
            print(f"Error while coverting python {name} to object")
            obj = None

    return obj

def post_to_resource(_resource_url, _dict):
    """
    Mai
    :param _resource_url:
    :param _dict:
    :return:
    """
    try:
        r = requests.post(_resource_url, json=_dict, proxies=ignoreproxies)
        if r.ok:
            print("Successfully sent json to {}".format(_resource_url))
            return True
        else:
            print("Failed to send json {} to {} status {} and response {}".format(_dict,
                    _resource_url, r.status_code, r.content))
    except:
        print(f'[INTERNAL NETWORK ERROR] check connection '
              f'with this resource {_resource_url}')
        traceback.print_exc()

    return False



