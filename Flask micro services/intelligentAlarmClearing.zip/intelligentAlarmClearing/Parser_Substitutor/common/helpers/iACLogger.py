import logging
import logging.handlers


iAC_MESSAGE_LOGGER_NAME = 'iACPrsrMsgLog'
iAC_ERROR_LOGGER_NAME = 'iACPrsrErrLog'

iAC_MESSAGE_LOG_FILENAME = 'iACMsgLog.txt'
iAC_ERROR_LOG_FILENAME = 'iACErrLog.txt'

iAC_MESSAGE_LOG_FILE_SIZE = 2147483648
iAC_ERROR_LOG_FILE_SIZE = 2147483648

iAC_MESSAGE_FILE_BACKUP_COUNT = 5
iAC_ERROR_FILE_BACKUP_COUNT = 5


global iacMsgLgr, iacErrLgr

def init_logger():

    logger = logging.getLogger(iAC_MESSAGE_LOGGER_NAME)
    logger.setLevel(logging.DEBUG)

    scrnLgr = logging.StreamHandler()
    scrnLgr.setLevel(logging.DEBUG)

    # Add the log message handler to the logger
    filehandler = logging.handlers.RotatingFileHandler(
        iAC_MESSAGE_LOG_FILENAME, maxBytes=iAC_MESSAGE_LOG_FILE_SIZE, backupCount=iAC_MESSAGE_FILE_BACKUP_COUNT)

    formatter = logging.Formatter(
        '%(asctime)s.%(msecs)03d | %(levelname)s | %(filename)s | %(funcName)s | %(thread)d | %(message)s',
        "%d-%b-%Y %H:%M:%S")
    formatter.default_msec_format = '%s.%03d'
    scrnLgr.setFormatter(formatter)
    filehandler.setFormatter(formatter)

    logger.addHandler(scrnLgr)
    logger.addHandler(filehandler)

