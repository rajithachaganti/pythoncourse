from django.shortcuts import render
import csv, io,json,os
from django.contrib import messages
from .models import StaticFileData
from os import path


# Create your views here.
def check_delimiter(delimiter: list,text: str):
    for delim in delimiter:
        if delim in text:
            return delim

def ConvertToJSON(input_data: str):
    line_data = input_data.split("\r\n")
    data = []
    delimiter = check_delimiter([",", "|", "\t", " ",";"], line_data[0])
    fieldnames = line_data[0].split(delimiter)
    for line in line_data:
        if line != line_data[0]:
            sp = line.split(delimiter)
            data.append(dict(zip(fieldnames, sp)))
    return data,fieldnames


def upload_csv(request):
    template = "upload_csv.html"
    prompt = {
        'rule' : 'please upload your csv'
    }
    if request.method == "GET":
        return render(request,template,prompt)
    csv_file = request.FILES['file']

    if not csv_file.name.endswith('.csv'):
        messages.error(request, 'Please upload csv file only')
        return render(request,template,prompt)
    else:
        file_data = csv_file.read().decode("utf-8")
        jsondata,fieldnames = ConvertToJSON(file_data)
        _,created = StaticFileData.objects.update_or_create(
            filename = os.path.splitext(str(csv_file))[0],
            filecolumns = fieldnames,
            filedata = jsondata
        )
        context = {}
        messages.info(request, 'File uploaded successfully')
        return render(request,template,context)




