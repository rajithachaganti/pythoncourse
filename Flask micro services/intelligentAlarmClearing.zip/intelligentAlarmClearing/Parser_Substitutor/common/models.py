from django.db import models
from django.contrib import admin
from django.contrib.postgres.fields import JSONField
from django.contrib.postgres.fields import ArrayField
from django.core.exceptions import ValidationError
from ckeditor.fields import RichTextField
from common.helpers.validate import ConfValidator

validate_json = None
def json_validator(value):
    """
    invoke json_validator to check keys, etc ... before insert JSON configuration
    :param value:
    :return:
    """
    if not validate_json.validate(value):
        raise ValidationError('Input Json contain some key error. Read documentation please',
                              params={'config': value},
                              )


class  ParserTypes(models.Model):
    class Meta:
        db_table = 'parsertypes'
        managed = False
        verbose_name_plural = "Parser types"

    typeid      = models.AutoField(primary_key=True, db_column='typeid')
    typename    = models.CharField(max_length=128, unique=True, blank=False, null=False)
    parserpath  = models.CharField(max_length=128, blank=False, null=False)
    description = RichTextField(blank=True, null=True)
    customer    = models.CharField(max_length=32, blank=False, null=False)

    def __str__(self):
        return '{}'.format(self.typename)


class  ParserRules(models.Model):
    class Meta:
        db_table = 'parserrules'
        managed = False
        verbose_name_plural = "Parser rules"

    parserid      = models.AutoField(primary_key=True, db_column='parserid')
    parsername    = models.CharField(max_length=128, unique=True, blank=False, null=False)
    typeid        = models.ForeignKey(ParserTypes, on_delete=models.SET_NULL, blank=True,null=True, db_column='typeid', help_text='select the parser type')
    parserrule    = JSONField(blank=False, null=False)
    parseroutput  = JSONField(blank=False, null=False)
    description   = RichTextField(blank=True, null=True)
    customer      = models.CharField(max_length=32, blank=False, null=False)

    def __str__(self):
        return '{}'.format(self.parsername)


class  SubstitutorRules(models.Model):
    class Meta:
        db_table = 'substitutorrules'
        managed = False
        verbose_name_plural = "Substitutor rules"

    ruleid      = models.AutoField(primary_key=True, db_column='ruleid')
    rulename    = models.CharField(max_length=128, unique=True, blank=False, null=False)
    rulecode    = JSONField(blank=False, null=False, validators=[json_validator])
    description = RichTextField(blank=True, null=True)
    customer    = models.CharField(max_length=32, blank=False, null=False)

    def __str__(self):
        return '{}'.format(self.rulename)



class  CommandDictionary(models.Model):
    class Meta:
        db_table = 'commanddictionary'
        managed = False
        verbose_name_plural = "Command dictionary"

    cmdid           = models.AutoField(db_column='cmdid', primary_key=True)
    commandname     = models.CharField(max_length=128, unique=True, blank=False, null=False)
    displayname     = models.CharField(max_length=256, blank=False, null=False)
    commandformat   = models.CharField(max_length=128, blank=False, null=False)
    nodevendor      = models.CharField(max_length=32, blank=True, null=True)
    nodetype        = models.CharField(max_length=32, blank=True, null=True)
    nodeversion     = models.CharField(max_length=16, blank=True, null=True)
    criticalcommand = models.BooleanField(default=False)
    ruleid          =  models.ForeignKey(SubstitutorRules, on_delete=models.SET_NULL, blank=True,null=True, db_column='ruleid', help_text='select the substitutor rule')
    parserid        =  models.ForeignKey(ParserRules, on_delete=models.SET_NULL, blank=True,null=True, db_column='parserid', help_text='select the parser rule')
    customer        = models.CharField(max_length=32, blank=False, null=False)

    def __str__(self):
        return '{}'.format(self.commandname)


class  ResolutionSummary(models.Model):
    class Meta:
        db_table = 'resolutionsummary'
        managed = False
        verbose_name_plural = "Resolution summary"

    rsid            = models.AutoField(db_column='rsid', primary_key=True)
    rsname          = models.CharField(max_length=128, unique=True, blank=False, null=False)
    displayname     = models.CharField(max_length=256, blank=False, null=False)
    rsformat        = models.CharField(max_length=1024,blank=False, null=False)
    customer        = models.CharField(max_length=32, blank=True, null=True)
    ruleid          = models.ForeignKey(SubstitutorRules, on_delete=models.SET_NULL, blank=True,null=True, db_column='ruleid', help_text='select the substitutor rule')

    def __str__(self):
        return '{}'.format(self.rsname)

class  StaticFileData(models.Model):
    class Meta:
        db_table = 'staticfiledata'
        managed = False
        verbose_name_plural = "Static File Data"

    fileid          = models.AutoField(db_column='fileid', primary_key=True)
    filename        = models.CharField(max_length=128, unique=True, blank=False, null=False)
    filecolumns     = models.CharField(max_length=1024,blank=False, null=False)
    filedata        = JSONField(blank=False, null=False)

    def __str__(self):
        return '{}'.format(self.filename)


class  AlarmKeyColumns(models.Model):
    class Meta:
        db_table = 'alarmkeycolumns'
        managed = False
        verbose_name_plural = "Alarm key columns"

    iacalarmid      = models.AutoField(db_column='iacalarmid', primary_key=True)
    customer        = models.CharField(max_length=32, blank=False, null=False)
    nodevendor      = models.CharField(max_length=32, blank=True, null=True)
    nodetype        = models.CharField(max_length=32, blank=True, null=True)
    nodeversion     = models.CharField(max_length=16, blank=True, null=True)
    alarmnumber     = models.CharField(max_length=32, blank=True, null=True)
    alarmname       = models.CharField(max_length=128, blank=False, null=False)
    mandatorycols   = ArrayField(models.CharField(max_length=128), blank=False, null=False)
    enabled         = models.CharField(max_length=10, blank=True, null=True)
    solrsearchcol   = ArrayField(models.CharField(max_length=128), blank=False, null=False)
    technology      = models.CharField(max_length=16, blank=True, null=True)
    executionmode   = models.CharField(max_length=16, blank=False, null=False, default='Training')
    parentid        = models.IntegerField(blank=True, null=True)

    def __str__(self):
        return '{}_{}'.format(self.customer, self.alarmname)

class  AlarmRSMapping(models.Model):
    class Meta:
        db_table = 'alarmrsmapping'
        managed = False
        verbose_name_plural = "Alarm Resolution mapping"

    mapid       = models.AutoField(db_column='mapid', primary_key=True)
    iacalarmid  =  models.ForeignKey(AlarmKeyColumns, on_delete=models.CASCADE, blank=False,null=False, db_column='iacalarmid', help_text='select the Alarm name')
    rsid       = models.ForeignKey(ResolutionSummary, on_delete=models.CASCADE, blank=False,null=False, db_column='rsid', help_text='select the resolution summary name')

class AlarmRSRuleDetails(models.Model):
    class Meta:
        db_table = 'alarmrsruledetails'
        managed = False
        verbose_name_plural = "Alarm Resolution rule details"

    customer        = models.CharField(max_length=32, blank=False, null=False)
    alarmname       = models.CharField(max_length=128, blank=False, null=False)
    enabled         = models.CharField(max_length=10, blank=True, null=True)
    executionmode   = models.CharField(max_length=16, blank=False, null=False, default='Training')
    rsname          = models.CharField(max_length=128, unique=True, blank=False, null=False)
    rsformat        = models.CharField(max_length=128, blank=False, null=False)
    rulename        = models.CharField(max_length=128, unique=True, blank=False, null=False)
    rulecode        = JSONField(blank=False, null=False, validators=[json_validator])
    dataid          = models.AutoField(db_column='dataid', primary_key=True)

    def __str__(self):
        return '{}_{}_{}'.format(self.customer, self.alarmname, self.rsname)


    def get_model_perms(self, request):
        """
        Return empty perms dict thus hiding the model from admin index.
        """
        return {}


class  AlarmCommandMapping(models.Model):
    class Meta:
        db_table = 'alarmcommandmapping'
        managed = False
        verbose_name_plural = "Alarm command mapping"

    mapid       = models.AutoField(db_column='mapid', primary_key=True)
    iacalarmid  =  models.ForeignKey(AlarmKeyColumns, on_delete=models.CASCADE, blank=False,null=False, db_column='iacalarmid', help_text='select the Alarm name')
    cmdid       = models.ForeignKey(CommandDictionary, on_delete=models.CASCADE, blank=False,null=False, db_column='cmdid', help_text='select the command name')


class CommandRuleDetails(models.Model):
    class Meta:
        db_table = 'commandruledetails'
        managed = False
        verbose_name_plural = "Command rule details"

    customer        = models.CharField(max_length=32, blank=False, null=False)
    commandname     = models.CharField(max_length=128, unique=True, blank=False, null=False)
    commandformat   = models.CharField(max_length=128, blank=False, null=False)
    criticalcommand = models.BooleanField(default=False)
    rulename        = models.CharField(max_length=128, unique=True, blank=False, null=False)
    rulecode        = JSONField(blank=False, null=False, validators=[json_validator])
    parsername      = models.CharField(max_length=128, unique=True, blank=False, null=False)
    typename        = models.CharField(max_length=128, unique=True, blank=False, null=False)
    parserpath      = models.CharField(max_length=128, unique=True, blank=False, null=False)
    parserrule      = JSONField(blank=False, null=False)
    parseroutput    = JSONField(blank=False, null=False)
    dataid          = models.AutoField(db_column='dataid', primary_key=True)

    def __str__(self):
        return '{}_{}_{}_{}'.format(self.customer, self.commandname, self.rulename, self.parsername)


    def get_model_perms(self, request):
        """
        Return empty perms dict thus hiding the model from admin index.
        """
        return {}


class AlarmCommandRuleDetails(models.Model):
    class Meta:
        db_table = 'alarmcommandruledetails'
        managed = False
        verbose_name_plural = "Alarm command rule details"

    customer        = models.CharField(max_length=32, blank=False, null=False)
    alarmname       = models.CharField(max_length=128, blank=False, null=False)
    enabled         = models.CharField(max_length=10, blank=True, null=True)
    executionmode   = models.CharField(max_length=16, blank=False, null=False, default='Training')
    commandname     = models.CharField(max_length=128, unique=True, blank=False, null=False)
    commandformat   = models.CharField(max_length=128, blank=False, null=False)
    criticalcommand = models.BooleanField(default=False)
    rulename        = models.CharField(max_length=128, unique=True, blank=False, null=False)
    rulecode        = JSONField(blank=False, null=False, validators=[json_validator])
    parsername      = models.CharField(max_length=128, unique=True, blank=False, null=False)
    typename        = models.CharField(max_length=128, unique=True, blank=False, null=False)
    parserpath      = models.CharField(max_length=128, unique=True, blank=False, null=False)
    parserrule      = JSONField(blank=False, null=False)
    parseroutput    = JSONField(blank=False, null=False)
    dataid          = models.AutoField(db_column='dataid', primary_key=True)

    def __str__(self):
        return '{}_{}_{}'.format(self.customer, self.alarmname, self.commandname)



    def get_model_perms(self, request):
        """
        Return empty perms dict thus hiding the model from admin index.
        """
        return {}



validate_json = ConfValidator(CommandRuleDetails)

