import re, json,ast

def parseMML(mmlCmdOp, cmdRegExp):
    keyVals = {}
    for mo in re.finditer(cmdRegExp, mmlCmdOp, re.M):
        kind = mo.lastgroup
        value = mo.group(kind)
        #keyVals[kind] = value
        keyVals[kind] = "value found"
        print(kind, "\t --- ", value)
    if (len(keyVals) != 0) and (mo.groupdict() != keyVals):
        comp_ = list(set(mo.groupdict().keys()) ^ (set(keyVals.keys())))
        print("comp {}".format(comp_))
        for kind in comp_:
            keyVals[kind] = "value not found"
    return keyVals


def generateOutput(outputformat, outputVals):
    print ("Type1 ", type(outputformat))
    print("outfmt ", outputformat)
    replaceStr=str(outputformat)
    print ('Type2 ', type(replaceStr))
    if len(outputVals)!= 0:
        for fmtkey in outputVals.keys():
            replace_key =  "param_{}".format(fmtkey)
            replace_val = outputVals[fmtkey]
            print("key {}".format(replace_key))
            print("value {}".format(replace_val))
            replaceStr = replaceStr.replace(replace_key, replace_val)
    else:
        for otrkey,otrval in outputformat.items():
            if isinstance(otrval, dict):
                for key, val in otrval.items():
                    if "param_" in val:
                        replace_key = val
                        replace_val = "value not found"
                        replaceStr = replaceStr.replace(replace_key, replace_val)
    print ('rep str ', replaceStr)
    #retJson = json.loads(replaceStr)
    #retJson = yaml.load(replaceStr)
    retJson = ast.literal_eval(replaceStr)
    return retJson




def parseOutputData(_cmdname, _alarmdetails, _parserule, _outputformat):
    cmdOp =  _alarmdetails.get("History").get("output_list")[-1]
    try:
        if 'checkIfValidOutput' in _parserule.keys():
            opCheck = _parserule.get("checkIfValidOutput")
            reg_list = map(re.compile, opCheck)
            match =[]
            for regex in reg_list:
                match.extend(re.findall(regex, cmdOp))
            if match !=[]:
                prsrregex = _parserule.get('RegEx')
                vals = parseMML(cmdOp, prsrregex)
                print("parse result : ", vals)
                outpt = generateOutput(_outputformat, vals)
                print("Parse format : ", outpt)
            else:
                outpt ={}
            return outpt
        else:
            prsrregex = _parserule.get('RegEx')
            vals = parseMML(cmdOp, prsrregex)
            print("parse result : ", vals)
            outpt = generateOutput(_outputformat, vals)
            print("Parse format : ", outpt)
            return outpt
    except:
        outpt = {}
        print("output is blank")
        return outpt
