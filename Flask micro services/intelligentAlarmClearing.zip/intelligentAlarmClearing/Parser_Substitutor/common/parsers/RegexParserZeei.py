import re, json
import itertools

def parseMMLZeei(mmlCmdOp, cmdRegExp):
    keyVals = {}
    i = -1
    Vals=[]
    if isinstance(cmdRegExp,str):
        for mo in re.finditer(cmdRegExp, mmlCmdOp, re.M):
            print ("Type of mo ", mo.groupdict())
            grpDict = mo.groupdict()

            for kind in grpDict.keys():
                if (kind == 'BTSOP') & (grpDict[kind] != None):
                    i = i + 1
                    keyVals[i] =[]
                    keyVals[i].append(grpDict[kind])
                if (kind == 'TRXOP') & (grpDict[kind] != None):
                    keyVals[i].append(grpDict[kind])
        list_ = {}
        list_["OP"] = []
        for index in range(0, len(keyVals)):
            list_["OP"].append(keyVals[index])
        return list_


def generateOutputZeei(outputformat, outputVals):
    retJson = None
    if isinstance(outputformat, str):
        retJson = json.loads(outputformat)
    else:
        retJson = outputformat
    print(retJson)
    for fmtkey in retJson.keys():
        fmtval = retJson[fmtkey]
        print("fmtkey {} and fmtval {} of type ".format(fmtkey, fmtval, type(fmtval)))
        if isinstance(fmtval, dict):
            retJson1 = generateOutputZeei(fmtval, outputVals)
        subsstr = []
        for val in fmtval:
            if (isinstance(val, str)) and (re.search("param_", val)):
                lstdef = val.split('_')
                print("*********Found LIST in {} and list is {}".format(val, lstdef))
                for subsvals in outputVals.keys():
                    if (re.search("^{}".format(lstdef[1]), subsvals)) and (outputVals[subsvals] is not None):
                        subsstr.append(outputVals[subsvals])
                print("result is  {} and join".format(subsstr))
                if (subsstr == []):
                    subsstr.append("value not found")
                retJson[fmtkey] = list(itertools.chain(*subsstr))
            elif (isinstance(val, str)) and (re.search("paramflat_", val)):
                lstdef = val.split('_')
                print("*********Found LIST in {} and list is {}".format(val, lstdef))
                for subsvals in outputVals.keys():
                    if (re.search("^{}".format(lstdef[1]), subsvals)) and (outputVals[subsvals] is not None):
                        subsstr.append(outputVals[subsvals])
                print("result is  {} and join".format(subsstr))
                if (subsstr == []):
                    subsstr.append("value not found")
                retJson[fmtkey] = list(itertools.chain(*subsstr[0]))
    #retJson = yaml.safe_load(replaceStr)
    return retJson


def parseOutputData(_cmdname, _alarmdetails, _parserule, _outputformat):
    cmdOp =  _alarmdetails.get("History").get("output_list")[-1]
    try:
        if 'checkIfValidOutput' in _parserule.keys():
            opCheck = _parserule.get("checkIfValidOutput")
            reg_list = map(re.compile, opCheck)
            match =[]
            for regex in reg_list:
                match.extend(re.findall(regex, cmdOp))
            if match !=[]:
                prsrregex = _parserule.get('RegExZeei')
                vals = parseMMLZeei(cmdOp, prsrregex)
                print("parse result : ", vals)
                outpt = generateOutputZeei(_outputformat, vals)
                print("Parse format : ", outpt)
            else:
                outpt ={}
            return outpt
        else:
            prsrregex = _parserule.get('RegExZeei')
            vals = parseMMLZeei(cmdOp, prsrregex)
            print("parse result : ", vals)
            outpt = generateOutputZeei(_outputformat, vals)
            print("Parse format : ", outpt)
            return outpt
    except:
        outpt = {}
        print("output is blank")
        return outpt

