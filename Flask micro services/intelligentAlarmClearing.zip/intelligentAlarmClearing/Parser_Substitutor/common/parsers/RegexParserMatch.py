import re,json,itertools
from subs_api.mappers.conf_parser import get_cmd_output,get_parser_output

def get_value(_dict,_alarm_dict):
    key = _dict["key"]
    key_value = _alarm_dict.get(key)
    regex_pattern = _dict["regex"]
    val = re.findall(regex_pattern,key_value)[0]
    return val

def get_value_cmd(_dict,_alarm_dict,cmdOp):
    source = _dict['source']
    if _alarm_dict.get('History').get('commandname_list')!=[]:
        cmd_op = get_cmd_output(source,_alarm_dict)
        regex_pattern = _dict["regex"]
        val = re.findall(regex_pattern,cmd_op)[0]
        return val
    else:
        _alarm_dict['History']['commandname_list'].append(source)
        _alarm_dict['History']['output_list'].append(cmdOp)
        cmd_op = get_cmd_output(source, _alarm_dict)
        regex_pattern = _dict["regex"]
        val = re.findall(regex_pattern, cmd_op)[0]
        return val

def get_regex(cmdRegRule,alarm_dict,cmdOp):
    key_list = []
    op_list = []
    key_dict = {}
    for key,val in cmdRegRule.items():
        if isinstance(val,dict):
            if val['source'] == "AlarmData":
                op_value = get_value(val,alarm_dict)
                param_key = key
                key_list.append(param_key)
                op_list.append(op_value)
            elif (val['source'] != "AlarmData") and ("key_map" in val.keys()):
                op_value = get_parser_output(val,alarm_dict)
                param_key = key
                key_list.append(param_key)
                op_list.append(op_value)
            elif(val['source'] != "AlarmData") and("regex" in val.keys()):
                op_value = get_value_cmd(val,alarm_dict,cmdOp)
                param_key = key
                key_list.append(param_key)
                op_list.append(op_value)
        elif key == "RegExMatch":
            for i in range(0,len(key_list)):
                if (key_list[i] in val) & ("param" in val):
                    rep_val = "<param_"+key_list[i]+">"
                    val = val.replace(rep_val,op_list[i])
                else:
                    key_dict[key_list[i]] = op_list[i]
            return val,key_dict

def parseMMLMatch(mmlCmdOp,cmdRegRule,alarm_dict):
    cmdRegExp,key_dict = get_regex(cmdRegRule,alarm_dict,mmlCmdOp)
    #regex_match = re.findall(cmdRegExp,mmlCmdOp)
    print(cmdRegExp)
    keyVals = {}
    i = 0
    try:
        for mo in re.finditer(cmdRegExp, mmlCmdOp, re.M):
            grpDict = mo.groupdict()
            kind = mo.lastgroup
            value = mo.group(kind)
            i = i+1
            for kind in grpDict.keys():
                value = grpDict[kind]
                kind = "{}_{}".format(kind, i)
                if value != None:
                    if ("\n" in value) and ("$" in value):
                        keyVals[kind] = "".join(value.split())
                        print(kind, "\t --- ", value)
                    elif ("\n" in value) and ("$" not in value):
                        keyVals[kind] = " ".join(value.split())
                        print(kind, "\t --- ", value)
                    else:
                        keyVals[kind] = value
        '''
        if (mo.groupdict() != keyVals):
            comp_ = list(set(mo.groupdict().keys()) ^ (set(keyVals.keys())))
            for kind in comp_:
                keyVals[kind] = None
        '''
    except:
        reg_pattern = "\?P<([\w\d]+)>"
        key_values = re.findall(reg_pattern,cmdRegExp)
        for key in key_values:
            keyVals[key] = None
    keyVals.update(key_dict)
    return keyVals

def generateOutputMatch(outputformat, outputVals):
    retJson = None
    if isinstance(outputformat, str):
        retJson = json.loads(outputformat)
    else:
        retJson = outputformat
    print(retJson)
    for fmtkey in retJson.keys():
        fmtval = retJson[fmtkey]
        print("fmtkey {} and fmtval {} of type ".format(fmtkey, fmtval, type(fmtval)))
        if isinstance(fmtval, dict):
            retJson1 = generateOutputMatch(fmtval, outputVals)
        subsstr = []
        for val in fmtval:
            if (isinstance(val, str)) and (re.search("val_", val)):
                lstdef = val.split('_')
                print("*********Found LIST in {} and list is {}".format(val, lstdef))
                for subsvals in outputVals.keys():
                    if (re.search("^{}".format(lstdef[1]), subsvals)) and (outputVals[subsvals] is not None):
                        subsstr.append(outputVals[subsvals])
                print("result is  {} and join".format(subsstr))
                if (subsstr == []):
                    subsstr.append("No Value")
                if (len(subsstr) == 1) & (isinstance(subsstr[0], list)):
                    subsstr = list(itertools.chain(*subsstr))
                retJson[fmtkey] = subsstr
            elif (isinstance(val, str)) and (re.search("param_", val)):
                lstdef = val.split('_')
                print("*********Found LIST in {} and list is {}".format(val, lstdef))
                for subsvals in outputVals.keys():
                    if (re.search("^{}".format(lstdef[1]), subsvals)) and (outputVals[subsvals] is not None):
                        subsstr.append("value found")
                subsstr = list(set(subsstr))
                print("result is  {} and join".format(subsstr))
                if (subsstr == []):
                    subsstr.append("value not found")
                if (len(subsstr) == 1) & (isinstance(subsstr[0], list)):
                    subsstr = list(itertools.chain(*subsstr))
                retJson[fmtkey] = subsstr

    # retJson = yaml.safe_load(replaceStr)
    return retJson


def parseOutputData(_cmdname, _alarmdetails, _parserule, _outputformat):
    cmdOp =  _alarmdetails.get("History").get("output_list")[-1]
    try:
        if 'checkIfValidOutput' in _parserule.keys():
            opCheck = _parserule.get("checkIfValidOutput")
            reg_list = map(re.compile, opCheck)
            match =[]
            for regex in reg_list:
                match.extend(re.findall(regex, cmdOp))
            if match !=[]:
                vals = parseMMLMatch(cmdOp, _parserule,_alarmdetails)
                print("parse result : ", vals)
                outpt = generateOutputMatch(_outputformat, vals)
                print("Parse format : ", outpt)
            else:
                outpt = {}
            return outpt
        else:
            vals = parseMMLMatch(cmdOp, _parserule, _alarmdetails)
            print("parse result : ", vals)
            outpt = generateOutputMatch(_outputformat, vals)
            print("Parse format : ", outpt)
            return outpt
    except:
        outpt={}
        print("output is blank")
        return outpt


