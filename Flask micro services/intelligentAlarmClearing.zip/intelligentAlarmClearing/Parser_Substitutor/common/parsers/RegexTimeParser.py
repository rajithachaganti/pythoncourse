import re, json,itertools,datetime


def parseMMLTime(mmlCmdOp, cmdRegExp):
    val = re.findall(cmdRegExp, mmlCmdOp)
    keyVals = {}
    diff_min = []
    date1 = datetime.datetime.strptime(val[0][0], '%Y-%m-%d %H:%M:%S')
    for i in range(1, len(val)):
        v = [v for v in val[i] if v != ''][0]
        date_ = datetime.datetime.strptime(v, '%Y-%m-%d %H:%M:%S')
        diff = (date1 - date_).total_seconds() / 60
        diff_min.append(int(diff))
    keyVals['TIME'] = diff_min
    return keyVals


def generateOutputTime(outputformat, outputVals):
    retJson = None
    if isinstance(outputformat, str):
        retJson = json.loads(outputformat)
    else:
        retJson = outputformat
    print(retJson)
    for fmtkey in retJson.keys():
        fmtval = retJson[fmtkey]
        print("fmtkey {} and fmtval {} of type ".format(fmtkey, fmtval, type(fmtval)))
        if isinstance(fmtval, dict):
            retJson1 = generateOutputTime(fmtval, outputVals)
        subsstr = []
        for val in fmtval:
            if (isinstance(val, str)) and (re.search("param_", val)):
                lstdef = val.split('_')
                print("*********Found LIST in {} and list is {}".format(val, lstdef))
                for subsvals in outputVals.keys():
                    if (re.search("^{}".format(lstdef[1]), subsvals)) and (outputVals[subsvals] is not None):
                        subsstr.append(outputVals[subsvals])
                print("result is  {} and join".format(subsstr))
                if (subsstr == []):
                    subsstr.append("value not found")
                if (len(subsstr) == 1) & (isinstance(subsstr[0], list)):
                    subsstr = list(itertools.chain(*subsstr))
                retJson[fmtkey] = subsstr
    #retJson = yaml.safe_load(replaceStr)
    return retJson


def parseOutputData(_cmdname, _alarmdetails, _parserule, _outputformat):
    cmdOp =  _alarmdetails.get("History").get("output_list")[-1]
    try:
        if 'checkIfValidOutput' in _parserule.keys():
            opCheck = _parserule.get("checkIfValidOutput")
            reg_list = map(re.compile, opCheck)
            match =[]
            for regex in reg_list:
                match.extend(re.findall(regex, cmdOp))
            if match !=[]:
                prsrregex = _parserule.get('RegExTime')
                vals = parseMMLTime(cmdOp, prsrregex)
                print("parse result : ", vals)
                outpt = generateOutputTime(_outputformat, vals)
                print("Parse format : ", outpt)
            else:
                outpt = {}
            return outpt
        else:
            prsrregex = _parserule.get('RegExTime')
            vals = parseMMLTime(cmdOp, prsrregex)
            print("parse result : ", vals)
            outpt = generateOutputTime(_outputformat, vals)
            print("Parse format : ", outpt)
            return outpt
    except:
        outpt = {}
        print("output is blank")
        return outpt


