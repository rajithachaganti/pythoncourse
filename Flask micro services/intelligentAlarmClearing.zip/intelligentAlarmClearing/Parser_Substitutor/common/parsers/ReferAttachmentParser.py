from common.helpers.db_helper import get_staticfiledata
from common.models import StaticFileData
import re, json,itertools

def parseMMLRefer(mmlCmdOp, cmdRegExp):
    keyVals = {}
    i = 0
    Vals=[]
    for mo in re.finditer(cmdRegExp, mmlCmdOp, re.M):
        print("Type of mo ", mo.groupdict())
        grpDict = mo.groupdict()
        i = i + 1
        for kind in grpDict.keys():
            value = grpDict[kind]
            mykey = "{}_{}".format(kind, i)
            keyVals[mykey] = value
    #            print(mykey, "\t --- ", value)
    return keyVals

def get_staticdata(cmdRegRule,keyVals):
    opVals = {}
    for key,val in cmdRegRule.items():
        if isinstance(val,dict):
            filename: str = val.get("source")
            key_map: list = val.get("key_map")
            match_key: str = key
            force_int: bool = val.get("force_integer")
            regex: str = val.get("regex")
            columns, data = get_staticfiledata(StaticFileData,filename)
            cmpVals = compare_value(columns, data, keyVals, key_map, match_key, force_int, regex)
            opVals.update(cmpVals)
    return opVals

def compare_value(columns,data,keyVals,key_map,match_key,force_int,regex):
    opVals= {}
    if len(keyVals) != 0:
        for key, val in keyVals.items():
            if (re.search(match_key, key)) and (val is not None):
                if force_int:
                    reg_val = int(val)
                else:
                    reg_val = val
        for col in key_map:
            for dict in data:
                if (dict.get(col) != None) and (re.findall(regex,dict.get(col)) != []):
                    if (force_int) and (reg_val == int(re.findall(regex,dict.get(col))[0])):
                        opVals[match_key] = dict.get(col)
                    elif (force_int is False) and (reg_val == re.findall(regex,dict.get(col))[0]):
                        opVals[match_key] = dict.get(col)
                elif match_key not in opVals.keys():
                    opVals[match_key] = None
    else:
        opVals = {}
    return opVals

def get_keyVals(opVals,keyVals):
    myDict = keyVals.copy()
    for keyOp, valOp in opVals.items():
        for key , val in keyVals.items():
            if re.search(keyOp,key):
                del myDict[key]
    opVals.update(myDict)
    return opVals

def generateOutputRefer(outputformat, outputVals):
    retJson = None
    if isinstance(outputformat, str):
        retJson = json.loads(outputformat)
    else:
        retJson = outputformat
    print(retJson)
    for fmtkey in retJson.keys():
        fmtval = retJson[fmtkey]
        print("fmtkey {} and fmtval {} of type ".format(fmtkey, fmtval, type(fmtval)))
        if isinstance(fmtval, dict):
            retJson1 = generateOutputRefer(fmtval, outputVals)
        subsstr = []
        for val in fmtval:
            if (isinstance(val, str)) and (re.search("val_", val)):
                lstdef = val.split('_')
                print("*********Found LIST in {} and list is {}".format(val, lstdef))
                if 'None' in subsstr:
                    subsstr = []
                for subsvals in outputVals.keys():
                    if (re.search("^{}".format(lstdef[1]), subsvals)) and (outputVals[subsvals] is not None):
                        subsstr.append(outputVals[subsvals])
                print("result is  {} and join".format(subsstr))
                if (subsstr == []):
                    subsstr.append("No Value")
                if (len(subsstr) == 1) & (isinstance(subsstr[0], list)):
                    subsstr = list(itertools.chain(*subsstr))
                if re.search("val_SUM",val):
                    subsList = [int(i) for i in subsstr]
                    retJson[fmtkey] = sum(subsList)
                else:
                    retJson[fmtkey] = list(set(subsstr))
            elif (isinstance(val, str)) and (re.search("param_", val)):
                lstdef = val.split('_')
                print("*********Found LIST in {} and list is {}".format(val, lstdef))
                for subsvals in outputVals.keys():
                    if (re.search("^{}".format(lstdef[1]), subsvals)) and (outputVals[subsvals] is not None):
                        subsstr.append("value found")
                subsstr = list(set(subsstr))
                print("result is  {} and join".format(subsstr))
                if (subsstr == []):
                    subsstr.append("value not found")
                if (len(subsstr) == 1) & (isinstance(subsstr[0], list)):
                    subsstr = list(itertools.chain(*subsstr))
                retJson[fmtkey] = list(set(subsstr))

    # retJson = yaml.safe_load(replaceStr)
    return retJson


def parseOutputData(_cmdname, _alarmdetails, _parserule, _outputformat):
    try:
        if 'checkIfValidOutput' in _parserule.keys():
            cmdOp = _alarmdetails.get("History").get("output_list")[-1]
            opCheck = _parserule.get("checkIfValidOutput")
            reg_list = map(re.compile, opCheck)
            match =[]
            for regex in reg_list:
                match.extend(re.findall(regex, cmdOp))
            if match !=[]:
                prsrregex = _parserule.get('RegExRefer')
                vals = parseMMLRefer(cmdOp, prsrregex)
                opVals = get_staticdata(_parserule, vals)
                ruleOp = get_keyVals(opVals, vals)
                outpt = generateOutputRefer(_outputformat, ruleOp)
                print("Parse format : ", outpt)
            else:
                outpt ={}
            return outpt
        elif ('checkIfValidOutput' not in _parserule.keys()) or (_cmdname == _alarmdetails.get("AlarmName")+"_"+"First_Parser"):
            cmdOp = _alarmdetails.get("AdditionalInfo")
            prsrregex = _parserule.get('RegExRefer')
            vals = parseMMLRefer(cmdOp, prsrregex)
            opVals = get_staticdata(_parserule,vals)
            ruleOp = get_keyVals(opVals, vals)
            outpt = generateOutputRefer(_outputformat, ruleOp)
            print("Parse format : ", outpt)
            return outpt
    except:
        outpt = {}
        print("output is blank")
        return outpt

