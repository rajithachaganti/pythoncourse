import re, json,itertools

def parseMMLLoop(mmlCmdOp, cmdRegExp):
    keyVals = {}
    i = 0
    Vals=[]
    if isinstance(cmdRegExp,str):
        for mo in re.finditer(cmdRegExp, mmlCmdOp, re.M):
            print ("Type of mo ", mo.groupdict())
            grpDict = mo.groupdict()
            i = i+1
            for kind in grpDict.keys():
                value = grpDict[kind]
                mykey = "{}_{}".format(kind, i)
                keyVals[mykey] = value
   #            print(mykey, "\t --- ", value)
        return keyVals
    elif isinstance(cmdRegExp, dict):
        print('in')
        for cmd in cmdRegExp.keys():
            for mo in re.finditer(cmdRegExp[cmd], mmlCmdOp, re.M):
                print("Type of mo ", mo.groupdict())
                grpDict = mo.groupdict()
                i = i + 1
                for kind in grpDict.keys():
                    value = grpDict[kind]
                    Vals.append(value)
        op_val =[]
        for value in Vals:
            if "\n" in value:
                value = "".join(value.split())
                op_val.append(value)
            else:
                op_val.append(value)
        keyVals[kind] = op_val
        return keyVals


def generateOutputLoop(outputformat, outputVals):
    retJson = None
    if isinstance(outputformat, str):
        retJson = json.loads(outputformat)
    else:
        retJson = outputformat
    print(retJson)
    for fmtkey in retJson.keys():
        fmtval = retJson[fmtkey]
        print("fmtkey {} and fmtval {} of type ".format(fmtkey, fmtval, type(fmtval)))
        if isinstance(fmtval, dict):
            retJson1 = generateOutputLoop(fmtval, outputVals)
        subsstr = []
        for val in fmtval:
            if (isinstance(val, str)) and (re.search("val_", val)):
                lstdef = val.split('_')
                print("*********Found LIST in {} and list is {}".format(val, lstdef))
                for subsvals in outputVals.keys():
                    if (re.search("^{}".format(lstdef[1]), subsvals)) and (outputVals[subsvals] is not None):
                        subsstr.append(outputVals[subsvals])
                print("result is  {} and join".format(subsstr))
                if (subsstr == []):
                    subsstr.append("No Value")
                if (len(subsstr) == 1) & (isinstance(subsstr[0], list)):
                    subsstr = list(itertools.chain(*subsstr))
                retJson[fmtkey] = list(set(subsstr))
            elif (isinstance(val, str)) and (re.search("param_", val)):
                lstdef = val.split('_')
                print("*********Found LIST in {} and list is {}".format(val, lstdef))
                for subsvals in outputVals.keys():
                    if (re.search("^{}".format(lstdef[1]), subsvals)) and (outputVals[subsvals] is not None):
                        subsstr.append("value found")
                print("result is  {} and join".format(subsstr))
                if (subsstr == []):
                    subsstr.append("value not found")
                if (len(subsstr) == 1) & (isinstance(subsstr[0], list)):
                    subsstr = list(itertools.chain(*subsstr))
                retJson[fmtkey] = list(set(subsstr))
    #retJson = yaml.safe_load(replaceStr)
    return retJson


def parseOutputData(_cmdname, _alarmdetails, _parserule, _outputformat):
    try:
        if 'checkIfValidOutput' in _parserule.keys():
            cmdOp = _alarmdetails.get("History").get("output_list")[-1]
            opCheck = _parserule.get("checkIfValidOutput")
            reg_list = map(re.compile, opCheck)
            match =[]
            for regex in reg_list:
                match.extend(re.findall(regex, cmdOp))
            if match !=[]:
                prsrregex = _parserule.get('RegExLoop')
                vals = parseMMLLoop(cmdOp, prsrregex)
                print("parse result : ", vals)
                outpt = generateOutputLoop(_outputformat, vals)
                print("Parse format : ", outpt)
            else:
                outpt ={}
            return outpt
        elif ('checkIfValidOutput' not in _parserule.keys()) or (_cmdname == _alarmdetails.get("AlarmName")+"_"+"First_Parser"):
            cmdOp = _alarmdetails.get("AdditionalInfo")
            prsrregex = _parserule.get('RegExLoop')
            vals = parseMMLLoop(cmdOp, prsrregex)
            print("parse result : ", vals)
            outpt = generateOutputLoop(_outputformat, vals)
            print("Parse format : ", outpt)
            return outpt
    except:
        outpt = {}
        print("output is blank")
        return outpt

