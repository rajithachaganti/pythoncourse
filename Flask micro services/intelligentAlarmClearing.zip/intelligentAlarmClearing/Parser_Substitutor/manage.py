#!/usr/bin/env python
import os
import sys
import logging
import logging.handlers
from common.helpers.general_helper import iAC_PARSER_MESSAGE_LOGGER_NAME, iAC_SUBS_MESSAGE_LOGGER_NAME


def init_logger(lgrname):
    LOG_FILENAME = lgrname + '.log'

    logger = logging.getLogger(lgrname)
    logger.setLevel(logging.DEBUG)

    scrnLgr = logging.StreamHandler()
    scrnLgr.setLevel(logging.DEBUG)

    # Add the log message handler to the logger
    filehandler = logging.handlers.RotatingFileHandler(
        LOG_FILENAME, maxBytes=2147483648, backupCount=5)

    formatter = logging.Formatter(
        '%(asctime)s.%(msecs)03d | %(levelname)s | %(filename)s | %(funcName)s | %(thread)d | %(message)s',
        "%d-%b-%Y %H:%M:%S")
    formatter.default_msec_format = '%s.%03d'
    scrnLgr.setFormatter(formatter)
    filehandler.setFormatter(formatter)

    logger.addHandler(scrnLgr)
    logger.addHandler(filehandler)


if __name__ == '__main__':
    init_logger(iAC_PARSER_MESSAGE_LOGGER_NAME)
    init_logger(iAC_SUBS_MESSAGE_LOGGER_NAME)

    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'django_dev_iac.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)
