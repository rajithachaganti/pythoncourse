import logging
import regex as re
from common.helpers.general_helper import iAC_SUBS_MESSAGE_LOGGER_NAME, prsr_subs_worker_pool
from common.helpers.db_helper import get_substitutor_rule,get_rs_substitutor_rule
from common.models import AlarmCommandRuleDetails,AlarmRSRuleDetails

from common.helpers.json_helper import get_customer_name, get_alarm_text
from subs_api.mappers.conf_parser import get_param,get_param_dict,get_subval

SUBSTITUTOR_OUTPUT_KEY = 'SubstitutorOutput'
SUBSTITUTOR_OUTPUT_CMD_OUTPUT_KEY = 'mmlCommand'
SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY = 'resolutionSummary'
USER_PROPOSED_KEY = 'UserProposed'
USER_PROPOSED_KEY_CMD_OUTPUT_KEY = 'mmlCommand'
msglogr = logging.getLogger(iAC_SUBS_MESSAGE_LOGGER_NAME)


def subs_cmd(alarm_dict:dict,resolution_status: str,subsiactkn: str):
    try:
        pred_cmd: str = alarm_dict.get('PredictorOutput').get('mmlCommand')
        msglogr.debug(f"Predicted command name for iACToken {subsiactkn} is {pred_cmd}")
        if (pred_cmd is None):
            msglogr.warning(
                f"Predicted MML Command is empty or not available, substitution skipped for iACToken {subsiactkn}")
            alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                'iacerrordetails': 'Predicted MML Command is empty or not available, substitution skipped',
                'iacstatus': 'Success',
                'resolutionStatus': 8,
                SUBSTITUTOR_OUTPUT_CMD_OUTPUT_KEY: None,
                SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None}
        else:
            # Get substitutor configuration from
            # from database, by filtering by customer, alarm text and predicted command
            sub_config, raw_cmd = get_substitutor_rule(AlarmCommandRuleDetails,
                                                       get_customer_name(alarm_dict),
                                                       get_alarm_text(alarm_dict),
                                                       pred_cmd)

            msglogr.debug(f"Substitutor rule {sub_config} for iACToken {subsiactkn} with raw_cmd {raw_cmd}")
            # Get parameter value list
            if sub_config:

                param_list: list = get_param(sub_config, alarm_dict, raw_cmd)

                if None in param_list:
                    msglogr.warning(f"Parameter values not found for substitution rule of iACToken {subsiactkn}")
                    alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                        'iacerrordetails': 'Parameter values not found for substitution rule of iACToken {subsiactkn}',
                        'iacstatus': 'Failed',
                        'resolutionStatus': 8,
                        SUBSTITUTOR_OUTPUT_CMD_OUTPUT_KEY: pred_cmd,
                        SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None}
                elif (re.findall('param', raw_cmd) == []):
                    raw_cmd: str = raw_cmd
                    # Set predicted output, meta data used to substitute, and response
                    alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                        'iacerrordetails': None,
                        'iacstatus': 'Success',
                        'resolutionStatus': resolution_status,
                        SUBSTITUTOR_OUTPUT_CMD_OUTPUT_KEY: raw_cmd,
                        SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None,
                        '_meta':
                            {'sub_config': sub_config,
                             'param_list': param_list,
                             'customer': get_customer_name(alarm_dict),
                             'alarmname': get_alarm_text(alarm_dict),
                             'raw_prediction_cmd': pred_cmd}
                    }
                else:

                    if (len(re.findall('param', raw_cmd)) != len(param_list)) or any(isinstance(i,list) for i in param_list):
                        raw_cmd: str = get_subval(param_list,alarm_dict,raw_cmd)
                    else:
                        for i in range(len(re.findall('param', raw_cmd))):
                            raw_cmd: str = raw_cmd.replace(f'<param{i}>', str(param_list[i]))

                    if raw_cmd is not None:
                        # Set predicted output, meta data used to substitute, and response
                        alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                            'iacerrordetails': None,
                            'iacstatus': 'Success',
                            'resolutionStatus': resolution_status,
                            SUBSTITUTOR_OUTPUT_CMD_OUTPUT_KEY: raw_cmd,
                            SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None,
                            '_meta':
                                {'sub_config': sub_config,
                                 'param_list': param_list,
                                 'customer': get_customer_name(alarm_dict),
                                 'alarmname': get_alarm_text(alarm_dict),
                                 'raw_prediction_cmd': pred_cmd}
                        }
                    else:
                        msglogr.warning(
                            f"all the combinations have been executed for {pred_cmd} for iACToken {subsiactkn}")
                        alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                            'iacerrordetails': 'all the combinations have been executed, try executing next command rather then repeting the same',
                            'iacstatus': 'Failed',
                            'resolutionStatus': 8,
                            USER_PROPOSED_KEY_CMD_OUTPUT_KEY: None,
                            SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None}

            else:
                msglogr.warning(f"Substitution rules not defined for the command {pred_cmd} for iACToken {subsiactkn}")
                alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                    'iacerrordetails': 'Substitution rules not defined for the command ' + pred_cmd,
                    'iacstatus': 'Failed',
                    'resolutionStatus': 8,
                    SUBSTITUTOR_OUTPUT_CMD_OUTPUT_KEY: None,
                    SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None}
    except Exception as e:
        # Set predicted output, meta data used to substitute, and response
        msglogr.error(f"Exception while processing substition rules for iACToken {subsiactkn} \n {traceback.format_exc()}")
        alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
            'iacerrordetails': 'Exception while processing substition rules',
            'iacstatus': 'Failed',
            'resolutionStatus': 8,
            'traceback': f' {e} /// {traceback.format_exc()}',
            SUBSTITUTOR_OUTPUT_CMD_OUTPUT_KEY: None,
            SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None}
    return alarm_dict


def subs_rs(alarm_dict:dict,resolution_status: str,subsiactkn: str):
    try:
        pred_rs: str = alarm_dict.get('PredictorOutput').get('rsname')
        msglogr.debug(f"Predicted Resolution Summary name for iACToken {subsiactkn} is {pred_rs}")
        if (pred_rs is None):
            msglogr.warning(
                f"Predicted Resolution Summary is empty or not available, substitution skipped for iACToken {subsiactkn}")
            alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                'iacerrordetails': 'Predicted Resolution Summary is empty or not available, substitution skipped',
                'iacstatus': 'Success',
                'resolutionStatus': 8,
                SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None,
                SUBSTITUTOR_OUTPUT_CMD_OUTPUT_KEY: None}

        else:
            # Get substitutor configuration from
            # from database, by filtering by customer, alarm text and predicted command
            sub_config, raw_rs = get_rs_substitutor_rule(AlarmRSRuleDetails,
                                                       get_customer_name(alarm_dict),
                                                       get_alarm_text(alarm_dict),
                                                          pred_rs)

            msglogr.debug(f"Substitutor resolution summary rule {sub_config} for iACToken {subsiactkn} with raw_cmd {raw_rs}")
            # Get parameter value list
            if sub_config:
                param_dict: dict = get_param_dict(sub_config, alarm_dict,raw_rs)

                if len(param_dict)==0:
                    msglogr.warning(f"Parameter values not found for substitution rule of iACToken {subsiactkn}")
                    alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                        'iacerrordetails': 'Parameter values not found for substitution rule of iACToken {subsiactkn}',
                        'iacstatus': 'Failed',
                        'resolutionStatus': 8,
                        SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: pred_rs,
                        SUBSTITUTOR_OUTPUT_CMD_OUTPUT_KEY: None}
                elif (re.findall('param', raw_rs) == []):
                    raw_rs: str = raw_rs
                    # Set predicted output, meta data used to substitute, and response
                    alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                        'iacerrordetails': None,
                        'iacstatus': 'Success',
                        'resolutionStatus': resolution_status,
                        SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: raw_rs,
                        SUBSTITUTOR_OUTPUT_CMD_OUTPUT_KEY: None,
                        '_meta':
                            {'sub_config': sub_config,
                             'param_dict': param_dict,
                             'customer': get_customer_name(alarm_dict),
                             'alarmname': get_alarm_text(alarm_dict),
                             'raw_prediction_rs': pred_rs}
                    }
                else:
                    for k, v in param_dict.items():
                        if re.findall('<'+k+'>', raw_rs):
                            raw_rs = raw_rs.replace(f'<'+k+'>', str(v))

                    # Set predicted output, meta data used to substitute, and response
                    alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                        'iacerrordetails': None,
                        'iacstatus': 'Success',
                        'resolutionStatus': resolution_status,
                        SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: raw_rs,
                        SUBSTITUTOR_OUTPUT_CMD_OUTPUT_KEY: None,
                        '_meta':
                            {'sub_config': sub_config,
                             'param_list': param_dict,
                             'customer': get_customer_name(alarm_dict),
                             'alarmname': get_alarm_text(alarm_dict),
                             'raw_prediction_rs': pred_rs}
                    }

            else:
                msglogr.warning(f"Substitution rules not defined for the resolution summary {pred_rs} for iACToken {subsiactkn}")
                alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                    'iacerrordetails': 'Substitution rules not defined for the rs ' + pred_rs,
                    'iacstatus': 'Failed',
                    'resolutionStatus': 8,
                    SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None,
                    SUBSTITUTOR_OUTPUT_CMD_OUTPUT_KEY: None}
    except Exception as e:
        # Set predicted output, meta data used to substitute, and response
        msglogr.error(
            f"Exception while processing substition rules for iACToken {subsiactkn} \n {traceback.format_exc()}")
        alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
            'iacerrordetails': 'Exception while processing substition rules',
            'iacstatus': 'Failed',
            'resolutionStatus': 8,
            'traceback': f' {e} /// {traceback.format_exc()}',
            SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None,
            SUBSTITUTOR_OUTPUT_CMD_OUTPUT_KEY: None}
    return alarm_dict


def subs_cmd_usr(alarm_dict:dict,usriactkn: str):
    try:
        user_cmd = alarm_dict.get('UserProposed').get('commandname')
        msglogr.info(f"User proposed command name is : {user_cmd}")
        usr_cmd_name = user_cmd
        if (user_cmd is None):
            msglogr.warning(
                f"User proposed command is empty or not available, substitution skipped for iACToken {usriactkn}")
            alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                'iacerrordetails': 'User proposed command is empty or not available, substitution skipped',
                'iacstatus': 'Success',
                'resolutionStatus': 8,
                USER_PROPOSED_KEY_CMD_OUTPUT_KEY: None,
                SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None}
        else:
            # get substitutor configuration parser
            sub_config, raw_cmd_usr = get_substitutor_rule(AlarmCommandRuleDetails,
                                                           get_customer_name(alarm_dict),
                                                           get_alarm_text(alarm_dict),
                                                           user_cmd)
            msglogr.info(f"Substitutor rule for iACToken {sub_config} with raw_cmd {raw_cmd_usr}")
            # Get parameter value list
            if sub_config:
                # Get parameter value list
                param_list: list = get_param(sub_config,alarm_dict,raw_cmd_usr)

                if None in param_list:
                    msglogr.warning(f"Parameter values not found for substitution rule of iACToken {usriactkn}")
                    alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                        'iacerrordetails': 'Parameter values not found for substitution rule',
                        'iacstatus': 'Failed',
                        'resolutionStatus': 8,
                        USER_PROPOSED_KEY_CMD_OUTPUT_KEY: user_cmd,
                        SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None}
                elif (re.findall('param', raw_cmd_usr) == []):
                    param_cmd: str = raw_cmd_usr
                    # Set predicted output, meta data used to substitute, and response
                    alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                        'iacerrordetails': None,
                        'iacstatus': 'Success',
                        USER_PROPOSED_KEY_CMD_OUTPUT_KEY: param_cmd,
                        SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None,
                        '_meta':
                            {'sub_config': sub_config,
                             'param_list': param_list,
                             'customer': get_customer_name(alarm_dict),
                             'alarmname': get_alarm_text(alarm_dict),
                             'raw_prediction_cmd': user_cmd}
                    }
                else:
                    msglogr.debug(f"Replacing the values for parameters {raw_cmd_usr}")
                    # Replace all <param0> , <param1> ... by substituted values

                    if (len(re.findall('param', raw_cmd_usr)) != len(param_list)) or any(isinstance(i,list) for i in param_list):
                        param_cmd: str = get_subval(param_list,alarm_dict,raw_cmd_usr)
                    else:
                        param_cmd = raw_cmd_usr
                        for i in range(len(re.findall('param', raw_cmd_usr))):
                            param_cmd: str = param_cmd.replace(f'<param{i}>', str(param_list[i]))
                    if param_cmd is not None:
                        # Set predicted output, meta data used to substitute, and response
                        alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                            'iacerrordetails': None,
                            'iacstatus': 'Success',
                            USER_PROPOSED_KEY_CMD_OUTPUT_KEY: param_cmd,
                            SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None,
                            '_meta':
                                {'sub_config': sub_config,
                                 'param_list': param_list,
                                 'customer': get_customer_name(alarm_dict),
                                 'alarmname': get_alarm_text(alarm_dict),
                                 'raw_prediction_cmd': user_cmd}
                        }
                    else:
                        msglogr.warning(
                            f"all the combinations have been executed for {user_cmd} for iACToken {usriactkn}")
                        alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                            'iacerrordetails': 'all the combinations have been executed, try executing next command rather then repeting the same',
                            'iacstatus': 'Failed',
                            'resolutionStatus': 8,
                            USER_PROPOSED_KEY_CMD_OUTPUT_KEY: None,
                            SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None}
            else:
                msglogr.warning(
                    f"Substitution rules not defined for the command {user_cmd} for iACToken {usriactkn}")
                alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                    'iacerrordetails': 'Substitution rules not defined for the command ',
                    'iacstatus': 'Failed',
                    'resolutionStatus': 8,
                    USER_PROPOSED_KEY_CMD_OUTPUT_KEY: None,
                    SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None}
    except:
        msglogr.error(f"Exception while processing substition rules for iACToken {usriactkn}")
        alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
            'iacerrordetails': 'Exception while processing substition rules',
            'iacstatus': 'Failed',
            'resolutionStatus': 8,
            USER_PROPOSED_KEY_CMD_OUTPUT_KEY: None,
            SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None}
    return alarm_dict


def subs_rs_usr(alarm_dict: dict,usriactkn: str):
    try:
        user_rs = alarm_dict.get('UserProposed').get('rsname')
        msglogr.info(f"User proposed resolution summary name is : {user_rs}")
        usr_rs_name = user_rs
        if (user_rs is None):
            msglogr.warning(
                f"User proposed command is empty or not available, substitution skipped for iACToken {usriactkn}")
            alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                'iacerrordetails': 'User proposed command is empty or not available, substitution skipped',
                'iacstatus': 'Success',
                'resolutionStatus': 8,
                SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None,
                USER_PROPOSED_KEY_CMD_OUTPUT_KEY: None}
        else:
            # get substitutor configuration parser
            sub_config, raw_rs_usr = get_rs_substitutor_rule(AlarmRSRuleDetails,
                                                           get_customer_name(alarm_dict),
                                                           get_alarm_text(alarm_dict),
                                                           user_rs)
            msglogr.info(f"Substitutor rule for iACToken {sub_config} with raw_rs {raw_rs_usr}")
            # Get parameter value list
            if sub_config:
                # Get parameter value list
                param_dict: dict = get_param_dict(sub_config, alarm_dict,raw_rs_usr)
                if len(param_dict) == 0:
                    msglogr.warning(f"Parameter values not found for substitution rule of iACToken {usriactkn}")
                    alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                        'iacerrordetails': 'Parameter values not found for substitution rule',
                        'iacstatus': 'Failed',
                        'resolutionStatus': 8,
                        SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: user_rs,
                        USER_PROPOSED_KEY_CMD_OUTPUT_KEY: None}
                elif (re.findall('param', raw_rs_usr) == []):
                    param_rs: str = raw_rs_usr
                    # Set predicted output, meta data used to substitute, and response
                    alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                        'iacerrordetails': None,
                        'iacstatus': 'Success',
                        SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: param_rs,
                        USER_PROPOSED_KEY_CMD_OUTPUT_KEY: None,
                        '_meta':
                            {'sub_config': sub_config,
                             'param_dict': param_dict,
                             'customer': get_customer_name(alarm_dict),
                             'alarmname': get_alarm_text(alarm_dict),
                             'raw_prediction_rs': user_rs}
                    }
                else:
                    msglogr.debug(f"Replacing the values for parameters {raw_rs_usr}")
                    # Replace all <param0> , <param1> ... by substituted values
                    param_cmd = raw_rs_usr
                    for k, v in param_dict.items():
                        if re.findall('<'+k+'>', param_cmd):
                            param_cmd = param_cmd.replace(f'<'+k+'>', str(v))

                    # Set predicted output, meta data used to substitute, and response
                    alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                        'iacerrordetails': None,
                        'iacstatus': 'Success',
                        SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: param_cmd,
                        USER_PROPOSED_KEY_CMD_OUTPUT_KEY: None,
                        '_meta':
                            {'sub_config': sub_config,
                             'param_list': param_dict,
                             'customer': get_customer_name(alarm_dict),
                             'alarmname': get_alarm_text(alarm_dict),
                             'raw_prediction_rs': user_rs}
                    }
            else:
                msglogr.warning(
                    f"Substitution rules not defined for the command {user_rs} for iACToken {usriactkn}")
                alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
                    'iacerrordetails': 'Substitution rules not defined for the resolution summary ',
                    'iacstatus': 'Failed',
                    'resolutionStatus': 8,
                    SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None,
                    USER_PROPOSED_KEY_CMD_OUTPUT_KEY: None}
    except:
        msglogr.error(
            f"Exception while processing substition rules for iACToken {usriactkn} \n {traceback.format_exc()}")
        alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
            'iacerrordetails': 'Exception while processing substition rules',
            'iacstatus': 'Failed',
            'resolutionStatus': 8,
            'traceback': f' "" /// {traceback.format_exc()}',
            SUBSTITUTOR_OUTPUT_RS_OUTPUT_KEY: None,
            USER_PROPOSED_KEY_CMD_OUTPUT_KEY: None}

    return alarm_dict
