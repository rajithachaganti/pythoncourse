import regex as re

from common.helpers.json_helper import get_last_command_output
from common.helpers.db_helper import get_from_dict
import logging
from common.helpers.general_helper import iAC_SUBS_MESSAGE_LOGGER_NAME
import itertools
from collections import defaultdict

msglogr = logging.getLogger(iAC_SUBS_MESSAGE_LOGGER_NAME)

def set_parameters(_param_list: list, _raw_predicted_cmd: str):
    """
    Replace raw predictor output <param0> ... by contextual(s) parameter(s)
    :param _param_list:
    :param _raw_predicted_cmd:
    :return:
    """
    for i in range(len(re.findall('param', _raw_predicted_cmd))):
        _raw_predicted_cmd: str = _raw_predicted_cmd.replace(f'<param{i}>', str(_param_list[i]))

    return _raw_predicted_cmd


def parse_from_alarmdata(_param_conf: dict, _alarm_dict: dict) -> int:
    """
    Get value from alarm ticket
    :param _alarm_dict:
    :param _param_conf:
    :return:

    >>> config = {
    >>>"param0":
    >>>    {"source": "AlarmData",
    >>>     "key_map": ["AdditionalFields", "BTS-ID"],
    >>>     "force_integer": True }}

    >>>alarm_ticket = {"AdditionalFields": {"BTS-ID": "BTS-54451"}}
    >>>parse_from_alarmdata(config, alarm_ticket)
    >>>54451
    """
    # Get mapping list to find value through JSON
    map_list: list = _param_conf.get('key_map')

    # Force integer
    force_int: bool = _param_conf.get('force_integer')
    # Check if regex_pattern is given as substitutor rule or not
    if 'regex_pattern' not in _param_conf.keys():
        # Get value from dict by using mapping list in config
        value: str = get_from_dict(_alarm_dict, map_list)

        msglogr.debug(f"Extracted values {value} for {map_list} from alarm data ")
        # Convert str to int of force_integer is True
        if force_int:
            # Get string and convert to int
            value: int = int(re.findall(r'\d+', value)[0])
        return value
    #if regex_pattern is given then find value from key_map
    else:
        regex_pattern:str = _param_conf.get('regex_pattern')
        value = [_alarm_dict[val] for val in map_list][0]
        value:str = str(re.findall(regex_pattern,value)[0])
        return value


def parse_last_cmd_output(_param_conf: dict, _alarm_dict: dict) -> int:
    """
    Parse data from last command output
    :param _param_conf:
    :param _alarm_dict:
    :return:
    """
    # Get regex pattern from conf dict
    regex_pattern: str = _param_conf.get('regex_pattern')
    # Force integer
    force_int = _param_conf.get('force_integer')

    # Get last command output without command output filter
    last_cmd_output: str = get_last_command_output(_alarm_dict, False)

    # Get value by using regular expression
    value: str = re.findall(regex_pattern, last_cmd_output)[0]

    if value and force_int:
        value: int = int(re.findall(r'\d+', value)[0])

    return value


def get_cmd_output_from_source(_source: str, _alarm_dict: dict) -> str:
    """
    Get good command output from source set in configuration : param-> source
    :param _source: regex flavor command (digit parameter replaced by r'\d*'
    :param _alarm_dict:
    :return:
    """
    cmd_list: list = _alarm_dict.get('History').get('cmd_list')
    cmd_output_list: list = _alarm_dict.get('History').get('output_list')

    for cmd, output in zip(reversed(cmd_list), reversed(cmd_output_list)):
        if re.findall(_source, cmd):
            return output

    raise ValueError(f'Can not find command output from this source {_source}')

#Rajesh - Added the method get_cmd_output to support new command_format_list
def get_cmd_output(_source: str, _alarm_dict: dict) -> str:
    """
    Get good command output from source set in configuration : param-> source
    :param _source: regex flavor command (digit parameter replaced by r'\d*'
    :param _alarm_dict:
    :return:
    """
    cmd_fmt_list: list = _alarm_dict.get('History').get('commandname_list')
    cmd_output_list: list = _alarm_dict.get('History').get('output_list')

    cmd_fmt_list.reverse()
    cmd_output_list.reverse()
    i = cmd_fmt_list.index(_source)
    output = cmd_output_list[i]
    return output

def check_cmd(_cmd: str,_alarm_dict: dict):
    if _cmd not in _alarm_dict.get('History').get('cmd_list'):
        op = _cmd
    else:
        op= None
    return op

def list_duplicates(seq):
    tally = defaultdict(list)
    for i,item in enumerate(seq):
        tally[item].append(i)
    return ((key,locs) for key,locs in tally.items()
                            if len(locs)>1)

def get_parser_output(_param_conf: dict,_alarm_dict: dict):
    cmdname_list = _alarm_dict.get("History").get("commandname_list")
    prsr_list = _alarm_dict.get("History").get("parser_list")
    #cmdname_list.reverse()
    #prsr_list.reverse()
    _source = _param_conf.get("source")
    dup = None
    prsr_op_list = []
    index=None
    for dup in sorted(list_duplicates(cmdname_list)):
        if dup[0] == _source:
            index = dup[1]
    if (dup is not None) & (index is not None):
        for i in index:
            prsr_op = prsr_list[i+1]
            value = prsr_op.get(_param_conf.get("key_map")[1]).get(_param_conf.get("key_map")[2])
            prsr_op_list.extend(value)
        return list(set(prsr_op_list))
    else:
        i = cmdname_list.index(_source)
        prsr_op = prsr_list[i+1]
        value = prsr_op.get(_param_conf.get("key_map")[1]).get(_param_conf.get("key_map")[2])
        if (isinstance(value,list)) and (len(value) ==1):
            return value[0]
        else:
            return value

def get_subval(param_list: list,_alarm_dict: dict,_raw_cmd: str):
    prsr_comb = list(itertools.product(*param_list))
    param_cmd = _raw_cmd
    cmd_comb =[]
    for j in range(0, len(prsr_comb)):
        for i in range(len(re.findall('param', _raw_cmd))):
            param_cmd: str = param_cmd.replace(f'<param{i}>', str(prsr_comb[j][i]))
        cmd_comb.append(param_cmd)
        param_cmd = _raw_cmd
    for i in range(0,len(cmd_comb)):
        op = check_cmd(cmd_comb[i],_alarm_dict)
        if op is None:
            if i != len(cmd_comb) - 1:
                op = check_cmd(cmd_comb[i+1],_alarm_dict)
            else:
                op=None
        else:
            break
    return op

def get_dup_cmd_output(_param_conf: dict,_alarm_dict: dict):
    cmdname_list = _alarm_dict.get("History").get("commandname_list")
    op_list = _alarm_dict.get(_param_conf['key_map'][0]).get(_param_conf['key_map'][1])
    #cmdname_list.reverse()
    #prsr_list.reverse()
    _source = _param_conf.get("source")
    dup = None
    prsr_op_list = []
    index=None
    for dup in sorted(list_duplicates(cmdname_list)):
        if dup[0] == _source:
            index = dup[1]
    if (dup is not None) & (index is not None):
        for i in index:
            _op = op_list[i]
            value = _op
            prsr_op_list.append(value)
        return list(set(prsr_op_list))
    else:
        i = cmdname_list.index(_source)
        _op = op_list[i]
        value = _op
        return value

def parse_from_cmd(_param_conf: dict, _alarm_dict: dict) -> int:
    """
    Parse data from last command output
    :param _param_conf:
    :param _alarm_dict:
    :return:
    """
    if 'key_map' not in _param_conf.keys():
        # Get source (ZEEI:BTS=\d* [...])
        cmd_source = _param_conf.get('source')
        # Get regex pattern from conf dict
        regex_pattern: str = _param_conf.get('regex_pattern')
        force_int: bool = _param_conf.get('force_integer')
        # Set output parameter as none
        # avoid index error in case of found value
        value: str = None

        # Get command output from mentioned source in configuration file for a param
        #last_cmd_output: str = get_cmd_output_from_source(cmd_source, _alarm_dict)
        last_cmd_output: str = get_cmd_output(cmd_source, _alarm_dict)


        # Get value by using regular expression
        try:
            value: str = re.findall(regex_pattern, last_cmd_output, re.M)[0]
        except IndexError:
            # If not value found r
            pass
        print ('Value after find all is ', value)
        '''
        if value and force_int:
            value: int = int(re.findall(r'\d+', value)[0])
        '''
        if value and force_int:
            if isinstance(value, tuple) and force_int:
                value: int = int([val for val in value if val != ''][0])
            else:
                value: int = int(re.findall(r'\d+', value)[0])

        return value
    elif ('key_map' in _param_conf.keys()) & ('History' not in _param_conf['key_map']):
        value  = get_parser_output(_param_conf,_alarm_dict)
        return value
    elif ('key_map' in _param_conf.keys()) & ('History' in _param_conf['key_map']):
        value = get_dup_cmd_output(_param_conf,_alarm_dict)
        return value

def parse_from_db(_param_conf: dict, _alarm_dict: dict,_raw_cmd: str) -> int:
    """
    Parse data from last command output
    :param _param_conf:
    :param _alarm_dict:
    :return:
    """
    # Get source (CopyCommand)
    cmd_source: str = _param_conf.get('source')
    force_int: bool = _param_conf.get('force_integer')
    # Set output parameter as none
    # avoid index error in case of found value
    value: str = None
    value = _raw_cmd
    return value


def get_param(_conf_dict: dict, _alarm_dict: dict,_raw_cmd : str) -> list:
    """
    Main function to fetch all needed parameter
    :param _alarm_dict:
    :param _conf_dict:
    :return:
    """

    print ("jello")
    # Iteration in each param
    param_list: list = []
    for param in _conf_dict.keys():
        print(param)
        # Get source (ticket/or command name)
        source = _conf_dict.get(param).get('source')

        # If param source if coming from ticket
        if source == 'AlarmData':
            param_list.append(parse_from_alarmdata(_conf_dict.get(param), _alarm_dict))
        elif source == 'Use AS-IS':
            param_list.append(parse_from_db(_conf_dict.get(param), _alarm_dict,_raw_cmd))
        else:
            param_list.append(parse_from_cmd(_conf_dict.get(param), _alarm_dict))
    return param_list

def get_param_dict(_conf_dict: dict, _alarm_dict: dict,_raw_rs:str) -> list:
    """
    Main function to fetch all needed parameter
    :param _alarm_dict:
    :param _conf_dict:
    :return:
    """
    # Iteration in each param
    param_dict: dict = {}
    for param in _conf_dict.keys():

        # Get source (ticket/or command name)
        source = _conf_dict.get(param).get('source')

        # If param source if coming from ticket
        if source == 'AlarmData':
            param_dict[param] = (parse_from_alarmdata(_conf_dict.get(param), _alarm_dict))
        elif source == 'Use AS-IS':
            param_dict[param] = (parse_from_db(_conf_dict.get(param), _alarm_dict,_raw_rs))
        else:
            param_dict[param] = (parse_from_cmd(_conf_dict.get(param), _alarm_dict))
    return param_dict
