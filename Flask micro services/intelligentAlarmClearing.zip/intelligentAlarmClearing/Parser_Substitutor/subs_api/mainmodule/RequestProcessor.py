import os
import sys
import json, requests
import regex as re
import traceback
from pprint import pprint
import logging

from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from common.models import AlarmCommandRuleDetails

from common.helpers.json_helper import get_customer_name, get_alarm_text
from common.helpers.db_helper import get_substitutor_rule,get_rs_substitutor_rule
from common.helpers.general_helper import iAC_SUBS_MESSAGE_LOGGER_NAME, prsr_subs_worker_pool
from common import iacexceptions

from subs_api.mappers.conf_parser import get_param
from subs_api.mappers.sub_method import subs_cmd,subs_rs,subs_rs_usr,subs_cmd_usr

global ORCH_TOKEN
ORCH_TOKEN="Start"

ignoreproxies = {
  "http": None,
  "https": None,
}

msglogr = logging.getLogger(iAC_SUBS_MESSAGE_LOGGER_NAME)

SUBSTITUTOR_OUTPUT_KEY = 'SubstitutorOutput'
SUBSTITUTOR_OUTPUT_CMD_OUTPUT_KEY = 'mmlCommand'

USER_PROPOSED_KEY = 'UserProposed'
USER_PROPOSED_KEY_CMD_OUTPUT_KEY = 'commandname'


if os.environ.get('PARSER_IGNORE_PROXIES'):
    val = os.environ.get('PARSER_IGNORE_PROXIES')
    msglogr.debug(f"val {val}, type is {type(val)}")
    ignoreproxies = json.loads(val)
# else if debugging resource, need tunneling before
else:
    ignoreproxies = None
#msglogr("ignoreproxies set to {} ".format(ignoreproxies))


if os.environ.get('ORCH_API_FULL_URL'):
    ORCHESTRATOR_RESOURCE_URL = os.environ.get('ORCH_API_FULL_URL')
# else if debugging resource, need tunneling before
else:
    ORCHESTRATOR_RESOURCE_URL = 'http://localhost:8005/orch/api/processmml/'

# Format to store operating system envrionment variable
# ORCHESTRATOR_TOKEN_DETAILS = json.loads('{"url", "http://localhost:8005/gui_services/ctoken", ' \
#                                 '"user", "iacuser", "pass", "iac123"}')

if os.environ.get('ORCH_TOKEN_DETAILS'):
    ORCHESTRATOR_TOKEN_DETAILS = json.loads(os.environ.get('ORCH_TOKEN_DETAILS'))
else:
    ORCHESTRATOR_TOKEN_DETAILS = None


def refresh_orch_token():
    global ORCH_TOKEN
    rettknstatus = False
    msglogr.debug(f"Refreshing the Orchestration token")
    try:
        if ORCHESTRATOR_TOKEN_DETAILS:
            url = ORCHESTRATOR_TOKEN_DETAILS["url"]
            usr = ORCHESTRATOR_TOKEN_DETAILS["user"]
            pss = ORCHESTRATOR_TOKEN_DETAILS["pass"]
            msglogr.debug(f"Connecting to URL {url} with user  {usr} and password {pss}")
            r=requests.post(url,data=json.dumps({"uname":usr,"pass":pss}),
                            headers={"Content-Type":"application/json"}, proxies=ignoreproxies)
            if r.status_code == 200:
                print(f"The contents are {r.content}")
                ORCH_TOKEN=r.json()["data"]["token"]
                rettknstatus = True
                retmsg = f"Success : token Refreshed, new token is {ORCH_TOKEN}"
                msglogr.debug(retmsg)
            else:
                retmsg = f"Fail : Token Refresh failed {r.content}"
                msglogr.warning(retmsg)
        else:
            retmsg = f"Fail : ORCHESTRATOR_TOKEN_DETAILS are empty, check environment settings"
            msglogr.error(retmsg)
    except:
        retmsg = "Fail : Exception while token refresh"
        msglogr.error(retmsg + traceback.format_exc())

    return rettknstatus, retmsg


def post_to_orchestrator(response_json):
    global ORCH_TOKEN
    retpststatus = False
    msglogr.info(f"Substitutor forwarding json to orchestrator")
    try:
        iactkn = response_json['iACToken']
        if ORCHESTRATOR_RESOURCE_URL:
            if ORCH_TOKEN == "Start":
                refresh_orch_token()

            msglogr.info(f"Using token {ORCH_TOKEN}")
            msglogr.info(f"Working with iACToken {iactkn}, ignore proxies {ignoreproxies}")
            msglogr.debug(f"JSON details for  iACToken {iactkn} \n {response_json}")
            r = requests.post(ORCHESTRATOR_RESOURCE_URL, json=response_json, proxies=ignoreproxies,
                              headers = {"token":ORCH_TOKEN,"Content-type":"application/json"})
            if r.ok:
                msglogr.info(f'Sent iACToken {iactkn} json to Orchestrator')
                retpststatus = True
            else:
                msglogr.warning(f'Failed to post iACToken {iactkn} to orchestrator code return = {r.status_code}')
                if (r.status_code == 401):
                    if refresh_orch_token():
                        msglogr.debug(f"Retrying to send iACToken {iactkn} to orchestrator")
                        r = requests.post(ORCHESTRATOR_RESOURCE_URL, json=response_json, proxies=ignoreproxies,
                                          headers = {"token":ORCH_TOKEN,"Content-type":"application/json"})
                        if r.ok:
                            msglogr.info(f'Sent iACToken {iactkn} json to Orchestrator during retry')
                            retpststatus = True
                        else:
                            msglogr.error(f'Failed to send iACToken {iactkn} json to Orchestrator during retry, skipped')
                    else:
                        msglogr.error(f"Couldn't refresh token from ORCH, failed to send packet for iACToken {iactkn}")
                else:
                    msglogr.error(f'Orchestrator service is not reachable {r.content}, failed to send iACToken {iactkn}')
        else:
            msglogr.error(f"Fail : ORCHESTRATOR_RESOURCE_URL is empty for iACToken {iactkn}, check environment settings")
    except:
        msglogr.error(f"Error in posting iACToken {iactkn} to ORCH {traceback.format_exc()}")

    return retpststatus


def substitutor_service(alarm_dict: dict):
    subsiactkn = alarm_dict['iACToken']
    try:
        msglogr.info(f"Started Substitutor thread to process json of iACToken {subsiactkn}")
        msglogr.debug(f"received JSON for iACToken {subsiactkn} \n {alarm_dict}")
        resolution_status = alarm_dict.get('PredictorOutput').get('resolutionStatus')
        # Create a dict for
        alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {}

        if (alarm_dict['PredictorOutput']['mmlCommand'] is None) and ('rsname' in alarm_dict['PredictorOutput']):
            alarm_dict = subs_rs(alarm_dict, resolution_status, subsiactkn)
        elif (alarm_dict['PredictorOutput']['rsname'] is None) and ('mmlCommand' in alarm_dict['PredictorOutput']):
            alarm_dict = subs_cmd(alarm_dict,resolution_status,subsiactkn)

        post_to_orchestrator(alarm_dict)
    except Exception as e:
        # Set predicted output, meta data used to substitute, and response
        msglogr.error(f"Exception while processing substition rules for iACToken {subsiactkn} \n {traceback.format_exc()}")
        alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
            'iacerrordetails': 'Exception while processing substition rules',
            'iacstatus': 'Failed',
            'resolutionStatus': 8,
            'traceback': f' {e} /// {traceback.format_exc()}',
            SUBSTITUTOR_OUTPUT_CMD_OUTPUT_KEY: None}
        post_to_orchestrator(alarm_dict)

    msglogr.info(f"Completed processing of iACToken {subsiactkn} by Substitutor")
    msglogr.debug(f"Sent json for iACToken {subsiactkn} \n {alarm_dict}")



@api_view(['POST'])
def substitute_by_user(request):

    try:
        msglogr.info("Received a request from user to substitute values")
        if request.method == 'GET':
            return Response({'nothing:''nothing to serve for HTTP/GET method -> use POST'},
                            status=status.HTTP_200_OK)

        if request.method == 'POST':
            alarm_dict: dict = request.data
            usriactkn = alarm_dict['iACToken']

            msglogr.info(f"Working with iACToken {usriactkn}")
            msglogr.debug(f"user JSON for iACToken {usriactkn} \n {alarm_dict}")

            # Get user command from ticket
            if ('rsname' in alarm_dict['UserProposed']):
                alarm_dict = subs_rs_usr(alarm_dict, usriactkn)
            elif ('commandname' in alarm_dict['UserProposed']):
                alarm_dict = subs_cmd_usr(alarm_dict, usriactkn)

            msglogr.info(f"Completed processing user request of iACToken {usriactkn} by Substitutor")
            msglogr.debug(f"returning json {alarm_dict}")
            return Response(alarm_dict, status=status.HTTP_200_OK)
    except:
        msglogr.error(f"Exception while processing substition rules for iACToken {usriactkn} \n {traceback.format_exc()}")
        alarm_dict[SUBSTITUTOR_OUTPUT_KEY] = {
            'iacerrordetails': 'Exception while processing substition rules',
            'iacstatus': 'Failed',
            'resolutionStatus': 8,
            'traceback': f' "" /// {traceback.format_exc()}',
            USER_PROPOSED_KEY_CMD_OUTPUT_KEY: None}



@api_view(['POST', 'GET'])
def async_substitutor_service_api(request):
    msglogr.info("Started async method")
    if request.method == 'POST' or request.method == 'GET':
        try:
            # Read from post
            msglogr.debug("Reading incoming data")
            print("Reading incoming data")
            income_data = request.data
            pprint(income_data)

            # If there JSON data
            # Call worker to process predictive job
            if income_data:
                msglogr.debug("Starting a thread to serve the request")
                print("Starting a thread to serve the request")
                prsr_subs_worker_pool.submit(substitutor_service, income_data)
                return Response({'debug': 'Substitutor process initiated'})
            else:
                print(f'[ERROR] No input data ! ')
                return Response({'debug': 'No input data found'},
                                status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        except AttributeError:
            print(traceback.format_exc())
            return Response({'debug': 'error', 'traceback': str(traceback.format_exc())},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    msglogr.info("Completed async method")
