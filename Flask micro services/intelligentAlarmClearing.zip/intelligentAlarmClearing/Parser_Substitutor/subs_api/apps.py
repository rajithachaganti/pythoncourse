from django.apps import AppConfig


class SubsApiConfig(AppConfig):
    name = 'subs_api'
