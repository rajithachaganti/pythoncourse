Project information
*******************


Clone this project with git submodules

.. code-block:: shell

    git clone --recurse-submodules -j8 https://gitlabe1.ext.net.nokia.com/ABI/intelligentAlarmClearing1/parser-substitutor.git



Deploy
******

use this command to display help

.. code-block:: shell

    make help


Build and run parser and substitutor APIs

.. code-block::

    # This command will create docker image parser-substitutor:0.0.1
    make docker-build-runserver


Change DNS or Tunneling configurations for
    - Orchestrator DATABASE
    - Orchestrator REST API url
    - Predictor REST API url

Change **Makefile**, recipe **docker-start** and set env var related in **DockerFile**

Env vars conditions will change the way to run application: create tunnels or not, using remote port or use local port.

Env vars settings will impact theses files :
    - ./init.sh (create or not tunnel is DNS are set)
    - ./django_dev_iac.settings.py (use tunnel parameters or DNS parameters to connect to database)
    - ./parser_api.views.v1 (use tunnel parameters of DNS parameters to POST to ORCHESTRATOR API, and predictor API)