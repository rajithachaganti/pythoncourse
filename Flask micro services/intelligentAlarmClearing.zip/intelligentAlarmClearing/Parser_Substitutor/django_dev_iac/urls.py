"""django_dev_iac URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf.urls import url
from rest_framework_swagger.views import get_swagger_view
import parser_api.mainmodule.RequestProcessor
import subs_api.mainmodule.RequestProcessor
import common.views


admin.autodiscover()
schema_view = get_swagger_view(title='API\'s List')

urlpatterns = [
    # Common resources
    path('admin/', admin.site.urls),
    url(r'^jet/', include('jet.urls', 'jet')),
    url(r'^$', schema_view),

    path('echo/', parser_api.mainmodule.RequestProcessor.    simple_echo),

    # Substitutor resources
    path('ps/substitute/', subs_api.mainmodule.RequestProcessor.async_substitutor_service_api),

    # Do parse, prediction, substitution
    path('ps/predictive_service/', parser_api.mainmodule.RequestProcessor.async_predictive_service_api),

    path('ps/substitute_by_user/', subs_api.mainmodule.RequestProcessor.substitute_by_user),

    path('upload_csv/',common.views.upload_csv)
    ]


