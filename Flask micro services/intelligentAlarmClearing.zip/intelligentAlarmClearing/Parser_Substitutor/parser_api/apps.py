from django.apps import AppConfig


class ParserApiConfig(AppConfig):
    name = 'parser_api'
