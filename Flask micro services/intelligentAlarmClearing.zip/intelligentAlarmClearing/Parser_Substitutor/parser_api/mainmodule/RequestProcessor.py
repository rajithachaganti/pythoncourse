# Main predictive service view
#
# main API resource = async_predictive_service_api


import os, sys, json, traceback
from pprint import pprint

import logging
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response

from common.helpers.json_helper import get_last_executed_commandname, get_customer_name, \
    get_alarm_text, get_last_command_output
from common.helpers.db_helper import get_parser_rule
from common.helpers.general_helper import get_object, post_to_resource, prsr_subs_worker_pool,iAC_PARSER_MESSAGE_LOGGER_NAME

from common.models import AlarmCommandRuleDetails




# +-----------------------------------------+
# | APP CONSTANT DEF                        |
# +-----------------------------------------+
# Parser key definition
PARSER_KEY = 'ParserOutput'
msglogr = logging.getLogger(iAC_PARSER_MESSAGE_LOGGER_NAME)
# Resources/API definition
if os.environ.get('PRED_API_FULL_URL'):
    PREDICTOR_RESOURCE_URL = os.environ.get('PRED_API_FULL_URL')
else:
    PREDICTOR_RESOURCE_URL = 'http://localhost:8000/predictor_api/get_next_command/'


def predictive_service_main(_dict: dict) -> None:
    iactoken = _dict['iACToken']
    try:
        # Read last command from
        lastcmdname = get_last_executed_commandname(_dict)
        print("last cmd", lastcmdname)
        if (lastcmdname == None) and (not _dict.get("History")):
            lastcmdname = _dict.get("AlarmName")+"_"+"First_Parser"
        if lastcmdname:
            try:
                # Get parser details from
                # from database, by filtering by customer, alarm name and predicted command
                parsertype, parserrule, parseroutput = get_parser_rule(AlarmCommandRuleDetails,
                            get_customer_name(_dict), get_alarm_text(_dict), lastcmdname)
                print("parsertype ", parsertype)
                parserobj = get_object(parsertype)
                if parserobj:
                    prsrOutput = parserobj.parseOutputData(lastcmdname, _dict, parserrule, parseroutput)
                    print("parseroutput ", prsrOutput)
                    if len(prsrOutput) != 0:
                        _dict[PARSER_KEY] = {
                            'debug': None,
                            'iacerrordetails': None,
                            'iacstatus': 'Success'}
                        _dict[PARSER_KEY].update(prsrOutput)
                    else:
                        _dict[PARSER_KEY] = {
                            'debug' : None,
                            'iacerrordetails': "Invalid/Error Alarm output received from NE",
                            'iacstatus': 'Failed'}
                else:
                    _dict[PARSER_KEY] = {
                        'debug' : 'Parser not defined for the command, skipping parse',
                        'iacerrordetails': None,
                        'iacstatus': 'Success'}
            except:
                msglogr.error(f"Erorr while extracting the parser object \n {traceback.format_exc()}")
                _dict[PARSER_KEY] = {
                    'iacerrordetails': 'Error while parsing the mml output',
                    'iacstatus': 'Failed',
                    'traceback': f' {e} /// {traceback.format_exc()}'}
        else:
            print("lastcmdname not available ")
            print("Last executed command name not found in alarm json")
            _dict[PARSER_KEY] = {
                'debug': 'no cmd output to parse',
                'iacerrordetails': None,
                'iacstatus': 'Success'}
        print("Sending alarm to predictor ", _dict)
        if "ResponseURL" in _dict.keys():
            predictor_response = post_to_resource(_dict["ResponseURL"], _dict)
        else:
            predictor_response = post_to_resource(PREDICTOR_RESOURCE_URL, _dict)
    except:
        msglogr.error(f"Error while processing the packet for token {iactoken} \n {traceback.format_exc()}")
        _dict[PARSER_KEY] = {
            'iacerrordetails': 'Error while processing the packet',
            'iacstatus': 'Failed',
            'traceback': f' {e} /// {traceback.format_exc()}'}


@api_view(['POST'])
def simple_echo(request):
    """
    Simple echo resource
    :param request:
    :return:
    """

    if request.method == 'POST':
        income_data = request.data
        return Response(income_data, status=status.HTTP_200_OK)


@api_view(['POST', 'GET'])
def async_predictive_service_api(request):
    print("Started async method")
    if request.method == 'POST' or request.method == 'GET':
        try:
            # Read from post
            print("Reading incoming data")
            income_data = request.data
            pprint(income_data)
            print("Read incoming data")

            if isinstance(income_data, dict):
                inputjson = income_data
            else:
                inputjson = json.loads(income_data)

            # If there JSON data
            # Call worker to process predictive job
            if income_data:
                prsr_subs_worker_pool.submit(predictive_service_main, inputjson)
                return Response({'debug': 'Parser process initiated'})
            else:
                print(f'[ERROR] No input data ! ')
                return Response({'debug': 'No input data found'},
                                status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        except AttributeError:
            print(traceback.format_exc())
            return Response({'debug': 'error', 'traceback': str(traceback.format_exc())},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

