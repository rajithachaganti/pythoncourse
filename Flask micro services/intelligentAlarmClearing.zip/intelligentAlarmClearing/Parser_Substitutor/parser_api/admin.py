# Register your models here.

from django.apps import apps
from import_export.admin import ImportExportModelAdmin
from django.contrib import admin

parser_api_app = apps.get_app_config('parser_api')

for model_name, model in parser_api_app.models.items():
    @admin.register(model)
    class OverrideAdmin(ImportExportModelAdmin):
        pass
