export CONTEXT_DB_HOST=192.168.0.28
export CONTEXT_DB_PG_PORT=5432
export CONTEXT_DB_PG_DB=iac
export CONTEXT_DB_PG_LOGIN=iac
export CONTEXT_DB_PG_PASSWORD=iac@!451

export PARSER_IGNORE_PROXIES='{"http":null, "https":null}'
export ORCH_API_FULL_URL="http://192.168.0.22:8011/orch/api/processmml"
export PRED_API_FULL_URL="http://192.168.0.11:8000/predictor_api/get_next_command/"
export ORCH_TOKEN_DETAILS='{"url":"http://192.168.0.22:8011/gui_services/ctoken", "user":"Siva", "pass":"siva1234"}'

python3 manage.py runserver 0.0.0.0:8012
