#!/usr/bin/env bash

# Pretty print
export COM_COLOR='\033[0;34m'
export OBJ_COLOR='\033[0;36m'
export OK_COLOR='\033[0;32m'
export ERROR_COLOR='\033[0;31m'
export WARN_COLOR='\033[0;33m'
export NO_COLOR='\033[m'

if [[ -z "$CONTEXT_DB_DNS" ]] && [[ -z "$ORCH_DNS" ]] && [[ -z "$PRED_DNS" ]]; then
    # If context DB dns is not set
    #  create ssh tunnel
    # in django_dev_iac.settings.DATABASE
    # host = localhost
    # port = local forwarded port will be used
    #-------------------------------------
    # ssh tunneling
    sshpass -p $CONTEXT_DB_SSH_PASSWORD \
    ssh -o StrictHostKeyChecking=no \
    -L $CONTEXT_DB_PG_LOCAL_PORT:127.0.0.1:$CONTEXT_DB_PG_REMOTE_PORT \
    -N -f -l $CONTEXT_DB_SSH_LOGIN $CONTEXT_DB_HOST \
    && \
    echo -e "${OK_COLOR}[OK]${NO_COLOR} Tunneling DB orchestrator \n" \
    && \
    sshpass -p $ORCH_SSH_PASSWORD \
    ssh -o StrictHostKeyChecking=no \
    -L $ORCH_API_LOCAL_PORT:127.0.0.1:$ORCH_API_REMOTE_PORT \
    -N -f -l $ORCH_SSH_LOGIN $ORCH_SSH_HOST \
    && \
    echo -e "${OK_COLOR}[OK]${NO_COLOR} Tunneling orchestrator API \n" \
    sshpass -p $PRED_SSH_PASSWORD \
    ssh -o StrictHostKeyChecking=no \
    -L $PRED_API_LOCAL_PORT:127.0.0.1:$PRED_API_REMOTE_PORT \
    -N -f -l $PRED_SSH_LOGIN $ORCH_SSH_HOST \
    &&\
    echo -e "${OK_COLOR}[OK]${NO_COLOR} Tunneling Predictor API \n" \
            "${COM_COLOR}[..]${NO_COLOR} Starting server \n" \
     && \
    #-------------------------------------
    # start server
    pipenv run python manage.py runserver 0.0.0.0:8000 ||\
    # if tunneling or running server is not working print error
    echo -e "${ERROR_COLOR}[ERROR]${NO_COLOR} In a tunnel" \
            "Used parameters: \n" \
            "  ORCH_SSH_HOST=$ORCH_SSH_HOST \n" \
            "  ORCH_SSH_LOGIN=$ORCH_SSH_LOGIN \n" \
            "  ORCH_SSH_PASSWORD=$ORCH_SSH_PASSWORD \n" \
            "  ORCH_API_REMOTE_PORT=$ORCH_API_REMOTE_PORT \n" \
            "  ORCH_API_LOCAL_PORT=$ORCH_API_LOCAL_PORT \n" \
            "  ORCH_API_RESOURCE=$ORCH_API_RESOURCE \n" \
            "  ORCH_API_FULL_URL=$ORCH_API_FULL_URL \n" \
            "  -------------------------------------------------------\n"\
            "  CONTEXT_DB_PG_REMOTE_PORT=$CONTEXT_DB_PG_REMOTE_PORT \n" \
            "  CONTEXT_DB_PG_LOCAL_PORT=$CONTEXT_DB_PG_LOCAL_PORT \n" \
            "  CONTEXT_DB_PG_DB=$CONTEXT_DB_PG_DB \n" \
            "  CONTEXT_DB_PG_LOGIN=$CONTEXT_DB_PG_LOGIN \n" \
            "  CONTEXT_DB_PG_PASSWORD=$CONTEXT_DB_PG_PASSWORD \n"
            "  -------------------------------------------------------\n"\
            "  PRED_SSH_HOST=$PRED_SSH_HOST \n"\
            "  PRED_SSH_LOGIN=$PRED_SSH_LOGIN \n"\
            "  PRED_SSH_PASSWORD=$PRED_SSH_PASSWORD \n"\
            "  PRED_API_REMOTE_PORT=$PRED_API_REMOTE_PORT \n"\
            "  PRED_API_LOCAL_PORT=$PRED_API_LOCAL_PORT \n" \
            "  PRED_API_RESOURCE=$PRED_API_RESOURCE \n"\
            "  PRED_API_FULL_URL $PRED_API_FULL_URL \n"\
    exit 1
else
    # if context DB dns is set
    # use remote port, dns, and postgres identifications
    # in django_dev_iac.settings.DATABASE
    # these parameters will be loaded if ENV VAR $CONTEXT_DB_DNS exist
    # host = dns
    # post = remote Postgres port
    echo -e "${OK_COLOR}[OK]${NO_COLOR} Used resources urls \n "\
            "   ORCH_API_FULL_URL_DNS=$ORCH_API_FULL_URL_DNS \n"\
            "   PRED_API_FULL_URL_DNS=$PRED_API_FULL_URL_DNS \n"\
            "   -------------------------------------------------------\n"
            "   CONTEXT_DB_DNS=$CONTEXT_DB_DNS \n"\
            "   CONTEXT_DB_PG_REMOTE_PORT=$CONTEXT_DB_PG_REMOTE_PORT \n"\
            "   CONTEXT_DB_PG_DB=$CONTEXT_DB_PG_DB \n"\
            "   CONTEXT_DB_PG_LOGIN=$CONTEXT_DB_PG_LOGIN \n"\
            "   CONTEXT_DB_PG_PASSWORD=$CONTEXT_DB_PG_PASSWORD \n" \

    pipenv run python manage.py runserver 0.0.0.0:8000 \
; fi
