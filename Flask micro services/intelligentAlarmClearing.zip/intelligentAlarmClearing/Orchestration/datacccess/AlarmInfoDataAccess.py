from Modules.Commons import getConnection
from psycopg2.extras import RealDictCursor
import pandas as pd
import json


class AlarmInfoDataAccess:

    def __init__(self):
        self.connection = getConnection()

    def __del__(self):
        self.connection.close()

    # Check if all the alarms are resolved or closed for the ticket id
    def is_alarms_resolved_for_ticket(self, ticket_id):
        try:
            with self.connection as conn:
                with conn.cursor() as cur:
                    cur.execute("select not exists(select 1 from alarminfo where (status is null or status not in (4,12))"
                                " and ticketid='{}')"
                                .format(ticket_id))
                    return cur.fetchone()[0]
        except BaseException as e:
            print("Error ---------  " + str(e))
            return False

    # Check if all the alarms are operation complete or closed for the ticket id
    def is_alarms_operation_complete_for_ticket(self, ticket_id):
        try:
            with self.connection as conn:
                with conn.cursor() as cur:
                    cur.execute("select not exists(select 1 from alarminfo where (status not in (4,12,13))"
                                " and ticketid='{}')"
                                .format(ticket_id))
                    return cur.fetchone()[0]
        except BaseException as e:
            print("Error ---------  " + str(e))
            return False

    # Gets ticket id for iactoken
    def get_ticketid(self, iactoken):
        try:
            with self.connection as conn:
                with conn.cursor() as cur:
                    cur.execute("select ticketid from alarminfo where iactoken='{}'"
                                .format(iactoken))
                    return cur.fetchone()[0]
        except BaseException as e:
            print("Error ---------  " + str(e))
            return None

    # Gets ticket id for iactoken
    def get_alarminfo(self, iactoken):
        try:
            with self.connection as conn:
                with conn.cursor(cursor_factory=RealDictCursor) as cur:
                    cur.execute("select ticketid,nodegroup,executionmode,customer,alarmnumber,alarmname,scope,status"
                                " from alarminfo where iactoken='{}'"
                                .format(iactoken))
                    return cur.fetchone()
        except BaseException as e:
            print("Error ---------  " + str(e))
            return None

    # Gets Performance Report by date
    def get_performance_report(self, interval):
        try:
            with self.connection as conn:
                performance_report = pd.read_sql("select * from getPerformanceReport(%s) order by "
                                                 "report_date::timestamp desc, nodegroup asc",
                                                 conn, params=[interval])
                return performance_report
        except BaseException as e:
            print("Error ---------  " + str(e))
            return None

    # Check if Cycle end exists for an alarm
    def is_alarm_cycle_end(self, iactoken):
        try:
            with self.connection as conn:
                with conn.cursor() as cur:
                    cur.execute("select exists(select 1 from alarmcycle where iactoken='{}' and tasktype=8)"
                                .format(iactoken))
                    return cur.fetchone()[0]
        except BaseException as e:
            print("Error ---------  " + str(e))
            return False

