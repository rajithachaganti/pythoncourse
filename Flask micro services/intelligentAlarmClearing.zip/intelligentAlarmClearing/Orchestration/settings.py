import logging.handlers
import requests
import os
import socket
global APP_NAME
global APP_VERSION
global RPA_LOGIN_URL
global RPA_TOKEN
global RPA_USERNAME
global RPA_PASSWORD
global RPA_LOGIN_DATA
global RPA_MML_URL
global PREDICT_URL
global KM_URL
global LOCAL_URL
global NO_PROXY
global DATABASE_CONFIG
global iAC1_URL
NO_PROXY = {
    "http": None,
    "https": None,
}
SMTP_SERVER="mailrelay.int.nokia.com"
# SMTP_SERVER="localhost"
SMTP_PORT=25
global logger


HOSTNAME = socket.gethostbyname(socket.gethostname())


logger = logging.getLogger('gunicorn.error')
logger.setLevel(logging.DEBUG)
ermloghandler=logging.handlers.RotatingFileHandler("logs/OrchestrationLog.log",maxBytes=100*1024*1024,backupCount=3)
logformatter=logging.Formatter('%(asctime)s.%(msecs)03d | %(levelname)s | %(filename)s | %(funcName)s | %(message)s', "%a %d-%b-%Y %H:%M:%S")
ermloghandler.setFormatter(logformatter)
logger.addHandler(ermloghandler)
APP_NAME="iAC"
APP_VERSION="2.0"
iAC1_AUTO_ALARM_LIST = set(['File Notification, AP CDH, Acknowledgement Fault', 'BTS Operation Degraded Fault', 'Charging Destination Fault'])
PROCESS_iAC1_AUTO_ALARMS = False

EMAIL_ALARM = True
EMAIL_ALARM_TYPE = set(['Remote IP Address Unreachable Fault',
                        'Size Alteration Fault',
                        'File Notification, AP CDH, Acknowledgement Fault',
                        'Charging Destination Fault',
                        'SCTP NETWORK STATUS CHANGE fault',
                        'AP FILE PROCESSING FAULT',
                        'M3UA ASSOCIATION STATUS CHANGE Fault',
                        'SCTP ON CP ASSOCIATION STATUS CHANGE FAULT',
                        'SCTP ON CP NETWORK STATUS CHANGE FAULT',
                        'RP FAULT'])
EMAIL_ALARM_TO = ['nss-fm-cm@list.nokia.com','ajay.k3.singh@nokia.com','deepak.20.sharma@nokia.com',
                  'sumit.11.sharma@nokia.com','david.thomas@nokia.com','rajesh.vaddi@nokia.com']
EMAIL_FROM='iAC@nokia.com'
# EMAIL_PERFORMANCE_REPORT_TO = ['david.thomas@nokia.com','rajesh.vaddi@nokia.com','mohit.7.kumar@nokia.com',
#                                'ajay.k3.singh@nokia.com','vineet.mahajan@nokia.com','kuldeep.kuldeep@nokia.com']
EMAIL_PERFORMANCE_REPORT_TO = ['david.thomas@nokia.com']


# iAC 1.0 URL
# iAC1_URL="http://10.129.212.3:5045/predict_from_iac1"
# iAC1_URL='http://10.129.211.250:5000/predict_from_iac1'
iAC1_URL='http://10.129.3.43:5045/predict_from_iac1'
# iAC1_URL = None




# Prod Env
RPA_ATTACH_LOG_URL="http://10.129.1.197:8080/rpa/attachlog"
RPA_CLOSETICKET_URL="http://10.129.1.197:8080/rpa/closeticket"
LOCAL_URL="http://localhost:5051/orch/api/"
KM_URL="http://192.168.0.9:5053/knowledge_manager_api/index_scenario/"
PREDICT_URL="http://192.168.0.7:5052/ps/predictive_service/"
RPA_MML_URL="http://10.129.1.197:8080/rpa/processcommand"
RPA_LOGIN_URL="http://10.129.1.197:8080/rpa/login"
DATABASE_CONFIG={
"DATABASE":'iac',
"USERNAME":'iac',
"PASSWORD":'iac@!451',
"HOST":'192.168.0.33',
"PORT":'5062'
}




# Staging Env
# RPA_ATTACH_LOG_URL="http://10.129.1.232:8080/rpa/attachlog"
# RPA_CLOSETICKET_URL="http://10.129.1.232:8080/rpa/closeticket"
# LOCAL_URL="http://localhost:5031/orch/api/"
# KM_URL="http://192.168.0.46:5033/knowledge_manager_api/index_scenario/"
# PREDICT_URL="http://192.168.0.23:5032/ps/predictive_service/"
# RPA_MML_URL="http://10.129.1.232:8080/rpa/processcommand"
# RPA_LOGIN_URL="http://10.129.1.232:8080/rpa/login"
# DATABASE_CONFIG={
# "DATABASE":'iac',
# "USERNAME":'iac',
# "PASSWORD":'iac@!451',
# "HOST":'192.168.0.40',
# "PORT":'5042'
# }

# Devkit Env
# RPA_CLOSETICKET_URL="http://localhost:8011/rpa/closeticket"
# LOCAL_URL="http://localhost:8011/orch/api/"
# KM_URL="http://192.168.0.11:8013/knowledge_manager_api/index_scenario/"
# PREDICT_URL="http://192.168.0.28:8012/ps/predictive_service/"
# RPA_MML_URL="http://localhost:8011/orch/api/dummy"
# RPA_LOGIN_URL="http://localhost:8011/orch/api/dummytoken"
# DATABASE_CONFIG={
# "DATABASE":'iac',
# "USERNAME":'iac',
# "PASSWORD":'iac@!451',
# "HOST":'192.168.0.28',
# "PORT":'5432'
# }

# Local Env
if os.environ['ENV'] == 'local':
    LOCAL_URL = "http://localhost:8080/orch/api/"
    KM_URL = "http://192.168.0.11:5013/knowledge_manager_api/index_scenario/"
    PREDICT_URL = "http://192.168.0.28:5012/ps/predictive_service/"
    RPA_MML_URL = "http://localhost:8080/orch/api/dummy"
    RPA_LOGIN_URL = "http://localhost:8080/orch/api/dummytoken"
    DATABASE_CONFIG = {
        "DATABASE": 'iac',
        "USERNAME": os.environ['DB_USERNAME'],
        "PASSWORD": os.environ['DB_PASSWORD'],
        "HOST": 'localhost',
        "PORT": '5432'
    }

RPA_TOKEN = ""
RPA_USERNAME = "AvaUser"
RPA_PASSWORD = "Nokia1234"
RPA_LOGIN_DATA = "grant_type=password&username=" + RPA_USERNAME + "&password=" + RPA_PASSWORD + "&client_id=rpaApi"


def refresh_rpa_token():
    global RPA_TOKEN
    r = requests.get(RPA_LOGIN_URL, data=RPA_LOGIN_DATA, headers={"Content-Type": "application/text"}, proxies=NO_PROXY)
    if r.status_code == 200:
        RPA_TOKEN = "Bearer " + r.json()["access_token"]
        print("RPPA Token Refreshed")
        return True
    else:
        print("RPA Token Refresh failed")
        return False

