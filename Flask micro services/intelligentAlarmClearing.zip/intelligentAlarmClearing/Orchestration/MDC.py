import threading

mdc = threading.local();