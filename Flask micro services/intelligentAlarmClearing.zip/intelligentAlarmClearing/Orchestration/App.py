from Modules.Imports import *
import settings
import logging
# from waitress import serve
app = falcon.API(middleware=[HandleCORS(),AuthMiddleware(),RESTIntreceptor()])
app.add_error_handler(Exception, ErrorHandler.unexpected)
app.add_error_handler(falcon.HTTPError, RESTIntreceptor.process_response)
# app.add_error_handler(falcon.HTTPStatus, RESTIntreceptor.process_response)
microservices = Microservices()
logicservices = Logicservices()
authData = AuthenticationData()
orchestration_services=Orchestrationservices()
app.add_route('/gui_services/{param}', microservices)
app.add_route('/gui_services/api/{param}', logicservices)
app.add_route('/orch/api/{param}',orchestration_services)
app.add_route('/gui_services/cuser', authData)
app.add_route('/gui_services/cauth', authData)
app.add_route('/gui_services/ctoken', authData)

# gunicorn_logger = logging.getLogger('gunicorn.error')
# app.logger.handlers = gunicorn_logger.handlers
# app.logger.setLevel(gunicorn_logger.level)


#
# app.logger.info("Info log")
# app.logger.error("Error log")
# app.logger.debug("Debug log")
# app.logger.warning("Warning log")
# app.logger.critical("Critical log")

# settings.refresh_rpa_token()
# print(settings.RPA_TOKEN)
# serve(app, listen='0.0.0.0:8080')
