import schedule
import time
from Modules.Imports import *
import jobs.ReportsJob as reports

#reports.job()
schedule.every().day.at("03:30").do(reports.job)

while True:
    schedule.run_pending()
    time.sleep(60)