from datacccess.AlarmInfoDataAccess import *
from datetime import date, timedelta
from Modules.EmailHandler import *
import Constants

def job():
    print("I'm working...")
    alarm_dao = AlarmInfoDataAccess()
    performance_report = alarm_dao.get_performance_report(2)
    today = date.today()
    yesterday = today - timedelta(days=1)
    performance_report.query('report_date=="{}" & alarm_scope=="In"'.format(yesterday.strftime("%d-%b-%Y")),
                             inplace=True)
    performance_report.rename(index=str, columns={"report_date":"Report Date", "nodegroup":"Node Group",
                                                  "alarmname":"Alarm Name", "alarm_scope":"Alarm Scope",
                                                  "total_alarms":"Total Alarms", "auto_mode":"Auto Mode",
                                                  "total_action_taken":"Total Action Taken",
                                                  "no_1st_response_from_ava":"No 1st Response from AVA",
                                                  "cases_resolved":"Cases Resolved",
                                                  "ava_suggested_manual":"AVA suggested manual",
                                                  "task_required":"Task Required", "task_created":"Task Created",
                                                  "email_required":"Email Required", "email_sent":"Email Sent"
                                                  }, inplace=True)
    # performance_report.to_excel("Performance_Report.xlsx",index=False,sheet_name=yesterday.strftime("%d-%b-%Y"))
    xlsFilepath = 'Performance_Report.xlsx'
    writer = pd.ExcelWriter(xlsFilepath, engine='xlsxwriter')

    # Write excel to file using pandas to_excel
    performance_report.to_excel(writer, startrow=1, sheet_name=yesterday.strftime("%d-%b-%Y"), index=False)

    # Indicate workbook and worksheet for formatting
    workbook = writer.book
    worksheet = writer.sheets[yesterday.strftime("%d-%b-%Y")]
    adjust_excel_columns(worksheet,performance_report)
    writer.save()

    report_attachment = open(xlsFilepath,'rb')
    email_handler = EmailHandler();
    email_handler.sendmail(senderid=settings.EMAIL_FROM, to_recipient=settings.EMAIL_PERFORMANCE_REPORT_TO,
                           subject=Constants.PERFORMANCE_REPORT_EMAIL_SUBJECT.format(yesterday.strftime("%d-%b-%Y")),
                           body=Constants.PERFORMANCE_REPORT_EMAIL_BODY.format(yesterday.strftime("%d-%b-%Y")),
                           file=report_attachment)
    report_attachment.close()
    print("Emailed sucessfully")

# Method to readjust the excel columns
def adjust_excel_columns(worksheet, performance_report):
    # Iterate through each column and set the width == the max length in that column. A padding length of 2 is also added.
    for i, col in enumerate(performance_report.columns):
        # find length of column i
        column_len = performance_report[col].astype(str).str.len().max()
        # Setting the length if the column header is larger
        # than the max column value length
        column_len = max(column_len, len(col)) + 2
        # set the column length
        worksheet.set_column(i, i, column_len)


