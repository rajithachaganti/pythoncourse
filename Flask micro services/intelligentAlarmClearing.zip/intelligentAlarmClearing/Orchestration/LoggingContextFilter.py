import logging
from MDC import mdc


class LoggingContextFilter(logging.Filter):
    def filter(self, record):
        if hasattr(mdc, 'iacToken'):
            record.iacToken = mdc.iacToken
        else:
            record.iacToken = 'none'
        return True