import json
import inspect
import requests
import datetime
import settings
import traceback
import psycopg2 as p
from psycopg2.extras import RealDictCursor


class Utility():
    @staticmethod
    def refresh_rpa_token():
        global RPA_TOKEN
        r = requests.get(settings.RPA_LOGIN_URL, data=settings.RPA_LOGIN_DATA, headers={"Content-Type": "application/text"}, proxies=settings.NO_PROXY)
        if r.status_code == 200:
            RPA_TOKEN = "Bearer " + r.json()["access_token"]
            print("RPPA Token Refreshed")
            return True
        else:
            print("RPA Token Refresh failed")
            return False


class DB_Handler():
    def __init__(self):
        self.connection = self.getConnection()

    def getConnection(self):
        # print("Getting DB connection")
        try:
            return p.connect("dbname='" + settings.DATABASE_CONFIG["DATABASE"] + "' user='" + settings.DATABASE_CONFIG["USERNAME"] + "' password='" + settings.DATABASE_CONFIG["PASSWORD"] + "' host='" + settings.DATABASE_CONFIG["HOST"] + "' port='" + settings.DATABASE_CONFIG["PORT"] + "'")
        except BaseException as e:
            traceback.print_exc()

    def insert_json(self, jsoninput=None):
        try:
            with self.connection as conn:
                with conn.cursor() as cur:
                    cur.execute("insert into inputjsondetails(inputjson) values ('{}') returning jsonid".format(str(json.dumps(jsoninput)).replace("'", " ")))
                    return cur.fetchone()[0]
        except BaseException as e:
            print("Error ---------  " + str(e))
            traceback.print_exc()
            settings.logger.error(f"Error while inserting json {jsoninput} traceback: {traceback.format_exc()}")
            return None

    def get_sequencenum(self, iactoken):
        try:
            with self.connection as conn:
                with conn.cursor() as cur:
                    cur.execute("select count(iactoken) + 1 as seqnum from alarmcycle where iactoken='{}'".format(iactoken))
                    return cur.fetchone()[0]
        except BaseException as e:
            # print("Error ---------  " + str(e))
            # traceback.print_exc()
            settings.logger.error(f"Error while getting sequencenum for iactoken {iactoken} traceback: {traceback.format_exc()}")
            return None
    def update_alarmstatus(self, iactoken=None, status=None, message=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    if message is None:
                        message = ''
                    cur.execute("update alarminfo set status= {},message='{}',updatedtime=now() where iactoken='{}'".format(self.get_statuscode(status=status), message, str(iactoken)))
                    settings.logger.info(f"Updated iactoken:{iactoken} status:{status} traceback: {traceback.format_exc()}")
                    return True
        except BaseException as e:
            self.insert_alarmcycle(iactoken=iactoken, tasktype="Error", message="Error while updating alarm status, " + str(e))
            # print("Error ---------  " + str(e))
            # traceback.print_exc()
            settings.logger.error(f"Error while updating alarm status for iactoken:{iactoken} status:{status} traceback: {traceback.format_exc()}")
            return False
    def get_task(self, task):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("select taskid from tasktypes where lower(taskname)=lower('{}')".format(task))
                    return cur.fetchone()[0]
        except BaseException as e:
            # print("Error ---------  " + str(e))
            # traceback.print_exc()
            settings.logger.error(f"Error while getting task {task} traceback: {traceback.format_exc()}")
            return None

    def get_statuscode(self, status=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("select status_id from statuscodes where lower(status)=lower('{}')".format(status))
                    return cur.fetchone()[0]
        except BaseException as e:
            # print("Error ---------  " + str(e))
            settings.logger.error(f"Error while getting statuscode {status} traceback: {traceback.format_exc()}")
            # traceback.print_exc()
            return None

    def get_resolution_status(self, status=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("select resolutionstatus from resolutioncodes where resolutioncode={}".format(status))
                    return cur.fetchone()[0]

        except BaseException as e:
            # print("Error ---------  " + str(e))
            settings.logger.error(f"Error while getting statuscode {status} traceback: {traceback.format_exc()}")
            # traceback.print_exc()
            return None

    def execute_query(self, query=None, param=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    print(query, param)
                    if param is None:
                        cur.execute(query)
                    else:
                        cur.execute(query, param)
                    return cur.fetchone()[0]
        except BaseException as e:
            # print("Error ---------  " + str(e))
            # traceback.print_exc()
            settings.logger.error(f"Error while executing query {query} traceback: {traceback.format_exc()}")
            return None

    def insert_alarmcycle(self, iactoken=None, tasktype=None, parentid=None, resolutioncode=None, inputreceived=None, resolutionsummary=None, mmlcommand=None, mmloutput=None, commandname=None, message=None, username=None, rsname=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("insert into alarmcycle(iactoken,tasktype,tasktime,sequencenum,parentid,resolutioncode,inputreceived,resolutionsummary,mmlcommand,commandname,message,mmloutput,username,rsname) values(%s,%s,now(),%s,%s,%s,%s,%s,%s,%s,substring(%s from 1 for 128),%s,%s,%s) returning id",
                                (iactoken, self.get_task(tasktype), self.get_sequencenum(iactoken), parentid, resolutioncode,
                                 inputreceived, resolutionsummary, mmlcommand, commandname, message, mmloutput, username, rsname))
                    settings.logger.info(f"Inserted a row in alarmcycle iACToken: {iactoken} tasktype:{tasktype} resolutioncode:{resolutioncode}")
                    return cur.fetchone()[0]
        except BaseException as e:
            # print(f"Error while inserting alarmcycle iactoken={iactoken}")
            settings.logger.error(f"Error while inserting alarmcycle iactoken={iactoken} traceback: {traceback.format_exc()}")
            # traceback.print_exc()
            return None

    def update_message(self, message=None, cycleid=None):
        try:
            with self.connection as conn:
                with conn.cursor() as cur:
                    cur.execute("update alarmcycle set message='{}' where id={}".format(str(message), cycleid))
        except:
            jsonid = self.insert_json(jsoninput={"errordetails": traceback.format_exc()})
            settings.logger.error(f"Error while updating alarm message cycleid:{cycleid}, jsonid:{jsonid}  traceback: {traceback.format_exc()}")

    def update_ticketmessage(self, message=None, ticketid=None):
        try:
            with self.connection as conn:
                with conn.cursor() as cur:
                    cur.execute("update ticketdetails set message='{}' where ticketid='{}'".format(str(message), ticketid))
        except:
            jsonid = self.insert_json(jsoninput={"errordetails": traceback.format_exc()})
            settings.logger.error(f"Error while updating ticket message ticketid:{ticketid}, jsonid:{jsonid}  traceback: {traceback.format_exc()}")

    def check_previous_command(self, currentcmd=None, iactoken=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("select id,iactoken,mmlcommand,commandname from alarmcycle where iactoken='{}' and tasktype=5 order by tasktime desc limit 1".format(iactoken))
                    res = cur.fetchone()
                    if res is None:
                        return False
                    else:
                        if res[3] == currentcmd:
                            return True
                        else:
                            return False
        except BaseException as e:
            traceback.print_exc()
            settings.logger.error(f"Error while checking previous command, iactoken:{iactoken}, traceback: {traceback.format_exc()}")
            self.insert_alarmcycle(iactoken=iactoken, tasktype="Error", inputreceived=self.insert_json(jsoninput={"errordetails": traceback.format_exc()}), message="Error while checking previous command, " + str(e))
            self.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")
            return None

    def get_command_details(self, commandname=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("select criticalcommand,beforeexecute,reattempt from commanddictionary where commandname='{}'".format(commandname))
                    return cur.fetchone()
        except BaseException as e:
            # traceback.print_exc()
            settings.logger.error(f"Error while executing query {query} traceback: {traceback.format_exc()}")
            return None






def checkForKeys(inputjson, keys):
    missing_keys = []
    if keys is not None:
        for key in keys:
            if key not in inputjson:
                missing_keys.append(key)
        if missing_keys:
            return ",".join(missing_keys)
        else:
            return None
    else:
        return None


def checkForValues(inputjson, keys, nokeys):
    empty_keys = []
    result = None
    if (nokeys != None):
        result = "Mandatory Fields are missing. Fields are ({}). ".format(nokeys)
        keys = list(set(keys) - set(nokeys.split(',')))
    if keys is not None:
        for key in keys:
            if inputjson[key] == "" or inputjson[key] == None:
                empty_keys.append(key)
        if empty_keys:
            return ("" if nokeys is None else result) + "Mandatory fields are empty. Empty fields are (" + (",".join(empty_keys)) + ")"
        else:
            return result


def make_list(x):
    T = tuple(x)
    if len(T) > 1:
        return T
    else:
        return T[0]


def join_list(x):
    slist = []
    for l in x:
        if isinstance(l, dict):
            slist = x
            break
        slist.extend(l)
    return slist


def datetimeconverter(o):
    if isinstance(o, datetime.datetime):
        return o.__str__()


# def checkForValues(inputjson, keys,nokeys):
# empty_keys = []
# result=None
# if(nokeys != None):
# result="Mandatory Fields are missing. Fields are ({}). ".format(nokeys)
# keys=list(set(keys)-set(nokeys.split(',')))
# for key in keys:
# if inputjson[key] == "" or inputjson[key] == None:
# empty_keys.append(key)
# if empty_keys:
# return ("" if nokeys is None else result)+ "Mandatory fields are empty. Empty fields are (" +(",".join(empty_keys))+")"
# else:
# return result
def chkval(obj):
    if obj is None or obj == "" or obj == "null" or obj == "Null":
        return None
    else:
        if isinstance(obj, (int)):
            return str(obj)
        else:
            return obj


def split_dict(inputjson, keys):
    dictfilt = lambda x, y: dict([(i, x[i]) for i in x if i in set(y)])
    tmp = inputjson.keys()
    remainkeys = list(set(keys) ^ set(tmp))
    result = dictfilt(inputjson, remainkeys)
    return result


def isiAC1AutoAlarm(alrmNm):
    retflag = False
    if settings.PROCESS_iAC1_AUTO_ALARMS:
        if (alrmNm in settings.iAC1_AUTO_ALARM_LIST):
            print(f"Element {alrmNm} found")
            retflag = True
        else:
            print(f"Element {alrmNm} NOT found")
    return retflag


def lineno():
    """Returns the current line number in our program."""
    return inspect.currentframe().f_back.f_lineno


def validate_json(jsoninput):
    if isinstance(jsoninput, dict):
        if bool(jsoninput):
            return True
        else:
            return False
    else:
        print('Invalid JSON')
        return False


class InputJSONError(Exception):
    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def __str__(self):
        return self.message


class TicketError(Exception):
    def __init__(self, message):
        super().__init__(message)

        self.message = message

    def __str__(self):
        return self.message


class AlarmError(Exception):
    def __init__(self, message):
        super().__init__(message)

        self.message = message

    def __str__(self):
        return self.message
