from prometheus_client import Counter
import logging


class LogCounterHandler(logging.handlers.RotatingFileHandler):
    level2count = None

    def __init__(self, *args, **kwargs):
        super(LogCounterHandler, self).__init__(*args, **kwargs)
        self.level2count = {}

    def emit(self, record):
        l = record.levelname
        if (l not in self.level2count):
            self.level2count[l] = Counter(l.capitalize(), f"No. of {l.lower()}")
        self.level2count[l].inc()
        print(self.level2count)
