import smtplib, ssl

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
import settings
import traceback
from os.path import basename
from email import encoders
import pandas as pd
from .Utilities import *
import numpy as np

class EmailHandler:
    def __init__(self):
        self.smtpserver = settings.SMTP_SERVER
        self.smtpport = settings.SMTP_PORT

    # def path_leaf(path):
    #     head, tail = ntpath.split(path)
    #     return tail or ntpath.basename(head)

    def sendmail(self, senderid, to_recipient,  subject, body, cc_recipient=None, bcc_recipient=None, file=None):
        try:
            # Create a multipart message and set headers
            message = MIMEMultipart()
            message["From"] = senderid
            message["To"] = ', '.join(to_recipient)
            if cc_recipient:
                message["Cc"] = ', '.join(cc_recipient)
            if bcc_recipient:
                message["Bcc"] = ', '.join(bcc_recipient)

            message["Subject"] = subject
            message.attach(MIMEText(body, 'html'))
            # with open(f, "rb") as fil:
            if file is not None:
                part = MIMEBase('application', "octet-stream")
                part.set_payload(file.read())
                encoders.encode_base64(part)
                # After the file is closed
                part['Content-Disposition'] = 'attachment; filename="%s"' % file.name
                message.attach(part)
            text = message.as_string()
            with smtplib.SMTP(self.smtpserver, self.smtpport) as server:
                # server.login(sender_email, password)   # we don't need that
                server.sendmail(senderid, to_recipient, text)

        except BaseException as e:
            traceback.print_exc()
            settings.logger.error(f"Error while sending email traceback:{traceback.format_exc()}")

    def send_mail(self,jsoninput=None):
        response = {"iacstatus": "Fail", "iacerrordetails": "Unknown"}
        settings.logger.info(f"Processing send_mail request with JSON")

        try:
            if (jsoninput is None):
                print("Invalid/Null JSON");
                response["iacerrordetails"] = "Invalid/Null JSON"
                return response;

            mail_details = pd.Series(jsoninput, index=["SenderID", "ToList", "Subject",
                                                       "Message", "CCList", "BCCList"])
            mail_details.replace({np.nan: None}, inplace=True)
            settings.logger.debug(f"Processing send mail for Subject : {mail_details['Subject']} "
                                  f"to {mail_details['ToList']}")
            w = checkForValues(mail_details, ["SenderID", "ToList", "Subject", "Message"], None)
            if w is None:
                self.sendmail(mail_details['SenderID'], mail_details['ToList'],
                    mail_details['Subject'], mail_details['Message'])
                response["iacstatus"] = "Success"
                response["iacerrordetails"] = "Mail sent successfully"
                settings.logger.info(f"Successfully sent the mail with subject {mail_details['Subject']}")
            else:
                settings.logger.error(f"Failed to send mail, {w}")
                response["iacstatus"] = "Fail"
                response["iacerrordetails"] = f"Mail send failed, {w}"
        except:
            settings.logger.error(f"Exception while sending email, traceback:{traceback.format_exc()}")
            response["iacstatus"] = "Fail"
            response["iacerrordetails"] = "Exception while sending mail, "

        return response
