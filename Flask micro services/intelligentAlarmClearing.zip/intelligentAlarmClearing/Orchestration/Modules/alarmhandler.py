from .Utilities import *
import traceback
import uuid
from .Commons import getConnection
from psycopg2 import DatabaseError
import settings


class AlarmHandler:
    def __init__(self):
        self.mandatoryAlarmFields = ['customer', 'vendorType', 'nodeName', 'nodeType', 'alarmText', 'eventTime', 'additionalInfo']
        self.connection = getConnection()
        # self.connection.autocommit = False

    def __del__(self):
        self.connection.close()

    def generate_alarmjson(self, inscopealarms):
        try:
            finaljson = list()
            for iactoken in inscopealarms:
                finaljson.append(self.generate_alarmjson2(iactoken))
            return finaljson
        except:
            traceback.print_exc()
            return None

    def generate_alarmjson2(self, iactoken):
        try:
            result = {}
            with self.connection:
                with self.connection.cursor() as cur:
                    i = 0
                    cur.execute("select iactoken,additionalinfo,additionalfields,a.alarmnumber,a.alarmname,a.customer,eventtime,nodeparent,nodeid,nodename,a.nodetype,a.nodevendor,c.nodeversion,c.solrsearchcol from alarminfo a left join alarmkeycolumns c on a.iacalarmid=c.iacalarmid where a.iactoken ='{}'".format(iactoken))
                    res = cur.fetchone()
                    result = {}
                    result["iACToken"] = res[0]
                    result["AdditionalInfo"] = res[1]
                    result["AdditionalFields"] = res[2]
                    result["AlarmNumber"] = res[3]
                    result["AlarmName"] = res[4]
                    result["Customer"] = res[5]
                    result["EventTime"] = res[6].strftime('%Y-%m-%d %H:%M:%S')
                    result["NodeParent"] = res[7]
                    result["NodeID"] = res[8]
                    result["NodeName"] = res[9]
                    result["NodeType"] = res[10]
                    result["NodeVendor"] = res[11]
                    result["NodeVersion"] = res[12]
                    result["solrsearchcols"] = res[13]
                    cur.execute("select json_agg(mmlcommand order by sequencenum),json_agg(mmloutput order by sequencenum),json_agg(commandname order by sequencenum) from alarmcycle where iactoken='{}' and tasktype=5".format(iactoken))
                    res2 = cur.fetchall()
                    print(res2)
                    cur.execute(" select json_agg(inputjson -> 'ParserOutput' order by jsonid),json_agg(inputjson -> 'PredictorOutput' -> 'rules' order by jsonid),json_agg(inputjson -> 'PredictorOutput' -> 'rulesResults' order by jsonid) from inputjsondetails where jsonid in (select inputreceived from alarmcycle where iactoken='{}' and tasktype=2)".format(iactoken))
                    res3 = cur.fetchall()
                    # print(res3)
                    # print("----------------generate alarm to ps")
                    # cur.execute("select json_agg(commandname order by sequencenum) from alarmcycle where iactoken='{}' and tasktype=4".format(iactoken))
                    # res4 = cur.fetchall()
                    if res2[0][0] is not None:
                        if res3[0][1] is not None:
                            del (res3[0][1])[0]
                        if res3[0][2] is not None:
                            del (res3[0][2])[0]

                        result["History"] = {"cmd_list": res2[0][0], "output_list": res2[0][1], "parser_list": res3[0][0], "rules_list": res3[0][1], "rulesresults_list": res3[0][2], "commandname_list": res2[0][2]}
                    else:
                        result["History"] = {}
                    return result
        except:
            traceback.print_exc()
            return None

    #FIXME: Not used method
    def send_alarm_to_ps(self, iactoken):
        try:
            print("Sending mml to ps...")
            alarmjson = AlarmHandler().generate_alarmjson2(self.connection, iactoken)
            print(alarmjson)
            r = requests.post(settings.PREDICT_URL, json=alarmjson)
            if r.status_code == 200:
                with self.connection as conn:
                    with conn.cursor() as cur:
                        cur.execute("insert into inputjsondetails(inputjson) values ('{}') returning jsonid".format(json.dumps(alarmjson)))
                        inputjson = cur.fetchone()[0]
                        cur.execute("insert into alarmcycle(iactoken,tasktype,tasktime,sequencenum,inputreceived) values(%s,%s,now(),%s,%s)",
                                    (iactoken, self.get_task("Output to Predictive Service"), self.get_sequencenum(iactoken), inputjson))
                print("sent to ps success")
                return "Success"
            else:
                print("sent to ps failed: {}".format(r.content))
                return "Failed"
        except:
            traceback.print_exc()
            return "Failed"

    def get_status(self, statuscode):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("select status_id from statuscodes where status='{}'".format(statuscode))
                    return cur.fetchone()[0]
        except:
            traceback.print_exc()
            return None

    def get_lastalarm(self, alarm):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("select eventtime from alarminfo where customer=%s and alarmname=%s and nodename=%s and nodeid =%s and nodetype=%s and nodeparent=%s and eventtime >= timestamp %s - interval '1 minute' order by eventtime desc limit 1", (alarm["customer"], alarm['alarmText'], alarm['nodeName'], alarm['nodeId'], alarm['nodeType'], alarm['ParentId'], alarm['eventTime']))
                    r = cur.fetchone()
                    return r
        except BaseException as e:
            traceback.print_exc()
            return None

    def get_task(self, task):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("select taskid from tasktypes where lower(taskname)=lower('{}')".format(task))
                    return cur.fetchone()[0]
        except BaseException as e:
            traceback.print_exc()
            return None

    def get_alarm(self, alarm):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("select iacalarmid from alarmkeycolumns where customer='{}' and nodevendor='{}' and nodetype='{}' and alarmnumber='{}' and alarmname='{}'".format(alarm["customer"], alarm["vendorType"], alarm["nodeType"], alarm["alarmNumber"], alarm["alarmText"]))
                    iacalarmid = cur.fetchone()[0]
                    # alarmkey=AlarmKeyColumns.objects.get(customer=alarm["customer"], nodevendor=alarm["vendorType"], nodetype=alarm["nodeType"], alarmnumber=alarm["alarmNumber"], alarmname=alarm["alarmText"])
        except:
            traceback.print_exc()
            return None
        else:
            return iacalarmid
        return AlarmInfo.objects.get(iactoken=iactoken)

    def add_entry_to_alarmcycle(self, iactokens, jsonid):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    for iactoken in iactokens:
                        cur.execute("insert into alamcycle(iactoken,tasktype,sequencenum,inputreceived)".format(iactoken, self.get_task('Alarm to Predictive Service'), 1, jsonid))
        except:
            traceback.print_exc()

    def get_alarmkeycolumn(self, alarm):
        try:
            print("......Getting alarmkeyid")
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("select iacalarmid,jsonmandatorycols as mandatorycols,alarmnumber,executionmode,nodegroup from alarmkeycolumns where customer='{}' and nodevendor='{}' and alarmname='{}'".format(alarm["customer"], alarm["vendorType"], alarm["alarmText"]))
                    res = cur.fetchone()
                    if res is not None:
                        iacalarm = dict()
                        iacalarm["iacalarmid"] = res[0]
                        iacalarm["mandatorycols"] = res[1]
                        iacalarm["alarmnumber"] = res[2]
                        iacalarm["executionmode"] = res[3]
                        iacalarm["nodegroup"] = res[4]
                        print("Alarmkey id ", iacalarm)
                        return iacalarm
                    return None
        except:
            print("")
            traceback.print_exc()
            return None

    def process_alarm(self, alarmjson=None, ticket=None, inputjson=None):
        insertediactokens = []
        inscopeiactokens = []
        j = 0
        if isinstance(alarmjson, list):
            for alarm in alarmjson:
                try:
                    v = checkForKeys(alarm, self.mandatoryAlarmFields)
                    w = checkForValues(alarm, self.mandatoryAlarmFields, v)
                    if v == None and w == None:
                        alarmkeyid = self.get_alarmkeycolumn(alarm)
                        with self.connection as conn:
                            with conn.cursor() as cur:
                                if alarmkeyid is not None:
                                    print("...Processing inscope alarm")
                                    v = checkForKeys(alarm, alarmkeyid["mandatorycols"])
                                    w = checkForValues(alarm, alarmkeyid["mandatorycols"], v)
                                    if v == None and w == None:
                                        status = self.get_status("Processing")
                                        w = checkForKeys(alarm, ['robotUID'])
                                        if w == None:
                                            cur.execute("insert into alarminfo(iactoken,ticketid,additionalinfo,nodeid,nodename,additionalfields,customer,nodevendor,status,nodetype,alarmnumber,alarmname,eventtime,scope,iacalarmid,iac_time,updatedtime) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,now(),now()) returning iactoken", (alarm["robotUID"], ticket, alarm["additionalInfo"], alarm["bcfID"], alarm["nodeName"], json.dumps(split_dict(alarm, ['robotUID', 'bcfID', 'customer', 'vendorType', 'nodeName', 'nodeType', 'alarmNumber', 'alarmText', 'eventTime', 'additionalInfo'])), alarm["customer"], alarm["vendorType"], status, alarm["nodeType"], alarmkeyid["alarmnumber"], alarm["alarmText"], alarm["eventTime"], "In", alarmkeyid["iacalarmid"]))
                                        else:
                                            cur.execute("insert into alarminfo(iactoken,ticketid,additionalinfo,nodeid,nodename,additionalfields,customer,nodevendor,status,nodetype,alarmnumber,alarmname,eventtime,scope,iacalarmid,iac_time,updatedtime) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,now(),now()) returning iactoken", (str(uuid.uuid1()), ticket, alarm["additionalInfo"], alarm["bcfID"], alarm["nodeName"], json.dumps(split_dict(alarm, ['bcfID', 'customer', 'vendorType', 'nodeName', 'nodeType', 'alarmNumber', 'alarmText', 'eventTime', 'additionalInfo'])), alarm["customer"], alarm["vendorType"], status, alarm["nodeType"], alarmkeyid["alarmnumber"], alarm["alarmText"], alarm["eventTime"], "In", alarmkeyid["iacalarmid"]))
                                        iacalarm = cur.fetchone()[0]
                                        insertediactokens.append(iacalarm)
                                        inscopeiactokens.append(iacalarm)
                                        cur.execute("insert into alarmcycle(iactoken,tasktype,tasktime,sequencenum,inputreceived) values(%s,%s,now(),%s,%s)", (iacalarm, self.get_task("Cycle Start"), 1, inputjson))
                                        cur.execute("insert into alarmcycle(iactoken,tasktype,tasktime,sequencenum,inputreceived) values(%s,%s,now(),%s,%s)", (iacalarm, self.get_task("Alarm to Predictive Service"), 2, inputjson))
                                        alarmjson[j]['iactoken'] = iacalarm
                                        alarmjson[j]['iacstatus'] = 'Success'
                                        alarmjson[j]['iacerrordetails'] = ''
                                    else:
                                        alarmjson[j]['iacstatus'] = 'Failed'
                                        alarmjson[j]['iacerrordetails'] = w  # 'Mandatory Fields are missing. Fields are ({})'.format(v)
                                else:
                                    print("...Processing outscope alarm")
                                    w = checkForKeys(alarm, ['robotUID'])
                                    if w == None:
                                        cur.execute("insert into alarminfo(iactoken,ticketid,additionalinfo,nodeid,nodename,additionalfields,customer,nodevendor,status,nodetype,alarmnumber,alarmname,eventtime,scope,iac_time,updatedtime) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,now(),now()) returning iactoken", (alarm["robotUID"], ticket, alarm["additionalInfo"], alarm["bcfID"], alarm["nodeName"], json.dumps(split_dict(alarm, ['robotUID', 'bcfID', 'customer', 'vendorType', 'nodeName', 'nodeType', 'alarmNumber', 'alarmText', 'eventTime', 'additionalInfo'])), alarm["customer"], alarm["vendorType"], None, alarm["nodeType"], alarm["alarmNumber"], alarm["alarmText"], alarm["eventTime"], "Out"))
                                    else:
                                        cur.execute("insert into alarminfo(iactoken,ticketid,additionalinfo,nodeid,nodename,additionalfields,customer,nodevendor,status,nodetype,alarmnumber,alarmname,eventtime,scope,iac_time,updatedtime) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,now(),now()) returning iactoken", (str(uuid.uuid1()), ticket, alarm["additionalInfo"], alarm["bcfID"], alarm["nodeName"], json.dumps(split_dict(alarm, ['bcfID', 'customer', 'vendorType', 'nodeName', 'nodeType', 'alarmNumber', 'alarmText', 'eventTime', 'additionalInfo'])), alarm["customer"], alarm["vendorType"], None, alarm["nodeType"], alarm["alarmNumber"], alarm["alarmText"], alarm["eventTime"], "Out"))
                                    iacalarm = cur.fetchone()[0]
                                    insertediactokens.append(iacalarm)
                                    alarmjson[j]['iactoken'] = iacalarm
                                    alarmjson[j]['iacstatus'] = 'Success'
                                    alarmjson[j]['iacerrordetails'] = ''
                    else:
                        alarmjson[j]['iacstatus'] = 'Failed'
                        alarmjson[j]['iacerrordetails'] = w  # 'Mandatory fields are empty. Fields are ({})'.format(w)
                except DatabaseError as e:
                    print("Error ---------" + str(e))

                    if "duplicate key" in e.args[0]:
                        print("--------Duplicate Alarm")
                        alarmjson[j]['iacstatus'] = "Failed"
                        alarmjson[j]['iacerrordetails'] = "Duplicate Alarm"
                    else:
                        traceback.print_exc()
                        alarmjson[j]['iacstatus'] = 'Failed'
                        alarmjson[j]['iacerrordetails'] = str(e)
                except BaseException as e:
                    traceback.print_exc()
                    print("Error ---------" + str(e))

                    alarmjson[j]['iacstatus'] = 'Failed'
                    alarmjson[j]['iacerrordetails'] = str(e)
                    traceback.print_exc()
                finally:
                    j += 1
        return alarmjson, insertediactokens, inscopeiactokens
