import psycopg2 as p
from psycopg2.extras import RealDictCursor
import json
import falcon
from falcon.http_error import HTTPError
from Services import *	#For API logic registers
import settings
import traceback
isTokenEnabled=True
isLocalPrintEnabled=False

database='iac'
user='iac'
password='iac@!451'
host='192.168.0.17'
port='5432'

res_data=None
res_msg=None
res_status=None
def getConnection():
    # print("Getting DB connection")
    try:
        return p.connect("dbname='"+settings.DATABASE_CONFIG["DATABASE"]+"' user='"+settings.DATABASE_CONFIG["USERNAME"]+"' password='"+settings.DATABASE_CONFIG["PASSWORD"]+"' host='"+settings.DATABASE_CONFIG["HOST"]+"' port='"+settings.DATABASE_CONFIG["PORT"]+"'")
    except BaseException as e:
        traceback.print_exc()
        RaiseError(453,str(e.args[0]))
        cprint(e.args[0])
        
def renameKeysToLower(iterable):
    if type(iterable) is dict:
        for key in iterable.keys():
            iterable[key.lower()] = iterable.pop(key)
            if type(iterable[key.lower()]) is dict or type(iterable[key.lower()]) is list:
                iterable[key.lower()] = renameKeysToLower(iterable[key.lower()])
    elif type(iterable) is list:
        for item in iterable:
            item = renameKeysToLower(item)
    return iterable
def connectNative(stmt):
	con = getConnection()
	cur = con.cursor()
	cur.execute(stmt)
	result = cur.fetchall()
	cur.close()
	con.close()
	return result
	
def connectNativeArray(stmt):
	con = getConnection()
	cur = con.cursor()
	cur.execute(stmt)
	result = [r[0] for r in cur.fetchall()]
	cur.close()
	con.close()
	return result
	
def insertWithoutQueryData(stmt):
	#con = None
	result = ''
	try:
		con = getConnection()
		cur = con.cursor()
		cur.execute(stmt)
		result = cur.rowcount
		con.commit()
	#except (Exception, psycopg2.DatabaseError) as error:
	except (Exception, p.Error) as error :
		if(con):
			cprint("Failed to insert record into table", error)
	finally:
        # closing database connection.
		if (con):
			cur.close()
			con.close()
			cprint("PostgreSQL connection is closed")
	return result
	
def insertDataWithInsertID(stmt):
	#con = None
	id_of_new_row = None
	try:
		con = getConnection()
		cur = con.cursor(cursor_factory=RealDictCursor)
		cur.execute(stmt)
		con.commit()
		cur.execute('SELECT LASTVAL()')
		id_of_new_row = cur.fetchone()['lastval']
		#id_of_new_row = cur.fetchone()[0]
	except (Exception, p.Error) as error :
		if(con):
			cprint("Failed to Select/insert record into table", error)
			#resp.body = response_wrapper(500,error)
			#resp.status=falcon.HTTP_500
	finally:
        # closing database connection.
		if (con):
			cur.close()
			con.close()
			cprint("PostgreSQL connection is closed")
	return id_of_new_row
	
def deleteall():
	with getConnection() as conn:
		with conn.cursor() as cur:
			cur.execute("delete from alarmcycle")
			cur.execute("delete from alarminfo")
			cur.execute("delete from inputjsondetails")
			cur.execute("delete from ticketdetails")
		conn.commit()
	conn.close()
#def connectFetchJSON(stmt):
#	cur = p.connect(database=database, user=settings.DATABASE_CONFIG["USER"], password=settings.DATABASE_CONFIG["PASSWORD"], host=settings.DATABASE_CONFIG["HOST"], port=settings.DATABASE_CONFIG["PORT"]).cursor(cursor_factory=RealDictCursor)
#	cur.execute(stmt)
#	result = cur.fetchall()
#	cur.close()
#	return result
	

	
def isRoute(route_path,path):
	if route_path == path:
		return True
	else:
		return False
		
def checkKey(dict, key): 
    if key in dict: 
        return True
    else: 
        return False
		
def random_with_N_digits(n):
    range_start = 10**(n-1)
    range_end = (10**n)-1
    return randint(range_start, range_end)
	
def token_exists(token):
	cprint(settings.DATABASE_CONFIG["DATABASE"])
	con = getConnection()
	cur = con.cursor()
	#cur = self.conn.cursor()
	cur.execute("SELECT username,token FROM token WHERE token = %s and updatedtime > now() - interval '30 minutes'", (token,))
	return cur.fetchone() is not None
	
def user_exists(username,passwd):	
	con = getConnection()
	cur = con.cursor()
	#cur = self.conn.cursor()
	cur.execute("SELECT username,enabled FROM users WHERE username = %s and password = crypt(%s, password)", (username,passwd))
	
	return cur.fetchone() is not None

def connectUpdationsNoResp(stmt,data):
	#con = None
	try:
		con = getConnection()
		cur = con.cursor()
		cur.execute(stmt,data)
		result = cur.rowcount
		con.commit()
	#except (Exception, psycopg2.DatabaseError) as error:
	except (Exception, p.Error) as error :
		if(con):
			cprint("Failed to insert record into table", error)
	finally:
        # closing database connection.
		if (con):
			cur.close()
			con.close()
			# cprint("PostgreSQL connection is closed")
	return "Updated"

def connectUpdationsNormal(stmt,data):
	#con = None
	try:
		con = getConnection()
		cur = con.cursor()
		cur.execute(stmt,data)
		result = cur.rowcount
		con.commit()
	#except (Exception, psycopg2.DatabaseError) as error:
	except (Exception, p.Error) as error :
		if(con):
			cprint("Failed to insert record into table", error)
	finally:
        # closing database connection.
		if (con):
			cur.close()
			con.close()
			# cprint("PostgreSQL connection is closed")
	return result
	
def connectUpdations(stmt,data,resp):
	#con = None
	try:
		con = getConnection()
		cur = con.cursor()
		cur.execute(stmt,data)
		result = cur.rowcount
		con.commit()
		resp.body = response_wrapper(200,result)
	#except (Exception, psycopg2.DatabaseError) as error:
	except (Exception, p.Error) as error :
		if(con):
			cprint("Failed to insert record into table", error)
			resp.body = response_wrapper(500,error)
			resp.status=falcon.HTTP_500
	finally:
        # closing database connection.
		if (con):
			cur.close()
			con.close()
			# cprint("PostgreSQL connection is closed")
	return resp
	
def connectFetchJSON(stmt,stmt_data,resp):
	#con = None
	try:
		con = getConnection()
		cur = con.cursor(cursor_factory=RealDictCursor)
		cur.execute(stmt,stmt_data)
		if stmt.startswith("insert") or stmt.startswith("update") or stmt.startswith("delete"):
			result = cur.rowcount
			con.commit()
		else:
			result = cur.fetchall()
		resp.body = response_wrapper(200,result)
	except (Exception, p.Error) as error :
		if(con):
			cprint("Failed to Select/insert record into table", error)
			resp.body = response_wrapper(500,error)
			resp.status=falcon.HTTP_500
	finally:
        # closing database connection.
		if (con):
			cur.close()
			con.close()
			# cprint("PostgreSQL connection is closed")
	return resp

def connectFetchJSONWihtoutQueryData(stmt,resp):
	#con = None
	try:
		con = getConnection()
		cur = con.cursor(cursor_factory=RealDictCursor)
		cur.execute(stmt)
		if stmt.startswith("insert") or stmt.startswith("update"):
			result = cur.rowcount
			con.commit()
		else:
			result = cur.fetchall()
		resp.body = response_wrapper(200,result)
	except (Exception, p.Error) as error :
		if(con):
			cprint("Failed to Select/insert record into table", error)
			resp.body = response_wrapper(500,error)
			resp.status=falcon.HTTP_500
	finally:
        # closing database connection.
		if (con):
			cur.close()
			con.close()
			# cprint("PostgreSQL connection is closed")
	return resp

def connectFetchJSONWihtoutQueryDataNoResponse(stmt,resp):
	#con = None
	result = ""
	try:
		con = getConnection()
		cur = con.cursor(cursor_factory=RealDictCursor)
		cur.execute(stmt)
		if stmt.startswith("insert") or stmt.startswith("update"):
			result = cur.rowcount
			con.commit()
		else:
			result = cur.fetchall()
		# resp.body = response_wrapper(200,result)
	except (Exception, p.Error) as error :
		if(con):
			cprint("Failed to Select/insert record into table", error)
			# resp.body = response_wrapper(500,error)
			# resp.status=falcon.HTTP_500
	finally:
        # closing database connection.
		if (con):
			cur.close()
			con.close()
			# cprint("PostgreSQL connection is closed")
	return result
	
def response_wrapper(status,data):
	json_data = {}
	if(status == 200):
		res_msg="Data Retrieved"
		res_status=200
		res_error=''
		json_data = {'data':data,'msg':res_msg,'status':res_status,'error':res_error}
	elif(status == 500):
		res_msg="Internal Server Error"
		res_status=500
		res_error=str(data)
		json_data = {'data':[],'msg':res_msg,'status':res_status,'error':res_error}
	elif(status == 401):
		res_msg="Invalid Credentials"
		res_status=401
		res_error=''
		json_data = {'data':data,'msg':res_msg,'status':res_status,'error':res_error}
	elif(status == 4001):
		res_msg="Auth Token Not Found"
		res_status=401
		res_error=''
		json_data = {'data':data,'msg':res_msg,'status':res_status,'error':res_error}
	elif(status == 4002):
		res_msg="Invalid Token/Expired"
		res_status=401
		res_error=''
		json_data = {'data':data,'msg':res_msg,'status':res_status,'error':res_error}
	elif(status == 404):
		res_msg="Service Not Found"
		res_status=404
		res_error=''
		json_data = {'data':data,'msg':res_msg,'status':res_status,'error':res_error}
	return json.dumps(json_data)
	
class ErrorHandler:
	@staticmethod
	def http(ex, req, resp, params):
		LoggerInfoUpdate(req,ex)
		raise
	@staticmethod
	def unexpected(ex, req, resp, params):
		cprint("uuuuuuuuuuuuuuuuu")
		cprint(type(ex))
		cprint(str(ex))
		RaiseError(1000,str(ex))
		#logger.exception('Unexpected Application Error')
		#raise falcon.HTTPInternalServerError()

class MyHTTPError(HTTPError):
	"""Represents a generic HTTP error.
    """
	def __init__(self, status, error):
		super(MyHTTPError, self).__init__(status)
		self.status = status
		self.body = json.dumps(error)
	def to_dict(self, obj_type=dict):
		"""Returns a basic dictionary representing the error.
        """
		#super(MyHTTPError, self).to_dict(obj_type)
		obj = self.body
		return json.loads(obj)

ERROR_CODES = {
	500:{"error_code":"XX0000ERR500YY","msg":"Internal Server Error","code":falcon.HTTP_500},
	401:{"error_code":"XX0000ERR401YY","msg":"Unauthorized","code":falcon.HTTP_401},
	451:{"error_code":"IAC000150001","msg":"Internal Server Error","code":falcon.HTTP_412}, #Error -> Key is Null
	452:{"error_code":"IAC000150002","msg":"Internal Server Error","code":falcon.HTTP_412}, #Error -> Key is Not Found
	453:{"error_code":"IAC000150003","msg":"Internal Server Error","code":falcon.HTTP_412},
	454:{"error_code":"IAC000150004","msg":"Internal Server Error","code":falcon.HTTP_412},
	455:{"error_code":"IAC000150005","msg":"Internal Server Error","code":falcon.HTTP_412},
	456:{"error_code":"IAC000150006","msg":"Internal Server Error","code":falcon.HTTP_412},
	457:{"error_code":"IAC000150007","msg":"Internal Server Error","code":falcon.HTTP_412},
	458:{"error_code":"IAC000150008","msg":"Internal Server Error","code":falcon.HTTP_412},
	459:{"error_code":"IAC000150009","msg":"Internal Server Error","code":falcon.HTTP_412},
	460:{"error_code":"IAC000150010","msg":"Internal Server Error","code":falcon.HTTP_412},
	461:{"error_code":"IAC000150011","msg":"Internal Server Error","code":falcon.HTTP_412},
	1000:{"error_code":"XX0000ERR1000YY","msg":"Internal Server Error","code":falcon.HTTP_500}
}

def RaiseError(status,data):
	res_msg=ERROR_CODES[status]["msg"]
	res_status=status
	#res_error=str(data)
	res_error={"error_code":ERROR_CODES[status]["error_code"],"traceout":data}
	error_data = {'data':[],'msg':res_msg,'status':res_status,'error_details':res_error}
	cprint(error_data)
	raise MyHTTPError(ERROR_CODES[status]["code"], error_data)

def LoggerInfo(req,body):
	#env = req.env
	#cprint(env)
	#token = "token test"
	#user_id = 2
	route_path = str(req.path)
	if checkKey(SKIP_TOKEN,route_path) == False:
		token = req.get_header('token')
		query = "select user_id from users a left join token b on a.username=b.username where token='"+token+"'"
		user_id = connectNativeArray(query)
		orgin = req.uri
		method = req.method
		useragent = req.user_agent
		#app = req.app
		app = settings.APP_NAME
		api = req.path
		refererurl = req.referer
		if method == "GET":
			input_data = "{}"
		else:
			input_data = body.decode('utf-8')
		content_type = req.content_type
		#input_data = {}
		query = "insert into auditlog(user_id,token,method,orgin,useragent,app,api,refererurl,visitedtime,input_data,content_type) values({},'{}','{}','{}','{}','{}','{}','{}','{}','{}','{}')".format(user_id[0],token,method,orgin,useragent,app,api,refererurl,'now()',str(input_data),content_type)
		#query = "insert into auditlog(user_id,token,orgin,useragent,app,api,refererurl,visitedtime,input_data) values({},'{}','{}','{}','{}','{}','{}','{}','{}')".format(user_id,token,orgin,useragent,app,api,refererurl,'now()',str(input_data))
		return insertDataWithInsertID(query)

def LoggerInfoUpdate(req,resp):
	route_path = str(req.path)
	if checkKey(SKIP_TOKEN,route_path) == False:
		if "req_id"  in req.context:
			cprint("Resp Body")
			cprint(resp.body)
			output_data = resp.body
			cprint("Req id = "+str(req.context["req_id"]))
			query = "update auditlog set output_data='{}' where id={}".format(str(output_data),req.context["req_id"])
			insertWithoutQueryData(query)

def cprint(self,msg=''):
	i = 0
	local_msg = msg
	if msg == '':
		local_msg = self
	if isLocalPrintEnabled == True:
		logger.info(local_msg)