import traceback
from json import JSONDecodeError
from .Commons import *
from .Utilities import *
from .alljsonschema import *
from .alarmhandler import AlarmHandler
from .tickethandler import TicketHandler
from .mmlhandler import MmlHandler
from .businessrulehandler import BusinessRuleHandler
from jsonschema import validate, Draft4Validator, FormatChecker
from jsonschema.exceptions import ValidationError
from .alljsonschema import *
import pandas as pd
import numpy as np
import time
import uuid

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', 10000)
pd.set_option('display.width', 100000)


class JSONValidator:
    def __init__(self):
        self.connection = getConnection()
        self.df_akc = None
        self.mmlhandler=MmlHandler()

        with self.connection as conn:
            with conn.cursor() as cur:
                self.df_akc = pd.read_sql("select * from alarmkeycolumns", getConnection())
        # self.connection.autocommit=False
        # self.pdoption=pd.option_context('display.max_rows', None, 'display.max_columns', 1000,'display.width', 225)

    def __del__(self):
        self.connection.close()

    def handle_json(self, jsoninput):
        try:
            i = 0
            # code=falcon.HTTP_200
            predictjson = {}
            insertedAlarmsID = []
            inscopeiactokens = []
            v = validate_json(jsoninput)
            if v == True:

                try:
                    with self.connection as conn:
                        conn.autocommit = True
                        with conn.cursor() as cur:
                            cur.execute("insert into inputjsondetails(inputjson) values ('{}') returning jsonid".format(json.dumps(jsoninput)))
                            inputjson = cur.fetchone()[0]
                            if checkForKeys(jsoninput, ['Tickets']) is None:
                                ticketjson, ia, ina = TicketHandler().process_ticket(jsoninput['Tickets'], inputjson)
                                jsoninput['Tickets'] = ticketjson
                                insertedAlarmsID = list(set(insertedAlarmsID + ia))
                                inscopeiactokens = list(set(inscopeiactokens + ina))
                            if checkForKeys(jsoninput, ['Alarms']) is None:
                                if isinstance(jsoninput['Alarms'], list):
                                    if jsoninput['Alarms']:
                                        alarmjson, ia, ina = AlarmHandler().process_alarm(jsoninput['Alarms'], ticket=None, inputjson=inputjson)
                                        insertedAlarmsID = list(set(insertedAlarmsID + ia))
                                        inscopeiactokens = list(set(inscopeiactokens + ina))
                                        jsoninput['Alarms'] = alarmjson
                                        if len(insertedAlarmsID) > 0:
                                            jsoninput["iacstatus"] = "Success"
                                            jsoninput["iacerrordetails"] = ""
                                        else:
                                            jsoninput["iacstatus"] = "Failed"
                                            jsoninput["iacerrordetails"] = "Issues in alarms"
                                            # code=falcon.HTTP_400
                                    else:
                                        jsoninput["iacstatus"] = "Failed"
                                        jsoninput["iacerrordetails"] = "There is no alarms"
                                        # code=falcon.HTTP_400
                                else:
                                    jsoninput["iacstatus"] = "Failed"
                                    jsoninput["iacerrordetails"] = "Alarms must contain a list/array of alarms"
                                    # code = falcon.HTTP_400
                            if len(insertedAlarmsID) == 0:
                                raise InputJSONError("Alarms not inserted, Please check the iacstatus in alarms")
                            elif len(inscopeiactokens) > 0:
                                predictjson = AlarmHandler().generate_alarmjson(inscopeiactokens)
                except InputJSONError as e:
                    jsoninput["iacstatus"] = "Failed"
                    jsoninput["iacerrordetails"] = str(e)
                    # RaiseError()
                    # RaiseError(500, "Error")
                    # code = falcon.HTTP_400
                except BaseException as e:
                    traceback.print_exc()
                    jsoninput["iacstatus"] = "Failed"
                    jsoninput["iacerrordetails"] = str(e)
                    # code=falcon.HTTP_500
            else:
                jsoninput = {"iacstatus": "Failed", "iacerrordetails": "invalid json"}
                # code=falcon.HTTP_400
        except JSONDecodeError as e:
            jsoninput = {"iacstatus": "Failed", "iacerrordetails": "invalid json"}
            # code = falcon.HTTP_400
        except BaseException as e:
            jsoninput = {"iacstatus": "Failed", "iacerrordetails": str(e)}
            # code=falcon.HTTP_500

        return {"rpa": jsoninput, "pre": predictjson}

    @staticmethod
    def combine_jsonerrors( keyerrors, patternerrors, typeerrors, othererrors):
        errormessage = []

        if keyerrors:
            errormessage.append(",".join(keyerrors) + " are missing")
        if patternerrors:
            errormessage.append(",".join(patternerrors) + " are not matching with format/pattern")
        if typeerrors:
            errormessage.append(",".join(typeerrors) + " are not in correct type")
        if othererrors:
            errormessage.append(",".join(othererrors))
        return ",".join(errormessage)

    def validate_with_schema(self, schema, jsoninstance):
        validator = Draft4Validator(schema, format_checker=FormatChecker())
        patternerrors = []
        typeerrors = []
        keyerrors = []
        othererrors = []
        for error in validator.iter_errors(jsoninstance):
            if error.validator == "type":
                typeerrors.append(error.schema["title"])
            elif error.validator == "pattern" or error.validator == "format":
                patternerrors.append(error.schema["title"])
            elif error.validator == "required":
                keyerrors.append(error.message.split("'")[1])
            else:
                othererrors.append(error.message)
        return self.combine_jsonerrors(keyerrors, patternerrors, typeerrors, othererrors)

    def validate_list(self, schema, jsonlist):
        valid_list = []
        # failed_list = []
        for d in jsonlist:
            v = self.validate_with_schema(schema, d)
            d["iacerrordetails"] = v
            if v == "":
                d["iacstatus"] = "Success"

                # valid_list.append(d)
            else:
                d["iacstatus"] = "Failed"
            print("ddddd",d)
                # failed_list.append(d)
            valid_list.append(d)
        return valid_list #, failed_list

    @staticmethod
    def df_to_list(df):
        if not df.empty:
            df = df.where(pd.notnull(df), None)
            # df.replace(to_replace="-_-",value=None,inplace=True)
            return df.T.apply(lambda x: x.to_dict()).tolist()
        else:
            return []

    def validate_alarm(self, jsoninput):
        try:
            insdf = None
            vlist = {"Tickets": "ticketjson", "Alarms": "alarmjson"}
            jsonid = MmlHandler().insert_json(jsoninput=jsoninput)
            v = validate_json(jsoninput)
            if v == True:
                for i, j in vlist.items():
                    # failed_list = []
                    valid_list = []
                    v = self.validate_with_schema(all_alarm_schema[i], jsoninput)
                    if v == "":
                        valid_list = self.validate_list(all_alarm_schema[j], jsoninput[i])
                        print(valid_list)
                        if valid_list:
                            orgdf, insdf = self.manage_alarms(valid_list=valid_list, casetype=i, jsonid=jsonid)
                            valid_list = self.df_to_list(orgdf)
                            # valid_list.extend(failed_list)
                        jsoninput[i] = valid_list
            
        except BaseException as e:
            settings.logger.error(f"Error in BRH while validating alarm traceback:{traceback.format_exc()}")
        return jsoninput, insdf

    def validate_mandatorycols(self, alarmlist):
        try:
            valid_list = []
            # failed_list = []
            for alarm in alarmlist:
                if alarm["iacstatus"]=="Success":
                    iacalarmdetail = AlarmHandler().get_alarmkeycolumn(alarm)
                    if iacalarmdetail is None:
                        alarm["scope"] = "Out"
                        alarm["iacstatus"] = "Success"
                        alarm["iacerrordetails"] = ""
                        alarm["processed"] = True
                        # valid_list.append(alarm)
                    else:
                        alarm["scope"] = "In"
                        alarmschema = all_alarm_schema["alarmjson"]
                        if iacalarmdetail["mandatorycols"] is not None:
                            alarmschema["required"] = list(set(alarmschema["required"] + iacalarmdetail["mandatorycols"]))
                        v = self.validate_with_schema(alarmschema, alarm)
                        alarm["iacalarmid"] = iacalarmdetail["iacalarmid"]
                        alarm["alarmNumber"] = iacalarmdetail["alarmnumber"]
                        alarm["executionmode"] = iacalarmdetail["executionmode"]
                        alarm["nodegroup"] = iacalarmdetail["nodegroup"]
                        alarm["iacerrordetails"] = v
                        if v == "":
                            alarm["iacstatus"] = "Success"
                            alarm["processed"] = False
                            # valid_list.append(alarm)
                        else:
                            alarm["scope"]="Out"
                            alarm["iacstatus"] = "Failed"
                            alarm["processed"] = True
                            # failed_list.append(alarm)
                else:
                    alarm["scope"] = "Out"
                    # alarm["iacstatus"] = "Success"
                    # alarm["iacerrordetails"] = ""
                    alarm["processed"] = True
                valid_list.append(alarm)

            return valid_list
        except BaseException as e:
            settings.logger.error(f"Error in BRH, traceback:{traceback.format_exc()}")

    def filter_tickets(self, df):
        try:
            print("All Tickets received before group....")
            print(df)
            print("All Tickets received after group....")
            if df.shape[0] > 1:
                df1 = df.groupby(["TicketID", "TTSeverity", "Country", "Customer", "Title", "CreateTime", "Acknowledge", "iacstatus", "iacerrordetails"], as_index=False).agg({'Alarms': make_list})
                df1['Alarms'] = df1['Alarms'].apply(lambda x: join_list(list(x)))
                print(df1)
                return df1
            print(df)
            return df
        except BaseException as e:
            settings.logger.error(f"Error in BRH, not able to group traceback: {traceback.format_exc()}")

    @staticmethod
    def extend_list(self, a, b):
        if a is None:
            if b is None:
                return []
            else:
                return b
        elif b is None:
            return a
        else:
            return a.extend(b)

    def manage_alarms(self, valid_list=None, casetype=None, jsonid=None):
        try:
            print(valid_list)
            df_alarms = pd.DataFrame()
            brh_rules = {"BCCH Missing Fault": ["bcfID", "ParentId"], "Cell Logical Channel Availability Supervision": ["nodeName", "ParentId"], "UtranCell_ServiceUnavailable": ["nodeName", "ParentId"], "UtranCell_NbapReconfigurationFailure": ["nodeName", "ParentId"], "UtranCell_NbapMessageFailure": ["nodeName", "ParentId"]}
            if casetype == "Tickets":
                df = pd.DataFrame(valid_list, columns=["TicketID", "TTSeverity", "Country", "Customer", "CreateTime", "Title", "Alarms", "Acknowledge", "iacstatus", "iacerrordetails", "status"])
                df.fillna('-_-', inplace=True)
                df = self.filter_tickets(df)
                for ticketindex, row in df.iterrows():
                    try:
                        row = TicketHandler().insert_ticket(row)
                        df.loc[ticketindex:, "iacstatus"] = row["iacstatus"]
                        df.loc[ticketindex:, "iacerrordetails"] = row["iacerrordetails"]

                        if df.loc[ticketindex,"iacstatus"] == "Success" or df.loc[ticketindex,"iacerrordetails"] == "Duplicate ticket":
                            v = self.validate_list(all_alarm_schema["alarmjson"], row["Alarms"])
                            v = self.validate_mandatorycols(v)
                            print("Validated alarms:",v)
                            df2 = pd.DataFrame(v, columns=["additionalInfo", "alarmNumber", "alarmText", "bcfID", "btsID", "countryName", "customer", "loginType", "eventTime", "fluctuationStatus", "nodeName", "nodeId", "nodeType", "ParentId", "robotUID", "trxID", "vendorType", "NodeInDB", "scope", "status", "iacalarmid", "iacstatus", "iacerrordetails", "iactoken", "parentalarm", "executionmode", "nodegroup","processed"])
                            df2["parentalarm"] = np.nan
                            df2["TicketID"] = row["TicketID"]
                            df2["eventTime"] = pd.to_datetime(df2['eventTime'])
                            df2["iactoken"] = df2["robotUID"]
                            df2["secs"] = 0
                            df2["sendtops"] = False
                            df2["tsecs"] = np.nan
                            df2.loc[df2['iactoken'].isna(), 'iactoken'] = df2.loc[df2['iactoken'].isna(), 'iactoken'].apply(lambda x: str(uuid.uuid4()))
                            if not df_alarms.empty:
                                df_alarms = df_alarms.append(df2, ignore_index=True)
                            else:
                                df_alarms = df2
                    except:
                        settings.logger.error(f"Error in BRH, traceback:{traceback.format_exc()}")
                        traceback.print_exc()
                print("df_alarms: ",df_alarms["eventTime"])
                if not df_alarms.empty:
                    df_alarms.drop_duplicates(inplace=True)
                    # ------------------------NodeInDB = False-----------------------------------------------------------------------------------

                    df_alarms.loc[(df_alarms["NodeInDB"] == False),["processed","scope"]]=True,"Out"

                    # ------------------------Size alteration  -----------------------------------------------------------------------------------

                    df_alarms.sort_values(by=["eventTime"], inplace=True)
                    df_alarms.fillna('-_-',inplace=True)
                    df_alarms.loc[:, "jsonid"] = jsonid
                    df_alarms.loc[(df_alarms['alarmText'] == "Size alteration") & (df_alarms["nodeType"].isin(["1", "2", "BSS"])) & (df_alarms['iacstatus'] == "Success") & (df_alarms['processed'] == False), ['iacstatus', 'iacerrordetails', 'processed']] = "Failed", "Alarm dropped as appearing on RAN Nodes", True

                    # -------------------------BTS O&M Link Failure Fault----------------------------------------------------------------------------------
                    df3 = df_alarms.loc[(df_alarms["alarmText"] == "BTS O&M Link Failure Fault") & (df_alarms["processed"] == False) & (df_alarms["scope"] == "In")].copy()
                    if not df3.empty:
                        for alarmindex, arow in df3.iterrows():
                            lasteventtime = None
                            if df3.loc[alarmindex, "processed"] == False:
                                df4 = df_alarms.loc[((df_alarms["alarmText"] == "BCCH Missing Fault") | (df_alarms["alarmText"] == "BTS O&M Link Failure Fault")) & (df_alarms["bcfID"] == arow["bcfID"]) & (df_alarms["ParentId"] == arow["ParentId"]) & (df_alarms["processed"] == False), :].copy()
                                lasteventtime = AlarmHandler().get_lastalarm(arow)
                                lasteventtime = lasteventtime if lasteventtime is not None else arow['eventTime']
                                df4.loc[:, 'secs'] = (df4.loc[:, 'eventTime'] - lasteventtime) / np.timedelta64(1, 's')
                                df4.loc[:, 'tsecs'] = df4['secs'] // 60
                                df4.loc[:, 'tsecs'].fillna(0)
                                bb = df4.groupby('tsecs')
                                dfgcc = [group for name, group in bb]
                                for dfs in dfgcc:
                                    if not dfs.empty:
                                        dfs.loc[:, 'newindex'] = np.arange(len(dfs))
                                        dfs = dfs.reset_index().set_index('newindex', append=True)
                                        dfs.loc[0, "sendtops"] = True
                                        if dfs.shape[0] > 1:
                                            dfs.loc[(dfs.index.get_level_values(0) > 0) & (dfs["alarmText"] == "BTS O&M Link Failure Fault"), "status"] = 5
                                            dfs.loc[(dfs.index.get_level_values(0) > 0) & (dfs["alarmText"] == "BCCH Missing Fault"), "status"] = 6
                                            dfs.loc[1:, ['parentalarm']] = dfs.loc[0, 'iactoken'][0]
                                        dfs = dfs.reset_index().set_index('index')
                                        dfs.loc[:, "processed"] = True
                                        df_alarms.update(dfs)
                                        df3.update(dfs)
                    # -------------------------Multiple alarm----------------------------------------------------------------------------------

                    for key, val in brh_rules.items():
                        df3 = df_alarms.loc[(df_alarms["alarmText"] == key) & (df_alarms["processed"] == False) & (df_alarms["scope"] == "In")]
                        if not df3.empty:
                            aa = df3.groupby(val)
                            dfg = [aa.get_group(x) for x in aa.groups]
                            for df4 in dfg:
                                lasteventtime = None
                                if not df4.empty:
                                    df4.loc[:, 'n1'] = np.arange(len(df4))
                                    df4.reset_index().set_index('n1', append=True)
                                    lasteventtime = AlarmHandler().get_lastalarm(df4.iloc[0])
                                    lasteventtime = lasteventtime if lasteventtime is not None else df4.iloc[0]['eventTime']
                                    df4.loc[:, 'secs'] = (df4.loc[:, 'eventTime'] - lasteventtime) / np.timedelta64(1, 's')
                                    df4.loc[:, 'tsecs'] = df4['secs'] // 60
                                    df4.loc[:, 'tsecs'].fillna(0)
                                    bb = df4.groupby('tsecs')
                                    dfgcc = [group for name, group in bb]
                                    for dfs in dfgcc:
                                        if not dfs.empty:
                                            dfs.loc[:, 'newindex'] = np.arange(len(dfs))
                                            dfs = dfs.reset_index().set_index('newindex', append=True)
                                            dfs.loc[0, "sendtops"] = True
                                            if dfs.shape[0] > 1:
                                                # dfs.loc[(dfs.index.get_level_values(0) > 0) & (dfs["alarmText"] == "BTS O&M Link Failure Fault"), "status"] = 5
                                                dfs.loc[1:, ['parentalarm']] = dfs.loc[0, 'iactoken'][0]
                                                dfs.loc[1:, ['status']] = 5
                                            dfs = dfs.reset_index().set_index('index')
                                            dfs.loc[:, "processed"] = True
                                            df_alarms.update(dfs)

                    # -------------------------After BRH alarm----------------------------------------------------------------------------------
                    # df_alarms.loc[(df_alarms['sendtops']==True) & (df_alarms["scope"]=="In"),'status']=1
                    df_alarms.replace({'-_-': None}, inplace=True)
                    df.replace({'-_-': None}, inplace=True)
                    df_alarms_copy = df_alarms.copy()
                    df_alarms = df_alarms.where(pd.notnull(df_alarms), None)
                    df_alarms["final"] = np.where((df_alarms['scope'] == "In") & (df_alarms["processed"] == df_alarms["sendtops"]), True, False)
                    print("after df_alarms:",df_alarms["eventTime"])
                    df_alarms.loc[(df_alarms["final"] == True), "status"] = 1
                    df_alarms.loc[:, "eventTime"] = df_alarms.loc[:, 'eventTime'].dt.strftime('%Y-%m-%d %H:%M:%S')
                    df_alarms.drop(["processed", "sendtops", "secs", "tsecs"], axis=1, inplace=True)
                    for ticketindex, row in df.iterrows():
                        df5 = df_alarms_copy.groupby(["TicketID"])
                        print("df5",df5)
                        dfg_alarms = [group for name, group in df5]
                        for dfg2 in dfg_alarms:
                            print("dfg2",dfg2)
                            dfg2 = dfg2.copy()
                            if not dfg2.empty:
                                if (dfg2["scope"]=="In").sum() > 0:
                                    self.mmlhandler.update_ticketstatus(ticketid=row["TicketID"],status="Processing")
                                dfg2.drop(["TicketID", "scope", "status", "iacalarmid", "parentalarm", "jsonid"], axis=1, inplace=True)
                                row["Alarms"] = self.df_to_list(dfg2)

                    print("final df: ",df_alarms[["iactoken", "alarmText", "eventTime", "scope", "status", "iacalarmid", "final", "iactoken"]])
                    return df, df_alarms
                else:
                    return df, df_alarms
            else:
                pass
        except BaseException as e:
            traceback.print_exc()
            settings.logger.error(f"Error in BRH, traceback:{traceback.format_exc()}")

    def validate_ps_json(self, jsoninput):
        pass

    def validate_rpa_json(self, jsoninput):
        pass

    def validate_gui_json(self, jsoninput):
        pass
