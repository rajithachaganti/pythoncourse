from Modules.Imports import *
import traceback


class HandleCORS(object):
    def process_request(self, req, resp):
        resp.set_header('Access-Control-Allow-Origin', '*')
        resp.set_header('Access-Control-Allow-Methods', '*')
        resp.set_header('Access-Control-Allow-Headers', '*')
        resp.set_header('Access-Control-Allow-Headers', 'token, Content-Type')
        # resp.set_header('Access-Control-Max-Age', 1728000)  # 20 days
        # if req.method == 'OPTIONS':
        #    raise HTTPStatus(falcon.HTTP_200, body='\n')


class AuthenticationData(object):
    def on_post(self, req, resp):
        route_path = str(req.path)
        if isRoute(route_path, CREATE_USER):
            try:
                data = json.loads(req.context["data"].decode('utf-8'))
                # cprint(data)
                uname = data['uname']
                password = data['pass']
                modifier = data['modifier']
                query = "insert into users (username,password,enabled,updatedtime,createdtime,modifier) values(%s,%s,%s,%s,%s,%s);"
                query_data = (uname, password, '1', 'now()', 'now()', modifier)
                connectUpdations(query, query_data, resp)
            except Exception as e:
                resp.body = response_wrapper(500, str(e))  # json.dumps({'error':str(e)})
                resp.status = falcon.HTTP_500
                return resp
        elif isRoute(route_path, CREATE_AUTH):
            try:
                data = json.loads(req.context["data"].decode('utf-8'))
                # cprint(data)
                uname = data['uname']
                auth = data['auth']
                query = "insert into authorities (username,authorities) values(%s,%s);"
                query_data = (uname, auth)
                connectUpdations(query, query_data, resp)
            except Exception as e:
                resp.body = response_wrapper(500, str(e))  # json.dumps({'error':str(e)})
                resp.status = falcon.HTTP_500
                return resp
        elif checkKey(SKIP_TOKEN, route_path):
            try:
                data = json.loads(req.context["data"].decode('utf-8'))
                # cprint(data)
                uname = data['uname']
                password = data['pass']
                if user_exists(uname, password):
                    # token = random_with_N_digits(16)
                    # token = str(uuid.uuid4().get_hex().upper()[0:16]) #For Python3 working
                    token = str(uuid.uuid4().hex.upper()[0:16])  # For Python2 working
                    query = "insert into token (username,token,updatedtime,enabled) values(%s,%s,%s,%s);"
                    query_data = (uname, token, 'now()', '1')
                    rows = connectUpdationsNormal(query, query_data)

                    query = "select authorities from authorities where username='" + uname + "'"
                    roles = connectNativeArray(query)

                    json_data = {'data': {"token": token, "uname": uname, "roles": roles}, 'msg': "Token Created", 'status': 200, 'error': ''}
                    resp.body = json.dumps(json_data)
                    resp.status = falcon.HTTP_200
                else:
                    resp.body = response_wrapper(401, [])
                    resp.status = falcon.HTTP_401
            except BaseException as e:
                resp.body = response_wrapper(500, str(e))  # json.dumps({'error':str(e)})
                resp.status = falcon.HTTP_500
                return resp


class AuthMiddleware(object):
    def process_request(self, req, resp):
        if req.method != 'OPTIONS':
            cprint("POST/GET Call")
            token = req.get_header('token')
            route_path = str(req.path)
            cprint('token = ', token)
            challenges = ['Token type="Fernet"']
            if checkKey(SKIP_TOKEN, route_path):
                return True
            elif isTokenEnabled == False:
                return True
            elif token is None:
                print("Auth token required. Please provide an auth token as part of the request.")
                RaiseError(401, "Auth token required. Please provide an auth token as part of the request.")
            elif not self._token_is_valid(token):
                # cprint("Token Invalid Raise Error")
                print("Auth token required. The provided auth token is not valid. Please request a new token and try again.")
                RaiseError(401, "Auth token required. The provided auth token is not valid. Please request a new token and try again.")
        else:
            cprint("Options Call")

    def _token_is_valid(self, token):
        cprint("_token_is_valid")
        if token_exists(token):  # Suuuuuure it's valid...
            # cprint("_token_is_valid is Valid")
            query = "update token set updatedtime=%s where token=%s;"
            query_data = ('now()', token)
            connectUpdationsNoResp(query, query_data)
            return True
        else:
            cprint("_token_is_valid is InValid")
            return False


class Microservices(object):
    def on_get(self, req, resp, **kwargs):
        route_path = str(req.path)
        # cprint("Microservices GETTTT")
        # cprint(route_path)
        if checkKey(GET_JSON, route_path):
            # cprint(GET_JSON[route_path])
            query = GET_JSON[route_path]
            query_data = ""
            connectFetchJSON(query, query_data, resp)
        else:
            resp.body = response_wrapper(404, [])  # json.dumps({'error':str(e)})
            resp.status = falcon.HTTP_404

    def on_post(self, req, resp, **kwargs):
        route_path = str(req.path)
        # cprint("Microservices POSTTT")
        if checkKey(POST_JSON, route_path):
            try:
                print("Inside onpost")
                data = json.loads(req.context['data'].decode('utf-8'))
                data['now'] = "now()"
                testJson = POST_JSON[route_path]
                query = testJson[0]
                tt = testJson[1]
                list = []
                for x in tt:
                    list.append(data[x])
                query_data = tuple(list)
                # cprint(query_data)
                connectFetchJSON(query, query_data, resp)
            except BaseException as e:
                traceback.print_exc()
                resp.body = response_wrapper(500, str(e))  # json.dumps({'error':str(e)})
                resp.status = falcon.HTTP_500
        else:
            resp.body = response_wrapper(404, [])  # json.dumps({'error':str(e)})
            resp.status = falcon.HTTP_404


class RESTIntreceptor(object):
    def process_request(self, req, resp):
        # cprint("PROCESS REQUESTSSSSSS")
        # if req.content_length in (None, 0):
        #     # Nothing to do
        #     return
        if req.method == 'OPTIONS':
            return
        if req.method == "GET":
            req.context["req_id"] = LoggerInfo(req, "")
            return
        try:
            route_path = str(req.path)
            # if checkKey(JSON_VALLIDATION,route_path):
            body = req.stream.read()
            print(f"Response : {body}")
            if not body:
                body = b'{}'
                req.context["req_id"] = LoggerInfo(req, body)
                error = "Empty request body. A valid JSON is required."
                print("----------------Body", body)
                RaiseError(500, error)
            req.context["req_id"] = LoggerInfo(req, body)
            # req.context['request'] = json.loads(body.decode('utf-8'))
            req.context['data'] = body

            # data = req.context['request']
            data = json.loads(body.decode('utf-8'))
            isKeyNull = True
            isKeyNotFound = True
            errorKey = []
            arrValidate = []
            if checkKey(JSON_VALLIDATION, route_path):
                arrValidate = JSON_VALLIDATION[route_path]
            for key in arrValidate:
                if checkKey(data, key):
                    if data[key] == '':
                        isKeyNull = False
                        errorKey.append(key)
                else:
                    errorKey.append(key)
                    isKeyNotFound = False
            if (isKeyNotFound == False):
                error = {"msg": "Required JSON Key is Not Found", "keys": errorKey}
                RaiseError(500, error)
            elif (isKeyNull == False):
                error = {"msg": "Required JSON Key is Null", "keys": errorKey}
                RaiseError(500, error)
        except (ValueError, UnicodeDecodeError):
            traceback.print_exc()
            RaiseError(500, "Malformed JSON, JSON was incorrect or not encoded as UTF-8.")
        except BaseException as e:

            traceback.print_exc()

    #    def process_resource(self, req, resp, resource, params):
    #         pass

    def process_response(self, req, resp, resource, arg=""):
        cprint("PROCESS RESPONSSSSSSS")
        cprint("SELF = " + str(self))
        cprint("req = " + str(req))
        cprint("resp = " + str(resp))
        cprint("resource = " + str(resource))
        cprint("arg = " + str(arg))

        if arg == "":
            raise

        if 'result' not in req.context:
            cprint(req.method)
            if req.method == "OPTIONS":
                return
            route_path = str(req.path)
            if checkKey(SKIP_TOKEN, route_path) == False:
                pass
                # cprint("Token Update Process")
                # TokenExpiredAndUpdate(req,resp)
            if req.method == "GET":
                if hasattr(self, 'body'):
                    LoggerInfoUpdate(req, self)
                    raise
                else:
                    LoggerInfoUpdate(req, resp)
                return
            route_path = str(req.path)
            # if checkKey(JSON_VALLIDATION,route_path):
            if hasattr(self, 'body'):
                # if self.body is None:
                LoggerInfoUpdate(req, self)
                raise
            else:
                LoggerInfoUpdate(req, resp)
            return
        resp.body = json.dumps(req.context['result'])


def TokenExpiredAndUpdate(req, resp):
    token = req.get_header('token')
    query = "select username from token where token='" + token + "'"
    uname = connectNativeArray(query)
    # cprint(token)
    # cprint(uname)
    tokens = str(uuid.uuid4().hex.upper()[0:16])  # For Python2 working
    # cprint(tokens)
    query = "delete from token where token='{}'".format(token)
    # cprint(query)
    insertWithoutQueryData(query)

    query = "insert into token values('{}','{}','{}','{}')".format(uname[0], tokens, 'now()', '1')
    insertWithoutQueryData(query)

    resp.set_header("token", tokens)
