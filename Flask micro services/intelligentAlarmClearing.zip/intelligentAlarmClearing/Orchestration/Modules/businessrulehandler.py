import traceback
from .Commons import *
from .Utilities import *
from .alljsonschema import *
from .alarmhandler import AlarmHandler
from .tickethandler import TicketHandler
import pandas as pd
class BusinessRuleHandler:
    def __init__(self):
        self.coorcols=['bcfID', 'customer', 'vendorType', 'nodeName', 'nodeType', 'alarmNumber', 'alarmText', 'additionalInfo']
        self.connection=getConnection()
    def __del__(self):
        self.connection.close()

    # def equal_dicts(d1, d2, ignore_keys):
    #     d1_filtered = dict((k, v) for k, v in d1.iteritems() if k not in ignore_keys)
    #     d2_filtered = dict((k, v) for k, v in d2.iteritems() if k not in ignore_keys)
    #     return d1_filtered == d2_filtered

    def equal_dicts(self,d1, d2, main_keys):
        print('here')
        mainkeys = set(main_keys)
        for k1, v1 in d1.items():
            print(k1)
            print(d2[k1] ,v1)
            if k1 in mainkeys and d2[k1] != v1:
                print('false')
                return False
        print('True')
        return True


    def remove_duplicate_json(self,jsoninput):
        try:
            uniquealarms=[dict(y) for y in set(tuple(x.items()) for x in jsoninput)]
            cooralarm=[]
            if len(cooralarm)==0:
                print('added')
                cooralarm.append(uniquealarms[0])
            print(len(uniquealarms))
            for a in uniquealarms:
                for b in range(0,len(cooralarm)):
                    if self.equal_dicts(cooralarm[b],a,self.coorcols) == False:
                        cooralarm.append(a)
                    else:
                        break
        except BaseException as e:
            jsoninput={"iacstatus":"Failed","iacerrordetails":str(e)}
        return {"rpa":cooralarm,"pre":""}

    # cur.execute("insert into alarminfo(iactoken,ticketid,additionalinfo,nodeid,nodename,additionalfields,customer,nodevendor,status,nodetype,alarmnumber,alarmname,eventtime,scope,iacalarmid,iac_time) "
    #             "values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,now()) returning iactoken",
    #             (alarm["robotUID"], ticket, alarm["additionalInfo"], alarm["bcfID"], alarm["nodeName"],
    #              json.dumps(split_dict(alarm, ['robotUID', 'bcfID', 'customer', 'vendorType', 'nodeName', 'nodeType', 'alarmNumber', 'alarmText', 'eventTime', 'additionalInfo'])),
    #              alarm["customer"], alarm["vendorType"], status, alarm["nodeType"], alarm["alarmNumber"], alarm["alarmText"], alarm["eventTime"], "In", alarmkeyid["iacalarmid"]))
    # def compare_with_db(self,df_grp):
        # with self.connection as conn:
            # with conn.cursor() as cur:
                # cur.execute("select iactoken,eventtime,ticketid,iacalarmid from alarminfo where nodeid='"bcfid"' and customer='"customer"' and nodevendor='"vendorType"' and nodename='"nodename"' and nodetype='"nodeType"' and alarmnumber='"alarmNumber
                # "' and alarmname='"alarmtext"' and additionalinfo='"additionalInfo"' order by eventtime desc limit 1")


    def coorelate_alarm(self,df_alarms,casetype):
        try:

            alarmdata=df_alarms["Alarms"]
            df = pd.DataFrame(alarmdata).drop_duplicates()
            df['eventTime'] = pd.to_datetime(df['eventTime'])
            # df.sort_values(['eventTime'])
            aa = df.groupby(['bcfID', 'customer', 'vendorType', 'nodeName', 'nodeType', 'alarmNumber', 'alarmText', 'additionalInfo'])
            dfg = [aa.get_group(x) for x in aa.groups]
            # print(dfg)
            for grp in dfg:
                print('here ---------------------------------------------------------')
                print(grp)
                bb=grp.groupby([pd.Grouper(key='eventTime',freq='60s')])
                print(bb)
                dfgcc = [group for name,group in bb]
                for dfs in dfgcc:
                    if not dfs.empty:
                        print('-------------------------------')
                        print(dfs)
                        print('-------------------------------')
                    # print(dfs)
                print('end here--------------------------------------------------------------')


        except:
            traceback.print_exc()
    # def compare_with_db(self,df):