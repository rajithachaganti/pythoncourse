import falcon

import Constants
from Modules.EmailHandler import *
from datacccess.AlarmInfoDataAccess import *
from .alarmhandler import AlarmHandler


class MmlHandler:

    def __init__(self):
        self.mandatorymmltoosfields = ['iactoken', 'Command', 'Resolution Code', 'Resolution Summary']
        self.statusmap = {'0': '2', '8': '4'}
        self.connection = getConnection()

    def __del__(self):
        self.connection.close()

    def insert_json(self, jsoninput=None):
        x = str(json.dumps(jsoninput))
        print("--json before replace ---",x)
        print("--json after replace  ---",x.replace("'", " "))
         try:
            with self.connection as conn:
                with conn.cursor() as cur:
                    cur.execute("insert into inputjsondetails(inputjson) values ('{}')".format(str(json.dumps(jsoninput)).replace("'", " "))
                    return cur.fetchone()[0]
        except BaseException as e:
            print("Error ---------  " + str(e))
            traceback.print_exc()
            settings.logger.error(f"Error while inserting json {jsoninput} traceback: {traceback.format_exc()}")
            return None

    def get_sequencenum(self, iactoken):
        try:
            with self.connection as conn:
                with conn.cursor() as cur:
                    cur.execute("select count(iactoken) + 1 as seqnum from alarmcycle where iactoken='{}'".format(iactoken))
                    return cur.fetchone()[0]
        except BaseException as e:
            # print("Error ---------  " + str(e))
            # traceback.print_exc()
            settings.logger.error(f"Error while getting sequencenum for iactoken {iactoken} traceback: {traceback.format_exc()}")
            return None

    def get_task(self, task):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("select taskid from tasktypes where lower(taskname)=lower('{}')".format(task))
                    return cur.fetchone()[0]
        except BaseException as e:
            # print("Error ---------  " + str(e))
            # traceback.print_exc()
            settings.logger.error(f"Error while getting task {task} traceback: {traceback.format_exc()}")
            return None

    def get_statuscode(self, status=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("select status_id from statuscodes where lower(status)=lower('{}')".format(status))
                    return cur.fetchone()[0]
        except BaseException as e:
            # print("Error ---------  " + str(e))
            settings.logger.error(f"Error while getting statuscode {status} traceback: {traceback.format_exc()}")
            # traceback.print_exc()
            return None

    def get_resolution_status(self, status=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("select resolutionstatus from resolutioncodes where resolutioncode={}".format(status))
                    return cur.fetchone()[0]

        except BaseException as e:
            # print("Error ---------  " + str(e))
            settings.logger.error(f"Error while getting statuscode {status} traceback: {traceback.format_exc()}")
            # traceback.print_exc()
            return None

    def execute_query(self, query=None, param=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    print(query, param)
                    if param is None:
                        cur.execute(query)
                    else:
                        cur.execute(query, param)
                    return cur.fetchone()[0]
        except BaseException as e:
            # print("Error ---------  " + str(e))
            # traceback.print_exc()
            settings.logger.error(f"Error while executing query {query} traceback: {traceback.format_exc()}")
            return None

    def close_ticket_response(self, jsoninput=None):
        try:
            clsticket = pd.Series(jsoninput, index=["ticketID", "resolutioncode", "status", "exceptiondetail"])
            clsticket.replace({np.nan: None}, inplace=True)
            jsonid = self.insert_json(jsoninput)
            if clsticket.status == "1":
                self.update_ticketmessage(message="Closed ticket in ITSM", ticketid=clsticket.ticketID)
                self.update_ticketstatus(ticketid=clsticket.ticketID, status="Closed")
            else:
                settings.logger.error(f"Error response from RPA for close ticket, ticketid:{clsticket.ticketID}, jsonid:{jsonid}, exceptiondetail: {clsticket.exceptiondetail}")
                self.update_ticketmessage(message='Close ticket failed :' + str(clsticket.exceptiondetail), ticketid=clsticket.ticketID)
                self.update_ticketstatus(status="Manual-Fail", ticketid=clsticket.ticketID)
        except BaseException as e:
            settings.logger.error(f"Error while processing close ticket response, jsonid:{self.insert_json({'errordetail':traceback.format_exc()})} traceback:{traceback.format_exc()}")

    def attach_log_ticket_response(self, jsoninput=None):
        try:
            ticket = pd.Series(jsoninput, index=["ticketID", "resolutioncode", "status", "exceptiondetail"])
            ticket.replace({np.nan: None}, inplace=True)
            jsonid = self.insert_json(jsoninput)
            if ticket.status == "1":
                self.update_ticketmessage(message="Attach log complete", ticketid=ticket.ticketID)
            else:
                settings.logger.error(f"Error response from RPA for close ticket, ticketid:{ticket.ticketID}, jsonid:{jsonid}, exceptiondetail: {ticket.exceptiondetail}")
                self.update_ticketmessage(message='Attach log failed :' + str(ticket.exceptiondetail), ticketid=ticket.ticketID)
        #         self.update_ticketstatus(status="Manual-Fail", ticketid=clsticket.ticketID)
        except BaseException as e:
            settings.logger.error(f"Error while processing close ticket response, jsonid:{self.insert_json({'errordetail':traceback.format_exc()})} traceback:{traceback.format_exc()}")

    def process_ticketacknowledge(self, jsoninput=None):
        try:
            ackticket = pd.Series(jsoninput, index=["ticketID", "acknowledgedTime", "resolutioncode", "status", "exceptiondetail"])
            ackticket.replace({np.nan: None}, inplace=True)
            ackticket.replace({'True': True, 'False': False}, inplace=True)
            jsonid = self.insert_json(jsoninput)
            if ackticket.status == "1":
                self.update_ticketmessage(message="Acknowledged ticket", ticketid=ackticket.ticketID)
                self.execute_query("update ticketdetails set acktime=%s ,updatedtime=now(), acknowledge='t' where ticketid=%s returning ticketid", (ackticket.acknowledgedTime, ackticket.ticketID))
                # self.update_ticketstatus(ticketid=clsticket.ticketID, status="Closed")
            else:
                settings.logger.error(f"Error response from RPA for acknowledge ticket, ticketid:{ackticket.ticketID}, jsonid:{jsonid}, exceptiondetail: {ackticket.exceptiondetail}")
                self.update_ticketmessage(message=ackticket.exceptiondetail, ticketid=ackticket.ticketID)
                # self.update_ticketstatus(status="Manual-Fail", ticketid=ackticket.ticketID)
        except BaseException as e:
            settings.logger.error(f"Error while processing close ticket response, jsonid:{self.insert_json({'errordetail':traceback.format_exc()})} traceback:{traceback.format_exc()}")

    def close_ticket(self, jsoninput=None, username=None):
        try:
            clsticket = pd.Series(jsoninput, index=["ticketid", "resolutionstatus", "resolutionsummary"])
            clsticket.replace({np.nan: None}, inplace=True)
            settings.logger.debug(f"Sending Close ticket request to RPA...ticketid: {clsticket['ticketid']}, resolutioncode: {clsticket['resolutionstatus']}, resolutionsummary: {clsticket['resolutionsummary']}")
            jsoninput = {"ticketID": clsticket["ticketid"], "resolutioncode": clsticket['resolutionstatus'], "resolutionsummary": clsticket['resolutionsummary']}
            jsonid = self.insert_json(jsoninput)
            w = checkForValues(clsticket, ["ticketid", "resolutionstatus"], None)
            if w is None:
                r = requests.post(settings.RPA_CLOSETICKET_URL, 
                                  headers={"Authorization": settings.RPA_TOKEN, 
                                  "Content-type": "application/json"}, 
                                  json=jsoninput, 
                                  proxies=settings.NO_PROXY
                                  )
                if r.status_code == 401:
                    s = settings.refresh_rpa_token()
                    if s:
                        r = requests.post(settings.RPA_CLOSETICKET_URL, headers={"Authorization": settings.RPA_TOKEN, "Content-type": "application/json"}, json=jsoninput, proxies=settings.NO_PROXY)
                        if r.status_code == 200:
                            settings.logger.debug(f"Sending to RPA for ticket close success ticketid:{clsticket['ticketid']}")
                            self.update_ticketstatus(ticketid=clsticket["ticketid"], status="Processing")
                            self.update_ticketmessage(message="Closing Ticket.Waiting for RPA response", ticketid=clsticket["ticketid"])
                        elif r.status_code == 401:
                            settings.logger.error(f"Error while sending close ticket request to RPA, jsonid:{jsonid}, token:{settings.RPA_TOKEN}, response: {r.content}")
                            # self.update_ticketstatus(ticketid=clsticket["ticketid"], status="Manual-Fail")
                            self.update_ticketmessage(message="Failed to send to RPA, token failed", ticketid=clsticket["ticketid"])
                        else:
                            settings.logger.error(f"Error while sending close ticket request to RPA, jsonid:{jsonid}, token:{settings.RPA_TOKEN}, response: {r.content}")
                            # self.update_ticketstatus(ticketid=clsticket["ticketid"], status="Manual-Fail")
                            self.update_ticketmessage(message="Failed to send to RPA", ticketid=clsticket["ticketid"])
                elif r.status_code == 200:
                    self.update_ticketstatus(ticketid=clsticket["ticketid"], status="Processing")
                    self.update_ticketmessage(message="Closing Ticket.Waiting for RPA response", ticketid=clsticket["ticketid"])
                else:
                    settings.logger.error(f"Error while sending close ticket request to RPA, jsonid:{jsonid}, token:{settings.RPA_TOKEN}, response: {r.content}")
                    # self.update_ticketstatus(ticketid=clsticket["ticketid"], status="Manual-Fail")
                    self.update_ticketmessage(message="Failed to send to RPA", ticketid=clsticket["ticketid"])
            else:
                settings.logger.error(f"Error while sending close ticket request to RPA, jsonid:{jsonid}")
                # self.update_ticketstatus(ticketid=clsticket["ticketid"], status="Manual-Fail")
                self.update_ticketmessage(message=f"Failed to send to RPA,{w}", ticketid=clsticket["ticketid"])
        except BaseException as e:
            self.update_ticketmessage(message="Closing ticket failed due to internal error", ticketid=clsticket["ticketid"])
            jsonid = self.insert_json(jsoninput={"errordetails": traceback.format_exc()})
            settings.logger.error(f"Error while sending close ticket ({clsticket['ticketid']}) request to RPA, jsonid:{jsonid}, traceback: {traceback.format_exc()}")
        settings.logger.debug("Completed Close ticket request")

    def attach_log_ticket(self, jsoninput=None):
        try:
            ticket = pd.Series(jsoninput, index=["ticketid"])
            ticket.replace({np.nan: None}, inplace=True)
            settings.logger.debug(f"Sending Attach Log ticket request to RPA...ticketid: {ticket['ticketid']}")
            jsoninput = {"ticketID": ticket["ticketid"], "resolutioncode": "12"}
            jsonid = self.insert_json(jsoninput)
            w = checkForValues(ticket, ["ticketid"], None)
            if w is None:
                r = requests.post(settings.RPA_ATTACH_LOG_URL, headers={"Authorization": settings.RPA_TOKEN, "Content-type": "application/json"}, json=jsoninput, proxies=settings.NO_PROXY)
                if r.status_code == 401:
                    s = settings.refresh_rpa_token()
                    if s:
                        r = requests.post(settings.RPA_ATTACH_LOG_URL, headers={"Authorization": settings.RPA_TOKEN, "Content-type": "application/json"}, json=jsoninput, proxies=settings.NO_PROXY)
                        if r.status_code == 200:
                            settings.logger.debug(f"Sending to RPA for ticket attach log success ticketid:{ticket['ticketid']}")
                            # self.update_ticketstatus(ticketid=ticket["ticketid"],status="Processing")
                            self.update_ticketmessage(message="Attach log.Waiting for RPA response", ticketid=ticket["ticketid"])
                        elif r.status_code == 401:
                            settings.logger.error(f"Error while sending attach log ticket request to RPA, jsonid:{jsonid}, token:{settings.RPA_TOKEN}, response: {r.content}")
                            # self.update_ticketstatus(ticketid=clsticket["ticketid"], status="Manual-Fail")
                            self.update_ticketmessage(message="Failed to send to RPA- Attach log, token failed", ticketid=ticket["ticketid"])
                        else:
                            settings.logger.error(f"Error while sending attach log ticket request to RPA, jsonid:{jsonid}, token:{settings.RPA_TOKEN}, response: {r.content}")
                            # self.update_ticketstatus(ticketid=clsticket["ticketid"], status="Manual-Fail")
                            self.update_ticketmessage(message="Failed to send to RPA-Attach log", ticketid=ticket["ticketid"])
                elif r.status_code == 200:
                    # self.update_ticketstatus(ticketid=ticket["ticketid"],status="Processing")
                    self.update_ticketmessage(message="Attach log.Waiting for RPA response", ticketid=ticket["ticketid"])
                else:
                    settings.logger.error(f"Error while sending attach log ticket request to RPA, jsonid:{jsonid}, token:{settings.RPA_TOKEN}, response: {r.content}")
                    # self.update_ticketstatus(ticketid=clsticket["ticketid"], status="Manual-Fail")
                    self.update_ticketmessage(message="Failed to send to RPA-Attach log", ticketid=ticket["ticketid"])
            else:
                settings.logger.error(f"Error while sending attach log ticket request to RPA, jsonid:{jsonid}")
                # self.update_ticketstatus(ticketid=clsticket["ticketid"], status="Manual-Fail")
                self.update_ticketmessage(message=f"Failed to send to RPA- Attach log,{w}", ticketid=ticket["ticketid"])
        except BaseException as e:
            self.update_ticketmessage(message="Attach log for ticket failed due to internal error", ticketid=ticket["ticketid"])
            jsonid = self.insert_json(jsoninput={"errordetails": traceback.format_exc()})
            settings.logger.error(f"Error while sending attach log ticket ({ticket['ticketid']}) request to RPA, jsonid:{jsonid}, traceback: {traceback.format_exc()}")
        settings.logger.debug("Completed Attach log ticket request")

    def update_message(self, message=None, cycleid=None):
        try:
            with self.connection as conn:
                with conn.cursor() as cur:
                    cur.execute("update alarmcycle set message='{}' where id={}".format(str(message), cycleid))
        except:
            jsonid = self.insert_json(jsoninput={"errordetails": traceback.format_exc()})
            settings.logger.error(f"Error while updating alarm message cycleid:{cycleid}, jsonid:{jsonid}  traceback: {traceback.format_exc()}")

    def update_ticketmessage(self, message=None, ticketid=None):
        try:
            with self.connection as conn:
                with conn.cursor() as cur:
                    cur.execute("update ticketdetails set message='{}' where ticketid='{}'".format(str(message), ticketid))
        except:
            jsonid = self.insert_json(jsoninput={"errordetails": traceback.format_exc()})
            settings.logger.error(f"Error while updating ticket message ticketid:{ticketid}, jsonid:{jsonid}  traceback: {traceback.format_exc()}")

    def insert_alarmcycle(self, iactoken=None, tasktype=None, parentid=None, resolutioncode=None, inputreceived=None, resolutionsummary=None, mmlcommand=None, mmloutput=None, commandname=None, message=None, username=None, rsname=None):
        try:
            with self.connection:
                # with self.connection.cursor() as cur:
                cur = self.connection.cursor()
                conn =getConnection()
                conn.set_isolation_level(p.extensions.ISOLATION_LEVEL_SERIALIZABLE)
                tranCur = conn.cursor()
                # tranCur.execute("update mylock set f1=True")
                tranCur.execute("update applock set lock=True where key=%s", [iactoken])
                cur.execute("insert into alarmcycle(iactoken,tasktype,tasktime,sequencenum,parentid,resolutioncode,"
                            "inputreceived,resolutionsummary,mmlcommand,commandname,message,mmloutput,username,rsname)"
                            " values(%s,%s,now(),(select coalesce(max(sequencenum),0) + 1 as seqnum "
                            "from alarmcycle where iactoken=%s)"
                            ",%s,%s,%s,%s,%s,%s,substring(%s from 1 for 128),%s,%s,%s) returning id",
                            (iactoken, self.get_task(tasktype), iactoken, parentid, resolutioncode,
                             inputreceived, resolutionsummary, mmlcommand, commandname, message, mmloutput, username, rsname))
                cycleid = cur.fetchone()[0]
                self.connection.commit()
                # tranCur.execute("delete from applock where key=%s",[iactoken])
                cur.close()
                tranCur.close()
                settings.logger.info(f"Inserted a row in alarmcycle iACToken: {iactoken} tasktype:{tasktype} resolutioncode:{resolutioncode}")
                return cycleid
        except BaseException as e:
            # print(f"Error while inserting alarmcycle iactoken={iactoken}")
            settings.logger.error(f"Error while inserting alarmcycle iactoken={iactoken} traceback: {traceback.format_exc()}")
            # traceback.print_exc()
            return None
        finally:
            if conn is not None:
                conn.rollback()
                conn.close()

    def insert_waitingcommands(self, iactoken=None, parentid=None, mmlcommand=None, commandname=None, executiontime=None, type=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("insert into waitingcommands(iactoken,mmlcommand,type,executiontime,status,ipaddress,commandname,parentid) values(%s,%s,%s,now() + interval '%s second',%s,%s,%s,%s) returning id",
                                (iactoken, mmlcommand, type, executiontime, self.get_statuscode("Processing"), settings.HOSTNAME, commandname, parentid))
                    settings.logger.info(f"Inserted a row in waitingcommands iACToken: {iactoken}")
                    return cur.fetchone()[0]
        except BaseException as e:
            # print(f"Error while inserting alarmcycle iactoken={iactoken}")
            settings.logger.error(f"Error while inserting alarmcycle iactoken={iactoken} traceback: {traceback.format_exc()}")
            # traceback.print_exc()
            return None

    def insert_alarm(self, iactoken=None, ticketid=None, additionalinfo=None, bcfid=None, nodename=None, nodeparent=None, additionalfields=None, customer=None, nodevendor=None, status=None, nodetype=None, alarmnumber=None, alarmname=None, eventtime=None, scope=None, iacalarmid=None, parentalarm=None, executionmode=None, nodegroup=None):
        try:
            with self.connection as conn:
                with conn.cursor() as cur:
                    cur.execute("insert into alarminfo(iactoken,ticketid,additionalinfo,nodeid,nodename,"
                                "additionalfields,customer,nodevendor,status,nodetype,alarmnumber,alarmname,eventtime,"
                                "scope,iacalarmid,iac_time,updatedtime,parentalarm,nodeparent,executionmode,nodegroup) "
                                "values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,now(),now(),%s,%s,%s,%s) "
                                "returning iactoken",
                                (iactoken, ticketid, additionalinfo, bcfid, nodename, additionalfields, customer,
                                 nodevendor, status, nodetype, alarmnumber, alarmname, eventtime, scope, iacalarmid,
                                 parentalarm, nodeparent, executionmode, nodegroup))
                    cur.execute("insert into applock values(%s,%s)", [iactoken, False])
            settings.logger.info(f"Inserted alarm {iactoken}")
            return True
        except BaseException as e:
            # print(f"Error while inserting alarm... iactoken={iactoken}")
            # traceback.print_exc()
            settings.logger.error(f"iACToken: {iactoken} traceback:{traceback.format_exc()}")
            return False

    def update_alarmstatus(self, iactoken=None, status=None, message=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    if message is None:
                        message = ''
                    cur.execute("update alarminfo set status= {},message='{}',updatedtime=now() where iactoken='{}'".format(self.get_statuscode(status=status), message, str(iactoken)))
                    settings.logger.info(f"Updated iactoken:{iactoken} status:{status} traceback: {traceback.format_exc()}")
                    return True
        except BaseException as e:
            self.insert_alarmcycle(iactoken=iactoken, tasktype="Error", message="Error while updating alarm status, " + str(e))
            # print("Error ---------  " + str(e))
            # traceback.print_exc()
            settings.logger.error(f"Error while updating alarm status for iactoken:{iactoken} status:{status} traceback: {traceback.format_exc()}")
            return False

    def change_executionmode(self, jsoninput=None, username=None):
        try:
            jsonid = self.insert_json(jsoninput=jsoninput)
            v = checkForKeys(jsoninput, ["iactoken", "mode"])
            w = checkForValues(jsoninput, ["iactoken", "mode"], v)
            if v is None and w is None:
                with self.connection:
                    with self.connection.cursor() as cur:
                        cur.execute("update alarminfo set executionmode=%s,updatedtime=now() where iactoken=%s",
                                    (jsoninput["mode"], jsoninput["iactoken"]))
                        self.insert_alarmcycle(iactoken=jsoninput["iactoken"], tasktype="Status Message",
                                               inputreceived=jsonid,
                                               message="Alarm execution mode changed to " + jsoninput["mode"],
                                               username=username)
                        settings.logger.info(f"Updated iactoken:{jsoninput['iactoken']} mode:{jsoninput['mode']}")
                        return {"iacstatus": "Success", "iacerrordetails": ""}, falcon.HTTP_200
            else:
                return {"iacstatus": "Failed", "iacerrordetails": w}, falcon.HTTP_400
        except BaseException as e:
            settings.logger.error(f"Error while updating alarm executionmode for iactoken:{jsoninput['iactoken']} mode:{jsoninput['mode']} jsonid:{jsonid}, traceback: {traceback.format_exc()}")
            return {"iacstatus": "Failed", "iacerrordetails": "Internal Server Error"}, falcon.HTTP_500

    def update_ticketstatus(self, ticketid=None, status=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("update ticketdetails set status= {},updatedtime=now() where ticketid='{}'".format(self.get_statuscode(status=status), str(ticketid)))
                    settings.logger.debug(f"Updated ticketid:{ticketid} status:{status}")
                    return True
        except BaseException as e:

            settings.logger.error(f"Error while updating ticket status for ticketid:{ticketid} status:{status} traceback: {traceback.format_exc()}")
            return False

    def send_alarm_to_ps(self, iactoken=None, tasktype=None):
        try:
            settings.logger.debug(f"Enter sending alarm to PS iactoken:{iactoken}")
            alarmjson = AlarmHandler().generate_alarmjson2(iactoken)
            print(alarmjson)
            jsonid = self.insert_json(alarmjson)
            cycleid = self.insert_alarmcycle(iactoken=iactoken, tasktype=tasktype, inputreceived=jsonid)
            r = requests.post(settings.PREDICT_URL, json=alarmjson, proxies=settings.NO_PROXY)
            if r.status_code == 200:
                self.update_message(message="Sending alarm to PS success", cycleid=cycleid)
                settings.logger.debug(f"Sending alarm to PS success iactoken:{iactoken} tasktype:{tasktype}")
                return "Success"
            else:
                settings.logger.error(f"Error while sending alarm to PS iactoken:{iactoken} tasktype:{tasktype} response:{r.content}")
                self.insert_alarmcycle(iactoken=iactoken, tasktype="Error", inputreceived=jsonid, message="Sending to PS failed")
                self.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")
                # print("..........Sending alarm to PS Failed: {}".format(r.content))

                return "Failed"
        except BaseException as e:
            settings.logger.error(f"Error while sending alarm to PS iactoken:{iactoken} json:{alarmjson} traceback: {traceback.format_exc()}")
            if iactoken is not None:
                self.insert_alarmcycle(iactoken=iactoken, tasktype="Error", inputreceived=self.insert_json(jsoninput={"errordetails": traceback.format_exc()}), message="Error while sending alarm to PS, " + str(e))
                self.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")
        settings.logger.debug(".....Exit: Sending alarm to PS completed")

    def process_km_response(self, jsoninput):
        try:
            jsonid = self.insert_json(jsoninput)
            settings.logger.debug(f"Processing KM Response: {jsoninput}")
            self.insert_alarmcycle(iactoken=jsoninput["iactoken"], tasktype="Knowledge Manager Response", inputreceived=jsonid, message=jsoninput["iacerrordetails"])
            return {"iacstatus": "Success", "iacerrordetails": ""}
        except BaseException as e:
            settings.logger.error(f"Error while processing KM Response {jsoninput} traceback: {traceback.format_exc()}")
            if jsoninput["iactoken"] is not None:
                self.insert_alarmcycle(iactoken=jsoninput["iactoken"], tasktype="Error", inputreceived=self.insert_json(jsoninput={"errordetails": traceback.format_exc()}), message="Exception while parsing JSON from KM, " + str(e))
                self.update_alarmstatus(iactoken=jsoninput["iactoken"], status="Manual-Fail")
            return {"iacstatus": "Failed", "iacerrordetails": "DB Error"}

    def check_previous_command(self, currentcmd=None, iactoken=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("select id,iactoken,mmlcommand,commandname from alarmcycle where iactoken='{}' and tasktype=5 order by tasktime desc limit 1".format(iactoken))
                    res = cur.fetchone()
                    if res is None:
                        return False
                    else:
                        if res[3] == currentcmd:
                            return True
                        else:
                            return False
        except BaseException as e:
            traceback.print_exc()
            settings.logger.error(f"Error while checking previous command, iactoken:{iactoken}, traceback: {traceback.format_exc()}")
            self.insert_alarmcycle(iactoken=iactoken, tasktype="Error", inputreceived=self.insert_json(jsoninput={"errordetails": traceback.format_exc()}), message="Error while checking previous command, " + str(e))
            self.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")
            return None

    def get_command_details(self, commandname=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("select criticalcommand,beforeexecute,reattempt from commanddictionary where commandname='{}'".format(commandname))
                    return cur.fetchone()
        except BaseException as e:
            # traceback.print_exc()
            settings.logger.error(f"Error while executing query, traceback: {traceback.format_exc()}")
            return None

    def insert_iac1_data_into_db(self, iac1_inp_data, iac1_resp_data, err_msg, err_data):
        try:
            print("inserting data")

            if (iac1_inp_data):
                jsonid = self.insert_json(jsoninput=iac1_inp_data)
                self.insert_alarmcycle(iactoken=iac1_inp_data["robotUID"], tasktype="Alarm sent to iAC 1.0", inputreceived=jsonid)
            if (err_msg):
                iac1_resp_data['iacStatus'] = 'Failed'
                iac1_resp_data['iacErorrDetails'] = f"{err_msg} {err_data}"
            if (err_msg):
                self.insert_alarmcycle(iactoken=iac1_inp_data["robotUID"], tasktype="Error", message=err_msg)
            else:
                jsonid = self.insert_json(jsoninput=iac1_resp_data)
                with self.connection as conn:
                    with conn.cursor() as cur:

                        cur.execute("select commandname from alarmcommandruledetails where commandformat ='{}' and alarmname in (select alarmname from alarminfo where iactoken ='{}')".format(iac1_resp_data["mmlCommand"], iac1_resp_data["robotUID"]))
                        res = cur.fetchone()
                        print("res ----- ", res)
                        if res is None:
                            cur.execute("select commandname from alarmcommandruledetails where regexp_replace(commandformat, '<param\d>', '', 'g') = regexp_replace('{}', '\d+', '', 'g') and alarmname in (select alarmname from alarminfo where iactoken ='{}')".format(iac1_resp_data["mmlCommand"], iac1_resp_data["robotUID"]))
                            res = cur.fetchone()
                            print("res2 ----- ", res)
                        print("res3 ----- ", res)
                        if res is None:
                            cmd = None
                        else:
                            cmd = res[0]
                        # else:
                        #     cmd
                settings.logger.info(f"Response from 1AC1.0 commandname:{cmd}")
                cycleid = self.insert_alarmcycle(iactoken=iac1_resp_data["robotUID"], tasktype="Response from iAC 1.0", inputreceived=jsonid, commandname=cmd, mmlcommand=iac1_resp_data["mmlCommand"], resolutionsummary=iac1_resp_data["alarmResolutionSummary"], resolutioncode=iac1_resp_data["resolutionStatus"])
                alarmtext = self.execute_query(query="select alarmname from alarminfo where iactoken=%s", param=(str(iac1_resp_data['robotUID']),))
                if isiAC1AutoAlarm(alarmtext):
                    if iac1_resp_data["resolutionStatus"] == "0":
                        r = self.execute_query(query="select criticalcommand from commanddictionary where commandname=%s", param=(str(cmd),))
                        print("R value is ", r)
                        if r == True:
                            self.update_alarmstatus(iactoken=iac1_resp_data["robotUID"], status="Manual-Critical Command")
                        else:
                            res = self.execute_query("update alarminfo set status= case when executionmode='Auto' then %s when executionmode='Training' then %s else null end,updatedtime=now() where iactoken=%s returning status", (self.get_statuscode(status="Processing"), self.get_statuscode(status="Manual"), iac1_resp_data["robotUID"],))
                            if res == 1:
                                self.execute_mml_to_rpa(iactoken=iac1_resp_data["robotUID"], parentid=cycleid, mmlcommand=iac1_resp_data["mmlCommand"], resolutioncode="0", resolutionsummary=iac1_resp_data["alarmResolutionSummary"], commandname=cmd)
                    elif iac1_resp_data["resolutionStatus"] == "1":
                        rstatus = self.get_statuscode(status="Resolved")
                        res = self.execute_query("update alarminfo set status= case when executionmode='Auto' then %s when executionmode='Training' then %s else null end,updatedtime=now() where iactoken=%s returning status", (str(rstatus), self.get_statuscode(status="Manual"), iac1_resp_data['robotUID'],))
                        print("Type of res", type(res))
                        if res == rstatus:
                            cycleid = self.insert_alarmcycle(iactoken=iac1_resp_data["robotUID"], tasktype="Cycle End", resolutioncode="1", resolutionsummary=iac1_resp_data["alarmResolutionSummary"], mmlcommand=iac1_resp_data["mmlCommand"])
                            # self.execute_query("update ticketdetails set status= case when cnt=0 then 4 else 1 end from ( select ticketid,count(ticketid) as cnt from alarminfo where ticketid=(select ticketid from alarminfo where iactoken=%s) and scope ='In' and status not in (%s,%s) and status is not null group by ticketid)a where ticketdetails.ticketid=a.ticketid returning status", (iac1_resp_data["robotUID"], self.get_statuscode("Resolved"), self.get_statuscode("Closed"),))
                            self.execute_mml_to_rpa(iactoken=iac1_resp_data["robotUID"], parentid=cycleid, resolutioncode="1", resolutionsummary=iac1_resp_data["alarmResolutionSummary"])

                    elif iac1_resp_data["resolutionStatus"] == "8":
                        if iac1_resp_data["alarmResolutionSummary"] == "GDC Operation Ongoing":
                            self.update_alarmstatus(iactoken=iac1_resp_data["robotUID"], status="Manual-GDC Analysis")
                        else:
                            self.update_alarmstatus(iactoken=iac1_resp_data["robotUID"], status="Manual-No Command")

                    else:
                        res = self.execute_query("update alarminfo set status= case when executionmode='Auto' then %s when executionmode='Training' then %s else null end,updatedtime=now() where iactoken=%s returning status", (self.get_statuscode(status="Processing"), self.get_statuscode(status="Manual"), iac1_resp_data["robotUID"]))
                        if res == 1:
                            cycleid = self.insert_alarmcycle(iactoken=iac1_resp_data["robotUID"], tasktype="User Update", resolutioncode=iac1_resp_data["resolutionStatus"], inputreceived=jsonid, resolutionsummary=iac1_resp_data["alarmResolutionSummary"], mmlcommand=iac1_resp_data["mmlCommand"])
                            self.execute_mml_to_rpa(iactoken=iac1_resp_data["robotUID"], parentid=cycleid, mmlcommand=iac1_resp_data["mmlCommand"], resolutioncode="1", resolutionsummary=iac1_resp_data["alarmResolutionSummary"])

        except:
            err = f"Exception while inserting data into DB"
            print(f"{err} {traceback.format_exc()}")

    def send_alarms_to_iAC1(self, alarm):
        print(f"Forwarding to iAC 1.0 at URL {settings.iAC1_URL}")
        print(f"JSON is {alarm}")

        if settings.iAC1_URL:
            # for alarm in alrm_set["pre"]:
            try:
                iac1_alrm_json = {}

                nd_type = "NSS"
                if alarm.get('AdditionalFields').get('loginType'):
                    val = int(alarm.get('AdditionalFields').get('loginType'))
                    if val == 4:
                        nd_type = "1"
                    elif val == 3:
                        nd_type = "2"
                elif alarm.get('NodeType') and alarm.get('NodeType') == "BSS":
                    nd_type = "BSS"

                iac_tok = alarm.get('iACToken');
                print(f"Preparing AC 1.0 json for {iac_tok}")
                iac1_alrm_json['additionalInfo'] = alarm.get('AdditionalInfo')
                iac1_alrm_json['nodebid'] = alarm.get('AdditionalFields').get('nodebid')
                iac1_alrm_json['bcfID'] = alarm.get('NodeID')
                iac1_alrm_json['alarmText'] = alarm.get('AlarmName')
                iac1_alrm_json['countryName'] = alarm.get('AdditionalFields').get('countryName')
                iac1_alrm_json['nodeName'] = alarm.get('NodeName')
                iac1_alrm_json['nodeType'] = nd_type
                iac1_alrm_json['robotUID'] = iac_tok
                iac1_alrm_json['vendorType'] = alarm.get('NodeVendor')
                iac1_alrm_json['eventTime'] = alarm.get('EventTime')

                print(f"Sending {iac_tok} to iAC 1.0")
                print(f"iAC 1.0 json {iac1_alrm_json}")
                r = requests.get(settings.iAC1_URL, json=iac1_alrm_json, proxies=settings.NO_PROXY, timeout=3)

                print(f"Receivied response from iAC 1.0 {r.content}")
                if r.status_code == 200:
                    print(f"Sent iAC token {iac_tok} to iAC 1.0 {r.content}")
                    iac1_resp = r.json()
                    self.insert_iac1_data_into_db(iac1_alrm_json, iac1_resp, None, None)
                else:
                    iac1_resp = {}
                    err = f"Failed to send iAC token {iac_tok} to iAC 1.0"
                    print(f"{err} {r.content}")
                    self.insert_iac1_data_into_db(iac1_alrm_json, iac1_resp, err, r.content)
            except:
                iac1_resp = {}
                err = f"Exception while sending iAC token {alarm['iACToken']} to iAC 1.0"
                print(f"{err} {traceback.format_exc()}")
                self.insert_iac1_data_into_db(iac1_alrm_json, iac1_resp, err, traceback.format_exc())
        else:
            print("settings.iAC1_URL is not configured, skipping alarm forwarding to iAC 1.0")

        print("Alarm forwarding to iAC 1.0 completed")

    def process_alarms(self, dfalarms=None):
        settings.logger.info("Starting Process Alarms")
        if dfalarms is not None and not dfalarms.empty:
            for inx, arow in dfalarms.iterrows():
                try:
                    alarm = arow.to_dict()
                    if self.insert_alarm(iactoken=alarm["iactoken"], ticketid=alarm["TicketID"], additionalinfo=alarm["additionalInfo"], bcfid=alarm["bcfID"], nodename=alarm["nodeName"], additionalfields=json.dumps(split_dict(alarm, ['robotUID', 'bcfID', 'customer', 'vendorType', 'executionmode', 'nodegroup', 'nodeName', 'nodeType', 'alarmNumber', 'alarmText', 'eventTime', 'additionalInfo', 'ParentId', 'final', 'scope', 'status'])), customer=alarm["customer"], nodevendor=alarm["vendorType"], status=alarm["status"], nodetype=alarm["nodeType"], alarmnumber=alarm["alarmNumber"], alarmname=alarm["alarmText"], eventtime=alarm["eventTime"], scope=alarm["scope"], iacalarmid=alarm["iacalarmid"], parentalarm=alarm["parentalarm"], nodeparent=alarm["ParentId"], executionmode=alarm["executionmode"], nodegroup=alarm["nodegroup"]):
                        settings.logger.debug("Alarm inserted, iactoken: {alarm['iactoken']}")
                        if alarm['scope'] == "In" and alarm["final"] == True:
                            self.insert_alarmcycle(iactoken=alarm["iactoken"], tasktype="Cycle Start", inputreceived=alarm["jsonid"])
                            self.send_alarm_to_ps(iactoken=alarm["iactoken"], tasktype="Alarm to Predictive Service")
                            self.send_alarms_to_iAC1(AlarmHandler().generate_alarmjson2(alarm["iactoken"]))
                except BaseException as e:
                    jsonid = self.insert_json(jsoninput={"errordetails": traceback.format_exc()})
                    settings.logger.error(f"Error while processing alarm {alarm['iactoken']} jsonid:{jsonid} traceback: {traceback.format_exc()}")
            # emailhandler = EmailHandler()
            try:
                notify_alarm_df = dfalarms[dfalarms.alarmText.isin(settings.EMAIL_ALARM_TYPE)][['TicketID', 'alarmText',
                                                                                                'bcfID', 'iactoken',
                                                                                                'eventTime']]
                notify_alarm_df.rename(index=str, columns={"TicketID": "TT Number", "alarmText": "Alarm Name", "bcfID": "Node Id",
                                                           "iactoken": "IAC Token", "eventTime": "Event Time"}, inplace=True)
                if len(notify_alarm_df) != 0:
                    email_handler = EmailHandler();
                    email_handler.sendmail(senderid=settings.EMAIL_FROM, to_recipient=settings.EMAIL_ALARM_TO,
                                           subject=Constants.ALARM_ADD_EMAIL_SUBJECT.format(notify_alarm_df["Alarm Name"].iloc[0]),
                                           body=Constants.ALARM_ADD_EMAIL_BODY.format(notify_alarm_df.to_html(index=False)))
                    print("Emailed sucessfully")
            except BaseException as e:
                settings.logger.error(f"Error while processing alarm {alarm['iactoken']} jsonid:{jsonid} traceback: {traceback.format_exc()}")

            settings.logger.info("Ending Process Alarms")
            # emailhandler.sendmail()

    def process_mmloutput(self, mmljson):
        print("Started process_mmloutput")
        try:
            alarm_dao = AlarmInfoDataAccess()
            iac_token = mmljson['robotUID']
            # Do not submit to IAC1.0 if cycle end
            if alarm_dao.is_alarm_cycle_end(iac_token):
                return

            # self.process_mmloutput_from_rpa(mmljson)
            if mmljson["responsecode"] != "1" and mmljson['status'] == "1":
                if settings.iAC1_URL:

                    print("Constructing iAC 1.0 mmloutput packet")
                    iac_tok = mmljson['robotUID']
                    iac1_mmlout_json = {}
                    iac1_mmlout_json['correlationId'] = '0'
                    iac1_mmlout_json['robotUID'] = mmljson['robotUID']
                    iac1_mmlout_json['mmlCommandOutput'] = mmljson['mmlcommandoutput']

                    print(f"Sending mmlouput of iACToken {iac_tok} to iAC 1.0")
                    print(f"iAC 1.0 mmloutput json {iac1_mmlout_json}")
                    r = requests.get(settings.iAC1_URL, json=iac1_mmlout_json, proxies=settings.NO_PROXY, timeout=3)

                    print("Test2")
                    print(f"Receivied response from iAC 1.0 {r.content}")
                    if r.status_code == 200:
                        print(f"Sent mmloutput of iAC token {iac_tok} to iAC 1.0 {r.content}")
                        iac1_resp = r.json()
                        self.insert_iac1_data_into_db(iac1_mmlout_json, iac1_resp, None, None)
                    else:
                        iac1_resp = {}
                        err = f"Failed to send mmloutput of iAC token {iac_tok} to iAC 1.0"
                        print(f"{err} {r.content}")
                        self.insert_iac1_data_into_db(iac1_mmlout_json, iac1_resp, err, r.content)
                else:
                    print(f"iAC1 URL is not set, skipping to forward mmloutput")

        except:
            iac1_resp = {}
            err = f"Exception while processing mmloutput form RPA"
            print(f"{err} {traceback.format_exc()}")
            self.insert_iac1_data_into_db(None, iac1_resp, err, traceback.format_exc())
        print("Completed process_mmloutput")

    def get_alarm_executionmode(self, iactoken=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("select executionmode from alarminfo where iactoken='{}'".format(iactoken))
                    return cur.fetchone()[0]
        except BaseException as e:
            # traceback.print_exc()
            settings.logger.error(f"Error while executing query, traceback: {traceback.format_exc()}")
            return None

    def process_mml_from_ps(self, jsoninput):
        inputjson = None
        try:
            if validate_json(jsoninput):
                inputjson = self.insert_json(jsoninput)
                v = checkForKeys(jsoninput, ['iACToken', 'ParserOutput', 'PredictorOutput', 'SubstitutorOutput'])
                w = checkForValues(jsoninput, ['iACToken', 'ParserOutput', 'PredictorOutput', 'SubstitutorOutput'], v)

                # print("Validation 1 result: ",w)
                settings.logger.debug(f"Validation 1 result:{w}")
                if v is None and w is None:
                    # preoutput = pd.Series(jsoninput["PredictorOutput"], index=["debug", "mmlCommand", "traceback", "errorstack", "similarityScore", "rsname", "resolutionStatus"])
                    # preoutput.replace({np.nan: None}, inplace=True)
                    # suboutput = pd.Series(jsoninput["SubstitutorOutput"], index=["mmlCommand", "iacstatus", "iacerrordetails", "resolutionStatus"])
                    # suboutput.replace({np.nan: None}, inplace=True)
                    jsoninput["PredictorOutput"]["rsname"] = None if checkForKeys(jsoninput['PredictorOutput'], ['rsname']) is not None else jsoninput['PredictorOutput']["rsname"]
                    jsoninput["SubstitutorOutput"]["resolutionSummary"] = None if checkForKeys(jsoninput['SubstitutorOutput'], ['resolutionSummary']) is not None else jsoninput['SubstitutorOutput']["resolutionSummary"]
                    # cmdid = self.insert_alarmcycle(jsoninput["iACToken"], "Response from Predictive Service", inputreceived=inputjson, resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"], commandname=jsoninput["PredictorOutput"]["mmlCommand"], rsname=jsoninput["PredictorOutput"]["rsname"])
                    with self.connection as conn:
                        with conn.cursor() as cur:
                            error_status = ""
                            if jsoninput['ParserOutput']['iacstatus'] == "Failed":
                                error_status = 'Parser Error - ' + jsoninput['ParserOutput'].get('iacerrordetails', 'Verify Logs')
                            elif jsoninput['PredictorOutput']['iacstatus'] == "Failed":
                                error_status = 'Predictor Error - ' + jsoninput['PredictorOutput'].get('iacerrordetails', 'Verify Logs')
                            elif jsoninput['SubstitutorOutput']['iacstatus'] == "Failed":
                                error_status = 'Subsitutor Error - ' + jsoninput['SubstitutorOutput'].get('iacerrordetails', 'Verify Logs')

                            if error_status != "":

                                cmdid = self.insert_alarmcycle(jsoninput["iACToken"], "Response from Predictive Service", inputreceived=inputjson)
                                self.insert_alarmcycle(jsoninput["iACToken"], "Error", parentid=cmdid, inputreceived=inputjson, message=error_status)
                                if not isiAC1AutoAlarm(jsoninput["AlarmName"]):
                                    self.update_alarmstatus(iactoken=jsoninput['iACToken'], status="Manual-Fail")
                                return
                            v = checkForKeys(jsoninput["PredictorOutput"], ["resolutionStatus", "rsname", "mmlCommand"])
                            w = checkForValues(jsoninput["PredictorOutput"], ["resolutionStatus"], v)
                            # print("Validation 2 result: ",w)
                            settings.logger.debug(f"Validation 2 result:{w}")
                            if v is None and w is None:

                                if jsoninput['ParserOutput'].get('iacerrordetails') is not None:
                                    error_status = 'Parser Error - ' + jsoninput['ParserOutput'].get('iacerrordetails',
                                                                                                     'Verify Logs')

                                if jsoninput['PredictorOutput']['resolutionStatus'] == 0:
                                    if jsoninput['SubstitutorOutput']['resolutionStatus'] == 0:
                                        action = jsoninput['PredictorOutput']['resolutionStatus']
                                        guireset_alarms = ['WCDMA CELL OUT OF USE fault', 'WCDMA BASE STATION OUT OF USE fault']
                                        command = jsoninput["SubstitutorOutput"]["mmlCommand"]
                                        res_summary = jsoninput["SubstitutorOutput"]["resolutionSummary"]
                                        commandname = jsoninput["PredictorOutput"]["mmlCommand"]
                                        res_name = jsoninput["PredictorOutput"]["rsname"]
                                        # hook for GUI Reset scenario
                                        if (jsoninput['AlarmName'] in guireset_alarms) \
                                                and jsoninput['History'].get('cmd_list') is not None \
                                                and len(jsoninput['History']['cmd_list']) == 2 \
                                                and jsoninput['History']['cmd_list'][0] == command:
                                            action = 7  # GUI RESET

                                        settings.logger.debug(f"iACToken :{jsoninput['iACToken']} resolutioncode: {jsoninput['SubstitutorOutput']['resolutionStatus']}")
                                        cmdid = self.insert_alarmcycle(jsoninput["iACToken"],
                                                                       "Response from Predictive Service",
                                                                       inputreceived=inputjson, resolutioncode=action,
                                                                       resolutionsummary=res_summary,
                                                                       mmlcommand=command,
                                                                       commandname=commandname,
                                                                       rsname=res_name,
                                                                       message=error_status)

                                        if not isiAC1AutoAlarm(jsoninput["AlarmName"]):
                                            r = self.get_command_details(commandname=str(jsoninput["PredictorOutput"]["mmlCommand"]))
                                            # r = self.execute_query("select criticalcommand from commanddictionary where commandname='{}'".format(str(jsoninput["PredictorOutput"]["mmlCommand"])))
                                            if r is not None and r[0] == True:
                                                self.update_alarmstatus(iactoken=jsoninput['iACToken'], status="Manual-Critical Command")
                                            else:
                                                processing_code = self.get_statuscode(status="Processing")
                                                res = self.execute_query("update alarminfo set status= case when executionmode='Auto' then %s when executionmode='Training' then %s else null end,updatedtime=now() where iactoken=%s returning status", (processing_code, self.get_statuscode(status="Manual"), jsoninput['iACToken']))
                                                if res == processing_code:
                                                    self.process_gui_execute_command(beforeexecute=r[1], reattempt=r[2],
                                                                                     iactoken=jsoninput["iACToken"],
                                                                                     parentid=cmdid,
                                                                                     resolutioncode=action,
                                                                                     mmlcommand=command,
                                                                                     resolutionsummary=res_summary,
                                                                                     commandname=jsoninput["PredictorOutput"]["mmlCommand"])
                                    elif jsoninput['SubstitutorOutput']['resolutionStatus'] == 8:
                                        self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Response from Predictive Service", resolutioncode=8, inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], message=jsoninput["SubstitutorOutput"]["iacerrordetails"], commandname=jsoninput["PredictorOutput"]["mmlCommand"], rsname=jsoninput["PredictorOutput"]["rsname"])
                                        if not isiAC1AutoAlarm(jsoninput["AlarmName"]):
                                            self.update_alarmstatus(iactoken=jsoninput["iACToken"], status="Manual-Fail")
                                elif jsoninput['PredictorOutput']['resolutionStatus'] == 8:
                                    self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Response from Predictive Service", resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], rsname=jsoninput["PredictorOutput"]["rsname"],message=error_status)
                                    if not isiAC1AutoAlarm(jsoninput["AlarmName"]):

                                        if jsoninput['SubstitutorOutput']['resolutionSummary'] == "GDC Operation Ongoing":
                                            rstatus = self.get_statuscode(status="Manual-GDC Analysis")
                                            res = self.execute_query("update alarminfo set status= case when executionmode='Auto' then %s when executionmode='Training' then %s else null end,updatedtime=now() where iactoken=%s returning status", (str(rstatus), self.get_statuscode(status="Manual"), jsoninput['iACToken']))

                                            if res == rstatus:
                                                # self.update_alarmstatus(iactoken=jsoninput["iACToken"], status="Manual-GDC Analysis")

                                                cmdid = self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Cycle End", resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], rsname=jsoninput["PredictorOutput"]["rsname"])
                                                self.execute_mml_to_rpa(iactoken=jsoninput["iACToken"], parentid=cmdid, resolutioncode="8", resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], rsname=jsoninput["PredictorOutput"]["rsname"])

                                        else:
                                            # if not isiAC1AutoAlarm(jsoninput["AlarmName"]):
                                            self.update_alarmstatus(iactoken=jsoninput["iACToken"], status="Manual-No Command")



                                elif jsoninput['PredictorOutput']['resolutionStatus'] == 7:
                                    if jsoninput['SubstitutorOutput']['resolutionStatus'] == 7:
                                        settings.logger.debug(f"iACToken :{jsoninput['iACToken']} resolutioncode: {jsoninput['SubstitutorOutput']['resolutionStatus']}")
                                        cmdid = self.insert_alarmcycle(jsoninput["iACToken"], "Response from Predictive Service", inputreceived=inputjson, resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"], commandname=jsoninput["PredictorOutput"]["mmlCommand"],message=error_status)

                                        processing_code = self.get_statuscode(status="Processing")
                                        res = self.execute_query("update alarminfo set status= case when executionmode='Auto' then %s when executionmode='Training' then %s else null end,updatedtime=now() where iactoken=%s returning status", (processing_code, self.get_statuscode(status="Manual"), jsoninput['iACToken']))
                                        if res == processing_code:
                                            self.execute_mml_to_rpa(iactoken=jsoninput["iACToken"], parentid=cmdid, mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"], resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], commandname=jsoninput["PredictorOutput"]["mmlCommand"])
                                    elif jsoninput['SubstitutorOutput']['resolutionStatus'] == 8:
                                        self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Response from Predictive Service", resolutioncode=8, inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], message=jsoninput["SubstitutorOutput"]["iacerrordetails"], commandname=jsoninput["PredictorOutput"]["mmlCommand"])
                                        if not isiAC1AutoAlarm(jsoninput["AlarmName"]):
                                            self.update_alarmstatus(iactoken=jsoninput["iACToken"], status="Manual-No Command")




                                elif jsoninput['PredictorOutput']['resolutionStatus'] == 1:
                                    self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Response from Predictive Service", resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"], rsname=jsoninput["PredictorOutput"]["rsname"],message=error_status)
                                    if not isiAC1AutoAlarm(jsoninput["AlarmName"]):
                                        rstatus = self.get_statuscode(status="Resolved")
                                        res = self.execute_query("update alarminfo set status= case when executionmode='Auto' then %s when executionmode='Training' then %s else null end,updatedtime=now() where iactoken=%s returning status", (str(rstatus), self.get_statuscode(status="Manual"), jsoninput['iACToken']))
                                        if res == rstatus:
                                            cycleid = self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Cycle End", resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"])
                                            # self.execute_query("update ticketdetails set status= case when cnt=0 then 4 else 1 end from ( select ticketid,count(ticketid) as cnt from alarminfo where ticketid=(select ticketid from alarminfo where iactoken=%s) and scope ='In' and status not in (%s,%s) and status is not null group by ticketid)a where ticketdetails.ticketid=a.ticketid returning status", (jsoninput["iACToken"], self.get_statuscode("Resolved"), self.get_statuscode("Closed")))
                                            self.execute_mml_to_rpa(iactoken=jsoninput["iACToken"], parentid=cycleid, resolutioncode="1", resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"])
                                elif jsoninput['PredictorOutput']['resolutionStatus'] == 2:
                                    self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Response from Predictive Service", resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"], rsname=jsoninput["PredictorOutput"]["rsname"],message=error_status)
                                    if not isiAC1AutoAlarm(jsoninput["AlarmName"]):
                                        rstatus = self.get_statuscode(status="iAC Operation Complete")
                                        res = self.execute_query("update alarminfo set status= case when executionmode='Auto' then %s when executionmode='Training' then %s else null end,updatedtime=now() where iactoken=%s returning status", (str(rstatus), self.get_statuscode(status="Manual"), jsoninput['iACToken']))
                                        if res == rstatus:
                                            alarm_dao = AlarmInfoDataAccess()
                                            alarm_info = alarm_dao.get_alarminfo(iactoken=jsoninput["iACToken"])
                                            ticket_id = alarm_info['ticketid']
                                            if alarm_info['nodegroup'] == 'BSS':
                                                self.insert_alarmcycle(iactoken=jsoninput["iACToken"],
                                                                       tasktype="Cycle End",
                                                                       resolutioncode=jsoninput['PredictorOutput'][
                                                                           'resolutionStatus'], inputreceived=inputjson,
                                                                       resolutionsummary=jsoninput["SubstitutorOutput"][
                                                                           "resolutionSummary"],
                                                                       mmlcommand=jsoninput["SubstitutorOutput"][
                                                                           "mmlCommand"])
                                                self.update_alarmstatus(iactoken=jsoninput["iACToken"],
                                                                        status="iAC Operation Complete",
                                                                        message="Task Creation disabled for BSS.")
                                            else:
                                                cycleid = self.insert_alarmcycle(iactoken=jsoninput["iACToken"],
                                                                       tasktype="Cycle End",
                                                                       resolutioncode=jsoninput['PredictorOutput'][
                                                                           'resolutionStatus'], inputreceived=inputjson,
                                                                       resolutionsummary=jsoninput["SubstitutorOutput"][
                                                                           "resolutionSummary"],
                                                                       mmlcommand=jsoninput["SubstitutorOutput"][
                                                                           "mmlCommand"])
                                                self.update_alarmstatus(iactoken=jsoninput["iACToken"],
                                                                        status="iAC Operation Complete",
                                                                        message="Task Creation in progress")
                                                # cycleid = self.insert_alarmcycle(iactoken=jsoninput["iACToken"],
                                                #                                  tasktype="User Update", resolutioncode=
                                                #                                  jsoninput['PredictorOutput'][
                                                #                                      'resolutionStatus'],
                                                #                                  inputreceived=inputjson,
                                                #                                  resolutionsummary=
                                                #                                  jsoninput["SubstitutorOutput"][
                                                #                                      "resolutionSummary"],
                                                #                                  mmlcommand=
                                                #                                  jsoninput["SubstitutorOutput"][
                                                #                                      "mmlCommand"])

                                                self.execute_mml_to_rpa(iactoken=jsoninput["iACToken"], parentid=cycleid,
                                                                        mmlcommand=jsoninput["SubstitutorOutput"][
                                                                            "mmlCommand"],
                                                                        resolutioncode=jsoninput['PredictorOutput'][
                                                                            'resolutionStatus'],
                                                                        resolutionsummary=jsoninput["SubstitutorOutput"][
                                                                            "resolutionSummary"])

                                else:
                                    self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Response from Predictive Service",
                                                           resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'],
                                                           inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"], rsname=jsoninput["PredictorOutput"]["rsname"],message=error_status)

                                    if not isiAC1AutoAlarm(jsoninput["AlarmName"]):
                                        processing_code = self.get_statuscode(status="Processing")
                                        res = self.execute_query("update alarminfo set status= case when executionmode='Auto' then %s when executionmode='Training' then %s else null end,updatedtime=now() where iactoken=%s returning status", (processing_code, self.get_statuscode(status="Manual"), jsoninput['iACToken']))
                                        if res == processing_code:
                                            cycleid = self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="User Update", resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"],rsname=jsoninput["PredictorOutput"]["rsname"])
                                            self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Cycle End", resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"],rsname=jsoninput["PredictorOutput"]["rsname"])
                                            self.execute_mml_to_rpa(iactoken=jsoninput["iACToken"], parentid=cycleid, mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"], resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"])
                            else:

                                x = checkForKeys(jsoninput['SubstitutorOutput'], ["resolutionStatus"])
                                y = checkForValues(jsoninput['SubstitutorOutput'], ["resolutionStatus"], x)
                                preoutput = pd.Series(jsoninput["PredictorOutput"], index=["debug", "mmlCommand", "traceback", "errorstack", "similarityScore", "rsname", "resolutionStatus"])
                                preoutput.replace({np.nan: None}, inplace=True)
                                suboutput = pd.Series(jsoninput["SubstitutorOutput"], index=["mmlCommand", "iacstatus", "iacerrordetails", "resolutionStatus", "resolutionSummary"])
                                suboutput.replace({np.nan: None}, inplace=True)
                                if x is None and y is None:
                                    self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Response from Predictive Service", resolutioncode=jsoninput['SubstitutorOutput']['resolutionStatus'], inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], rsname=jsoninput["PredictorOutput"]["rsname"])
                                    if suboutput['resolutionStatus'] == 8 and suboutput['iacstatus'] == "Failed":
                                        if not isiAC1AutoAlarm(jsoninput["AlarmName"]):
                                            self.update_alarmstatus(iactoken=jsoninput["iACToken"], status="Manual-Fail")

                                else:
                                    settings.logger.error(f"JSON not having mandatory fields {y}")
                                    self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Response from Predictive Service", resolutioncode=suboutput['resolutionStatus'], inputreceived=inputjson, resolutionsummary=suboutput["resolutionSummary"], rsname=preoutput["rsname"])
                                    self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Error", resolutioncode=suboutput['resolutionStatus'], inputreceived=inputjson, resolutionsummary=suboutput["resolutionSummary"], rsname=preoutput["rsname"], message=y)
                                    self.update_alarmstatus(iactoken=jsoninput["iACToken"], status="Manual-Fail")

                else:
                    settings.logger.error(f"Error {w}------json: {jsoninput}")
                    if checkForKeys(jsoninput, ["iACToken"]) is None:
                        self.insert_alarmcycle(iactoken=jsoninput["iACToken"], inputreceived=inputjson, tasktype="Error", message="Invalid JSON from PS, " + w)
                        self.update_alarmstatus(iactoken=jsoninput["iACToken"], status="Manual-Fail")
                    else:
                        settings.logger.error(f"Error---------------------------iACToken is missing {jsoninput}")
            else:
                settings.logger.error(f"JSON Error ----------- invalid json {jsoninput}")
        except BaseException as e:
            settings.logger.error(traceback.format_exc())
            settings.logger.error(jsoninput)
            if checkForKeys(jsoninput, ["iACToken"]) is None:

                self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Error", inputreceived=self.insert_json(jsoninput={"errordetails": traceback.format_exc()}), message="Exception while parsing PS Response JSON from PS, " + str(e))
                self.update_alarmstatus(iactoken=jsoninput["iACToken"], status="Manual-Fail")
            else:
                settings.logger.error("Error occured in JSON")

    def process_mml_from_ps2(self, jsoninput):
        inputjson = None
        try:
            if validate_json(jsoninput):
                inputjson = self.insert_json(jsoninput)
                v = checkForKeys(jsoninput, ['iACToken', 'ParserOutput', 'PredictorOutput', 'SubstitutorOutput'])
                w = checkForValues(jsoninput, ['iACToken', 'ParserOutput', 'PredictorOutput', 'SubstitutorOutput'], v)

                # print("Validation 1 result: ",w)
                settings.logger.info(f"Validation 1 result:{w}")
                if v is None and w is None:
                    preoutput = pd.Series(jsoninput["PredictorOutput"], index=["debug", "mmlCommand", "traceback", "errorstack", "similarityScore", "rsname", "resolutionStatus"])
                    preoutput.replace({np.nan: None}, inplace=True)
                    suboutput = pd.Series(jsoninput["SubstitutorOutput"], index=["mmlCommand", "iacstatus", "iacerrordetails", "resolutionStatus", "resolutionSummary"])
                    suboutput.replace({np.nan: None}, inplace=True)
                    cmdid = self.insert_alarmcycle(jsoninput["iACToken"], "Response from Predictive Service", inputreceived=inputjson, resolutioncode=suboutput['resolutionStatus'], resolutionsummary=suboutput["resolutionSummary"], mmlcommand=suboutput["mmlCommand"], commandname=preoutput["mmlCommand"], rsname=preoutput["rsname"])
                    # if suboutput["resolutionStatus"] is None:
                    #     if preoutput["resolutionStatus"] is None:

                    with self.connection as conn:
                        with conn.cursor() as cur:
                            v = checkForKeys(jsoninput["PredictorOutput"], ["resolutionStatus", "rsname", "mmlCommand"])
                            w = checkForValues(jsoninput["PredictorOutput"], ["resolutionStatus"], v)
                            # print("Validation 2 result: ",w)
                            settings.logger.info(f"Validation 2 result:{w}")
                            if v is None and w is None:
                                if suboutput['resolutionStatus'] is None:
                                    if preoutput["mmlCommand"] is None:
                                        pass
                                if jsoninput['PredictorOutput']['resolutionStatus'] == 0:
                                    if jsoninput['SubstitutorOutput']['resolutionStatus'] == 0:
                                        settings.logger.info(f"iACToken :{jsoninput['iACToken']} resolutioncode: {jsoninput['SubstitutorOutput']['resolutionStatus']}")
                                        cmdid = self.insert_alarmcycle(jsoninput["iACToken"], "Response from Predictive Service", inputreceived=inputjson, resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"], commandname=jsoninput["PredictorOutput"]["mmlCommand"], rsname=jsoninput["PredictorOutput"]["rsname"])

                                        if not isiAC1AutoAlarm(jsoninput["AlarmName"]):
                                            r = self.execute_query("select criticalcommand from commanddictionary where commandname='{}'".format(str(jsoninput["PredictorOutput"]["mmlCommand"])))
                                            if r == 't':
                                                self.update_alarmstatus(iactoken=jsoninput['iACToken'], status="Manual-Critical Command")
                                            else:
                                                res = self.execute_query("update alarminfo set status= case when executionmode='Auto' then %s when executionmode='Training' then %s else null end,updatedtime=now() where iactoken=%s returning status", (self.get_statuscode(status="Processing"), self.get_statuscode(status="Manual"), jsoninput['iACToken']))
                                                if res == 1:
                                                    self.execute_mml_to_rpa(iactoken=jsoninput["iACToken"], parentid=cmdid, mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"], resolutioncode="0", resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], commandname=jsoninput["PredictorOutput"]["mmlCommand"])
                                    elif jsoninput['SubstitutorOutput']['resolutionStatus'] == 8:
                                        self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Response from Predictive Service", resolutioncode=8, inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], message=jsoninput["SubstitutorOutput"]["iacerrordetails"], commandname=jsoninput["PredictorOutput"]["mmlCommand"], rsname=jsoninput["PredictorOutput"]["rsname"])
                                        if not isiAC1AutoAlarm(jsoninput["AlarmName"]):
                                            self.update_alarmstatus(iactoken=jsoninput["iACToken"], status="Manual-Fail")
                                elif jsoninput['PredictorOutput']['resolutionStatus'] == 8:
                                    self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Response from Predictive Service", resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], rsname=jsoninput["PredictorOutput"]["rsname"])
                                    if not isiAC1AutoAlarm(jsoninput["AlarmName"]):
                                        if jsoninput['SubstitutorOutput']['resolutionSummary'] == "GDC Operation Ongoing":
                                            self.update_alarmstatus(iactoken=jsoninput["iACToken"], status="Manual-GDC Analysis")
                                        else:
                                            # if not isiAC1AutoAlarm(jsoninput["AlarmName"]):
                                            self.update_alarmstatus(iactoken=jsoninput["iACToken"], status="Manual-No Command")
                                elif jsoninput['PredictorOutput']['resolutionStatus'] == 1:
                                    self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Response from Predictive Service", resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"], rsname=jsoninput["PredictorOutput"]["rsname"])
                                    if not isiAC1AutoAlarm(jsoninput["AlarmName"]):
                                        rstatus = str(self.get_statuscode(status="Resolved"))
                                        res = self.execute_query("update alarminfo set status= case when executionmode='Auto' then %s when executionmode='Training' then %s else null end,updatedtime=now() where iactoken=%s returning status", (str(rstatus), self.get_statuscode(status="Manual"), jsoninput['iACToken']))
                                        if res == rstatus:
                                            cycleid = self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Cycle End", resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"])
                                            # self.execute_query("update ticketdetails set status= case when cnt=0 then 4 else 1 end from ( select ticketid,count(ticketid) as cnt from alarminfo where ticketid=(select ticketid from alarminfo where iactoken=%s) and scope ='In' and status not in (%s,%s) and status is not null group by ticketid)a where ticketdetails.ticketid=a.ticketid returning status", (jsoninput["iACToken"], self.get_statuscode("Resolved"), self.get_statuscode("Closed")))
                                            self.execute_mml_to_rpa(iactoken=jsoninput["iACToken"], parentid=cycleid, resolutioncode="1", resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"])
                                else:
                                    self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Response from Predictive Service", resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"], rsname=jsoninput["PredictorOutput"]["rsname"])

                                    if not isiAC1AutoAlarm(jsoninput["AlarmName"]):
                                        res = self.execute_query("update alarminfo set status= case when executionmode='Auto' then %s when executionmode='Training' then %s else null end,updatedtime=now() where iactoken=%s returning status", (self.get_statuscode(status="Processing"), self.get_statuscode(status="Manual"), jsoninput['iACToken']))
                                        if res == 1:
                                            cycleid = self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="User Update", resolutioncode=jsoninput['PredictorOutput']['resolutionStatus'], inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"])
                                            self.execute_mml_to_rpa(iactoken=jsoninput["iACToken"], parentid=cycleid, mmlcommand=jsoninput["SubstitutorOutput"]["mmlCommand"], resolutioncode="1", resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"])
                            else:

                                x = checkForKeys(jsoninput['SubstitutorOutput'], ["resolutionStatus"])
                                y = checkForValues(jsoninput['SubstitutorOutput'], ["resolutionStatus"], x)
                                preoutput = pd.Series(jsoninput["PredictorOutput"], index=["debug", "mmlCommand", "traceback", "errorstack", "similarityScore", "rsname", "resolutionStatus"])
                                preoutput.replace({np.nan: None}, inplace=True)
                                suboutput = pd.Series(jsoninput["SubstitutorOutput"], index=["mmlCommand", "iacstatus", "iacerrordetails", "resolutionStatus"])
                                suboutput.replace({np.nan: None}, inplace=True)
                                if x is None and y is None:
                                    self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Response from Predictive Service", resolutioncode=jsoninput['SubstitutorOutput']['resolutionStatus'], inputreceived=inputjson, resolutionsummary=jsoninput["SubstitutorOutput"]["resolutionSummary"], rsname=jsoninput["PredictorOutput"]["rsname"])
                                    if suboutput['resolutionStatus'] == 8 and suboutput['iacstatus'] == "Failed":
                                        if not isiAC1AutoAlarm(jsoninput["AlarmName"]):
                                            self.update_alarmstatus(iactoken=jsoninput["iACToken"], status="Manual-Fail")

                                else:
                                    settings.logger.error(f"JSON not having mandatory fields {y}")
                                    self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Response from Predictive Service", resolutioncode=suboutput['resolutionStatus'], inputreceived=inputjson, resolutionsummary=suboutput["resolutionSummary"], rsname=preoutput["rsname"])
                                    self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Error", resolutioncode=suboutput['resolutionStatus'], inputreceived=inputjson, resolutionsummary=suboutput["resolutionSummary"], rsname=preoutput["rsname"], message=y)
                                    self.update_alarmstatus(iactoken=jsoninput["iACToken"], status="Manual-Fail")

                else:
                    settings.logger.error(f"Error {w}------json: {jsoninput}")
                    # print(f"JSON Error ------------- " + w)
                    if checkForKeys(jsoninput, ["iACToken"]) is None:
                        self.insert_alarmcycle(iactoken=jsoninput["iACToken"], inputreceived=inputjson, tasktype="Error", message="Invalid JSON from PS, " + w)
                        self.update_alarmstatus(iactoken=jsoninput["iACToken"], status="Manual-Fail")
                    else:
                        settings.logger.error(f"Error---------------------------iACToken is missing {jsoninput}")
                        # print("Error---------------------------iACToken is missing",jsoninput)
            else:
                settings.logger.error(f"JSON Error ----------- invalid json {jsoninput}")
                # print(f"JSON Error ----------- invalid json {jsoninput}")
        except BaseException as e:
            # print("Error -------" + str(e))
            # print(f"----JSON is  {jsoninput}")
            settings.logger.error(traceback.format_exc())
            settings.logger.error(jsoninput)
            # traceback.print_exc()
            if checkForKeys(jsoninput, ["iACToken"]) is None:

                self.insert_alarmcycle(iactoken=jsoninput["iACToken"], tasktype="Error", inputreceived=self.insert_json(jsoninput={"errordetails": traceback.format_exc()}), message="Exception while parsing JSON from PS, " + str(e))
                self.update_alarmstatus(iactoken=jsoninput["iACToken"], status="Manual-Fail")
            else:
                settings.logger.error("Error occured in JSON")

    def process_mml_from_gui2(self, jsoninput, username=None):
        inputjson = None
        try:
            if validate_json(jsoninput):
                inputjson = self.insert_json(jsoninput=jsoninput)
                v = checkForKeys(jsoninput, ['iactoken', 'mmlcommand', 'parentid', 'tasktype', 'resolutionstatus', 'resolutionsummary'])
                w = checkForValues(jsoninput, ['iactoken', 'tasktype', 'resolutionstatus'], v)
                if v == None and w == None:
                    jsoninput["rsname"] = None if checkForKeys(jsoninput, ["rsname"]) is not None else jsoninput["rsname"]
                    with self.connection as conn:
                        with conn.cursor() as cur:
                            rescode = str(jsoninput['resolutionstatus'])
                            if rescode == "0":
                                x = checkForValues(jsoninput, ["mmlcommand"], None)
                                if x is None:
                                    if jsoninput['tasktype'] == "User accepted MML":
                                        cur.execute("select iactoken,mmlcommand,id as parentid,resolutioncode, resolutionsummary,commandname,rsname from alarmcycle where id=" + str(jsoninput["parentid"]))
                                        res = cur.fetchone()
                                        cycleid = self.insert_alarmcycle(iactoken=jsoninput["iactoken"], tasktype="User accepted MML", parentid=res[2], resolutioncode=res[3], inputreceived=inputjson, mmlcommand=res[1], resolutionsummary=res[4], commandname=res[5], username=username, rsname=res[6])
                                        self.update_alarmstatus(iactoken=jsoninput["iactoken"], status="Processing")
                                        conn.commit()
                                        self.execute_mml_to_rpa(iactoken=jsoninput["iactoken"], parentid=cycleid, mmlcommand=jsoninput['mmlcommand'], resolutioncode=res[3], resolutionsummary=res[4], commandname=res[5])
                                    else:
                                        cycleid = self.insert_alarmcycle(iactoken=jsoninput["iactoken"], tasktype="User updated MML", inputreceived=inputjson, mmlcommand=jsoninput["mmlcommand"], parentid=jsoninput["parentid"], username=username, resolutioncode=jsoninput["resolutionstatus"], resolutionsummary=jsoninput["resolutionsummary"], commandname=jsoninput["commandname"], rsname=jsoninput["rsname"])
                                        self.update_alarmstatus(iactoken=jsoninput["iactoken"], status="Processing")
                                        conn.commit()
                                        self.execute_mml_to_rpa(iactoken=jsoninput["iactoken"], mmlcommand=jsoninput["mmlcommand"], parentid=cycleid, resolutioncode=jsoninput["resolutionstatus"], resolutionsummary=jsoninput["resolutionsummary"], commandname=jsoninput["commandname"])
                                else:
                                    self.insert_alarmcycle(iactoken=jsoninput["iactoken"], inputreceived=inputjson, tasktype="Error", message="Invalid JSON from GUI, " + x)
                                    self.update_alarmstatus(iactoken=jsoninput["iactoken"], status="Manual-Fail")
                            elif rescode == "1":
                                x = checkForValues(jsoninput, ["resolutionsummary"], None)
                                if x is None:
                                    cycleid = self.insert_alarmcycle(iactoken=jsoninput["iactoken"], tasktype="Cycle End", inputreceived=inputjson, mmlcommand=jsoninput["mmlcommand"], parentid=jsoninput["parentid"], username=username, resolutioncode=jsoninput["resolutionstatus"], resolutionsummary=jsoninput["resolutionsummary"], rsname=jsoninput["rsname"])
                                    self.update_alarmstatus(iactoken=jsoninput["iactoken"], status="Resolved")
                                    conn.commit()
                                    self.execute_mml_to_rpa(iactoken=jsoninput["iactoken"], parentid=cycleid, resolutioncode=jsoninput["resolutionstatus"], resolutionsummary=jsoninput["resolutionsummary"])
                                else:
                                    self.insert_alarmcycle(iactoken=jsoninput["iactoken"], inputreceived=inputjson, tasktype="Error", message="Invalid JSON from GUI, " + x)
                                    self.update_alarmstatus(iactoken=jsoninput["iactoken"], status="Manual-Fail")
                                # cur.execute("")


                            elif rescode == "7":
                                cycleid = self.insert_alarmcycle(iactoken=jsoninput["iactoken"], tasktype="User Update", inputreceived=inputjson, mmlcommand=jsoninput["mmlcommand"], parentid=jsoninput["parentid"], username=username, resolutioncode=jsoninput["resolutionstatus"], resolutionsummary=jsoninput["resolutionsummary"], rsname=jsoninput["rsname"])
                                self.update_alarmstatus(iactoken=jsoninput["iactoken"], status="Processing")
                                # conn.commit()
                                self.execute_mml_to_rpa(iactoken=jsoninput["iactoken"], parentid=cycleid, commandname=jsoninput["commandname"], mmlcommand=jsoninput["mmlcommand"], resolutioncode=jsoninput['resolutionstatus'], resolutionsummary=jsoninput['resolutionsummary'])
                            elif rescode != "8" and rescode != "55":
                                cycleid = self.insert_alarmcycle(iactoken=jsoninput["iactoken"], tasktype="User Update", inputreceived=inputjson, mmlcommand=jsoninput["mmlcommand"], parentid=jsoninput["parentid"], username=username, resolutioncode=jsoninput["resolutionstatus"], resolutionsummary=jsoninput["resolutionsummary"], rsname=jsoninput["rsname"])
                                self.update_alarmstatus(iactoken=jsoninput["iactoken"], status="Processing")
                                # conn.commit()
                                self.execute_mml_to_rpa(iactoken=jsoninput["iactoken"], parentid=cycleid, resolutioncode=jsoninput['resolutionstatus'], resolutionsummary=jsoninput['resolutionsummary'])
                else:
                    if checkForKeys(jsoninput, ["iactoken"]) is None:
                        self.insert_alarmcycle(iactoken=jsoninput["iactoken"], inputreceived=inputjson, tasktype="Error", message="Invalid JSON from GUI, " + w)
                        self.update_alarmstatus(iactoken=jsoninput["iactoken"], status="Manual-Fail")
                    else:
                        print("Error---------------------------iACToken is missing", jsoninput)
            else:
                print(f"JSON Error ----------- invalid json {jsoninput}")
        except BaseException as e:
            print("Error -------" + str(e))
            print(f"----JSON is  {jsoninput}")
            traceback.print_exc()

            if checkForKeys(jsoninput, ["iactoken"]) is None:
                self.insert_alarmcycle(iactoken=jsoninput["iactoken"], tasktype="Error", inputreceived=self.insert_json(jsoninput={"errordetails": traceback.format_exc()}), message="Exception while parsing JSON from GUI, " + str(e))
                self.update_alarmstatus(iactoken=jsoninput["iactoken"], status="Manual-Fail")
            # logging here

    def process_gui_execute_command(self, beforeexecute=0, reattempt=0, iactoken=None, parentid=None, resolutioncode=None, mmlcommand=None, resolutionsummary=None, commandname=None):
        if beforeexecute == 0 and reattempt == 0:
            self.execute_mml_to_rpa(iactoken=iactoken, parentid=parentid, mmlcommand=mmlcommand, resolutioncode=resolutioncode, resolutionsummary=resolutionsummary, commandname=commandname)
        else:
            if self.check_previous_command(currentcmd=str(commandname), iactoken=iactoken):
                cid = self.insert_alarmcycle(iactoken=iactoken, tasktype="Status Message", resolutioncode=resolutioncode, parentid=parentid, mmlcommand=mmlcommand, resolutionsummary=resolutionsummary, commandname=commandname, message="Waiting for execution")
                if reattempt == 0:
                    self.insert_waitingcommands(iactoken=iactoken, parentid=cid, mmlcommand=mmlcommand, commandname=commandname, executiontime=beforeexecute, type="Re")
                else:
                    self.insert_waitingcommands(iactoken=iactoken, parentid=cid, mmlcommand=mmlcommand, commandname=commandname, executiontime=reattempt, type="Re")
            else:
                if beforeexecute == 0:
                    self.execute_mml_to_rpa(iactoken=iactoken, parentid=parentid, mmlcommand=mmlcommand, resolutioncode="0", resolutionsummary=resolutionsummary, commandname=commandname)
                else:
                    cid = self.insert_alarmcycle(iactoken=iactoken, tasktype="Status Message", resolutioncode=resolutioncode, parentid=parentid, mmlcommand=mmlcommand, resolutionsummary=resolutionsummary, commandname=commandname, message="Waiting for execution")
                    self.insert_waitingcommands(iactoken=iactoken, parentid=cid, mmlcommand=mmlcommand, commandname=commandname, executiontime=beforeexecute, type="Be")

    def process_mml_from_gui(self, jsoninput, username=None):
        inputjson = None
        try:
            if validate_json(jsoninput):
                inputjson = self.insert_json(jsoninput=jsoninput)
                guioutput = pd.Series(jsoninput, index=['iactoken', 'mmlcommand', 'parentid', 'rsname', 'tasktype', 'commandname', 'resolutionstatus', 'resolutionsummary'])
                guioutput.replace({np.nan: None}, inplace=True)
                guioutput = guioutput.to_dict()
                w = checkForValues(guioutput, ['iactoken', 'tasktype', 'resolutionstatus'], None)
                if w is None:
                    with self.connection as conn:
                        with conn.cursor() as cur:
                            rescode = str(guioutput['resolutionstatus'])
                            if rescode == "0":
                                x = checkForValues(guioutput, ["mmlcommand"], None)
                                if x is None:
                                    self.update_alarmstatus(iactoken=guioutput["iactoken"], status="Processing")
                                    if guioutput['tasktype'] == "User accepted MML":
                                        cur.execute("select iactoken,mmlcommand,id as parentid,resolutioncode, resolutionsummary,commandname,rsname from alarmcycle where id=" + str(guioutput["parentid"]))
                                        res = cur.fetchone()
                                        r = self.get_command_details(commandname=res[5])
                                        cycleid = self.insert_alarmcycle(iactoken=guioutput["iactoken"], tasktype="User accepted MML", parentid=res[2], resolutioncode=res[3], inputreceived=inputjson, mmlcommand=res[1], resolutionsummary=res[4], commandname=res[5], username=username, rsname=res[6])
                                        self.process_gui_execute_command(beforeexecute=r[1], reattempt=r[2], iactoken=guioutput["iactoken"], parentid=cycleid, resolutioncode=str(res[3]), mmlcommand=res[1], resolutionsummary=res[4], commandname=res[5])
                                    else:
                                        r = self.get_command_details(commandname=guioutput["commandname"])
                                        cycleid = self.insert_alarmcycle(iactoken=guioutput["iactoken"], tasktype="User updated MML", inputreceived=inputjson, mmlcommand=guioutput["mmlcommand"], parentid=guioutput["parentid"], username=username, resolutioncode=guioutput["resolutionstatus"], resolutionsummary=guioutput["resolutionsummary"], commandname=guioutput["commandname"], rsname=guioutput["rsname"])
                                        self.process_gui_execute_command(beforeexecute=r[1], reattempt=r[2], iactoken=guioutput["iactoken"], parentid=cycleid, resolutioncode=str(guioutput["resolutionstatus"]), mmlcommand=guioutput["mmlcommand"], resolutionsummary=guioutput["resolutionsummary"], commandname=guioutput["commandname"])
                                else:
                                    settings.logger.error(f"Invalid JSON from GUI,{w}")
                                    self.insert_alarmcycle(iactoken=guioutput["iactoken"], inputreceived=inputjson, tasktype="Error", message="Invalid JSON from GUI, " + x)
                                    self.update_alarmstatus(iactoken=guioutput["iactoken"], status="Manual-Fail")
                            elif rescode == "1":
                                x = checkForValues(guioutput, ["resolutionsummary", "rsname"], None)
                                if x is None:
                                    cycleid = self.insert_alarmcycle(iactoken=guioutput["iactoken"], tasktype="Cycle End", inputreceived=inputjson, parentid=guioutput["parentid"], username=username, resolutioncode=guioutput["resolutionstatus"], resolutionsummary=guioutput["resolutionsummary"], rsname=guioutput["rsname"])
                                    self.update_alarmstatus(iactoken=guioutput["iactoken"], status="Processing")
                                    self.execute_mml_to_rpa(iactoken=guioutput["iactoken"], parentid=cycleid, resolutioncode=str(guioutput["resolutionstatus"]), resolutionsummary=guioutput["resolutionsummary"])
                                else:
                                    settings.logger.error(f"Invalid JSON from GUI,{w}")
                                    self.insert_alarmcycle(iactoken=guioutput["iactoken"], inputreceived=inputjson, tasktype="Error", message="Invalid JSON from GUI, " + x)
                                    self.update_alarmstatus(iactoken=guioutput["iactoken"], status="Manual-Fail")

                            elif rescode == "7":
                                x = checkForValues(guioutput, ["mmlcommand"], None)

                                cycleid = self.insert_alarmcycle(iactoken=guioutput["iactoken"], tasktype="User Update", inputreceived=inputjson, mmlcommand=guioutput["mmlcommand"], parentid=guioutput["parentid"], username=username, resolutioncode=guioutput["resolutionstatus"], resolutionsummary=guioutput["resolutionsummary"], rsname=guioutput["rsname"], commandname=guioutput["commandname"])
                                if x is None:
                                    self.update_alarmstatus(iactoken=guioutput["iactoken"], status="Processing")
                                    self.execute_mml_to_rpa(iactoken=guioutput["iactoken"], parentid=cycleid, commandname=guioutput["commandname"], mmlcommand=guioutput["mmlcommand"], resolutioncode=guioutput['resolutionstatus'], resolutionsummary=guioutput['resolutionsummary'])
                                else:
                                    settings.logger.error(f"Invalid JSON from GUI,{w}")
                                    self.insert_alarmcycle(iactoken=guioutput["iactoken"], parentid=cycleid, inputreceived=inputjson, tasktype="Error", message="Invalid JSON from GUI, " + x)
                                    self.update_alarmstatus(iactoken=guioutput["iactoken"], status="Manual-Fail")
                            elif rescode == "11" or rescode == "12":
                                cycleid = self.insert_alarmcycle(iactoken=guioutput["iactoken"], tasktype="User Update", inputreceived=inputjson, mmlcommand=guioutput["mmlcommand"], parentid=guioutput["parentid"], username=username, resolutioncode=guioutput["resolutionstatus"], resolutionsummary=guioutput["resolutionsummary"], rsname=guioutput["rsname"])
                                if rescode == "11":
                                    self.update_alarmstatus(iactoken=guioutput["iactoken"], status="Processing")
                                self.execute_mml_to_rpa(iactoken=guioutput["iactoken"], parentid=cycleid, commandname=guioutput["commandname"], mmlcommand=guioutput["mmlcommand"], resolutioncode=guioutput['resolutionstatus'], resolutionsummary=guioutput['resolutionsummary'])
                            else:
                                cycleid = self.insert_alarmcycle(iactoken=guioutput["iactoken"], tasktype="User Update", inputreceived=inputjson, mmlcommand=guioutput["mmlcommand"], parentid=guioutput["parentid"], username=username, resolutioncode=guioutput["resolutionstatus"], resolutionsummary=guioutput["resolutionsummary"], rsname=guioutput["rsname"])
                                self.insert_alarmcycle(iactoken=guioutput["iactoken"], tasktype="Cycle End", inputreceived=inputjson, mmlcommand=guioutput["mmlcommand"], username=username, resolutioncode=guioutput["resolutionstatus"], resolutionsummary=guioutput["resolutionsummary"], rsname=guioutput["rsname"])
                                self.update_alarmstatus(iactoken=guioutput["iactoken"], status="Processing")
                                self.execute_mml_to_rpa(iactoken=guioutput["iactoken"], parentid=cycleid, resolutioncode=guioutput['resolutionstatus'], resolutionsummary=guioutput['resolutionsummary'])
                else:
                    if checkForKeys(guioutput, ["iactoken"]) is None:
                        settings.logger.error(f"Invalid JSON from GUI,{w}")
                        self.insert_alarmcycle(iactoken=guioutput["iactoken"], inputreceived=inputjson, tasktype="Error", message="Invalid JSON from GUI, " + w)
                        self.update_alarmstatus(iactoken=guioutput["iactoken"], status="Manual-Fail")
                    else:
                        settings.logger.error(f"Error JSON from GUI, iACToken is missing json:{jsoninput}")
            else:
                settings.logger.error(f"Invalid JSON from GUI, json:{jsoninput}")
                print(f"JSON Error ----------- invalid json {jsoninput}")
        except BaseException as e:
            settings.logger.error(f"Exception while parsing JSON from GUI,{traceback.format_exc()}")
            self.insert_alarmcycle(iactoken=jsoninput["iactoken"], tasktype="Error", inputreceived=self.insert_json(jsoninput={"errordetails": traceback.format_exc()}), message="Exception while parsing JSON from GUI, " + str(e))
            self.update_alarmstatus(iactoken=jsoninput["iactoken"], status="Manual-Fail")

    def execute_mml_to_rpa(self, iactoken=None, parentid=None, resolutioncode=None, resolutionsummary=None, mmlcommand=None, commandname=None, rsname=None):
        try:
            print("Sending json to RPA ...", datetime.datetime.now())
            mmlexcid = self.insert_alarmcycle(iactoken=iactoken, tasktype="MML to Execution", resolutioncode=resolutioncode, resolutionsummary=resolutionsummary, parentid=parentid, mmlcommand=mmlcommand, commandname=commandname, rsname=rsname)
            jsoninput = {"robotuid": iactoken, "mmlcommandID": mmlexcid, "mmlcommand": mmlcommand, "resolutioncode": resolutioncode, "resolutionsummary": resolutionsummary}
            jsonid = self.insert_json(jsoninput)
            with self.connection as conn:
                with conn.cursor() as cur:
                    cur.execute("update alarmcycle set inputreceived={} where id={}".format(jsonid, mmlexcid))
                    conn.commit()
                    try:
                        r = requests.post(settings.RPA_MML_URL, headers={"Authorization": settings.RPA_TOKEN, "Content-type": "application/json"}, json=jsoninput, proxies=settings.NO_PROXY)
                        if r.status_code == 401:
                            s = settings.refresh_rpa_token()
                            if s:
                                r = requests.post(settings.RPA_MML_URL, headers={"Authorization": settings.RPA_TOKEN, "Content-type": "application/json"}, json=jsoninput, proxies=settings.NO_PROXY)
                                if r.status_code == 200:
                                    self.update_message(message="Sending to RPA success", cycleid=mmlexcid)
                                elif r.status_code == 401:
                                    self.insert_alarmcycle(iactoken, tasktype="Error", parentid=mmlexcid, resolutioncode=resolutioncode, inputreceived=jsonid, resolutionsummary=resolutionsummary, mmlcommand=mmlcommand, commandname=commandname, message="Failed to connect RPA while Token refresh")
                                    self.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")
                                else:
                                    self.insert_alarmcycle(iactoken, tasktype="Error", parentid=mmlexcid, resolutioncode=resolutioncode, inputreceived=jsonid, resolutionsummary=resolutionsummary, mmlcommand=mmlcommand, commandname=commandname, message="Failed to send MML to RPA")
                                    self.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")
                        elif r.status_code == 200:
                            self.update_message(message="Sending to RPA success", cycleid=mmlexcid)
                        else:
                            self.insert_alarmcycle(iactoken, tasktype="Error", parentid=mmlexcid, resolutioncode=resolutioncode, inputreceived=jsonid, resolutionsummary=resolutionsummary, mmlcommand=mmlcommand, commandname=commandname, message="Failed to send MML to RPA")
                            self.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")
                    except requests.exceptions.RequestException as e:
                        self.insert_alarmcycle(iactoken, tasktype="Error", parentid=mmlexcid, resolutioncode=resolutioncode, inputreceived=jsonid, resolutionsummary=resolutionsummary, mmlcommand=mmlcommand, commandname=commandname, message="Failed to send MML to RPA")
                        self.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")

        except BaseException as e:
            print("Error -------" + str(e))
            print(f"----JSON is  {jsoninput}")
            traceback.print_exc()
            if iactoken is not None:
                self.insert_alarmcycle(iactoken, tasktype="Error", inputreceived=self.insert_json(jsoninput={"errordetails": traceback.format_exc()}), message="Error while sending mml to RPA, " + str(e))
                self.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")
        print("Sending json to RPA ...Completed ", datetime.datetime.now())

    def update_km(self, alarm=None, username=None):
        try:
            print("Sending json to KM...")
            jsoninput = {"mode": "operational", "iacTokenID": [alarm["iactoken"]]}
            jsonid = self.insert_json(jsoninput)
            cycleid = self.insert_alarmcycle(iactoken=alarm["iactoken"], tasktype="Update Knowledge Manager", inputreceived=jsonid, username=username)
            r = requests.post(settings.KM_URL, json=jsoninput, proxies=settings.NO_PROXY)
            if r.status_code == 200:
                self.update_message(message="Sending to KM success", cycleid=cycleid)
                print("Sending to KM success")
            else:
                self.insert_alarmcycle(iactoken=alarm["iactoken"], tasktype="Error", inputreceived=self.insert_json(jsoninput={"errordetails": r.content}), message="Sending to KM failed")
                self.update_alarmstatus(iactoken=alarm["iactoken"], status="Manual-Fail")
                print("Sending to KM failed: {}".format(r.content))
        except BaseException as e:
            print("Error -------" + str(e))
            print(f"----JSON is  {alarm}")
            traceback.print_exc()
            if checkForKeys(alarm, ["iactoken"]) is None:
                self.insert_alarmcycle(alarm["iactoken"], tasktype="Error", inputreceived=self.insert_json(jsoninput={"errordetails": traceback.format_exc()}), message="Error while updating KM, " + str(e))
                self.update_alarmstatus(iactoken=alarm["iactoken"], status="Manual-Fail")

    def send_mmloutput_to_ps(self, iactoken):
        try:
            alarm_dao = AlarmInfoDataAccess()
            # Do not submit to PS if cycle end
            if alarm_dao.is_alarm_cycle_end(iactoken):
                return

            print(f"Enter: Sending MML to PS: {iactoken} ")
            alarmjson = AlarmHandler().generate_alarmjson2(iactoken)
            jsonid = self.insert_json(alarmjson)
            cycleid = self.insert_alarmcycle(iactoken=iactoken, tasktype="Output to Predictive Service", inputreceived=jsonid)
            r = requests.post(settings.PREDICT_URL, json=alarmjson, proxies=settings.NO_PROXY)
            if r.status_code == 200:
                self.update_message(message="Sending to PS success", cycleid=cycleid)
                print("..........Sent to PS Success")
                return "Success"
            else:

                self.insert_alarmcycle(iactoken=iactoken, tasktype="Error", inputreceived=self.insert_json(jsoninput={"errordetails": r.content}), message="Sending to PS failed")
                self.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")
                print(f"..........Sent to PS Failed: {iactoken}")
                return "Failed"
        except BaseException as e:
            print("Error -------" + str(e))
            print(f"----iACToken is  {iactoken}")
            traceback.print_exc()
            if iactoken is not None:
                self.insert_alarmcycle(iactoken, tasktype="Error", inputreceived=self.insert_json(jsoninput={"errordetails": traceback.format_exc()}), message="Error while sending MML Output to PS, " + str(e))
                self.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")
        finally:
            print(f"Exit: Sending MML to PS: {iactoken}")

    def get_command(self, id=None):
        try:
            if id is not None:
                with self.connection:
                    with self.connection.cursor() as cur:
                        cur.execute("select mmlcommand from alarmcycle where id={}".format(id))
                        return cur.fetchone()[0]
            else:
                return None
        except BaseException as e:
            print("Error ---------  " + str(e))
            traceback.print_exc()
            return None

    def get_commandname(self, id=None):
        try:
            if id is not None:
                with self.connection:
                    with self.connection.cursor() as cur:
                        cur.execute("select commandname from alarmcycle where id={}".format(id))
                        return cur.fetchone()[0]
            else:
                return None
        except BaseException as e:
            print("Error ---------  " + str(e))
            traceback.print_exc()
            return None

    def process_mmloutput_from_rpa(self, jsoninput):
        jsonid = None
        try:
            if validate_json(jsoninput):
                jsonid = self.insert_json(jsoninput)
                rpaoutput = pd.Series(jsoninput, index=['robotUID', 'mmlcommand', 'mmlcommandoutput', 'mmlcommandID', 'responsecode', 'status', 'exceptiondetail'])
                rpaoutput.replace({np.nan: None}, inplace=True)
                v = checkForKeys(rpaoutput, ['robotUID', 'responsecode', 'status'])
                w = checkForValues(rpaoutput, ['robotUID', 'responsecode', 'status'], v)
                alarm_dao = AlarmInfoDataAccess()
                alarm_info = alarm_dao.get_alarminfo(iactoken=rpaoutput["robotUID"])
                ticket_id = alarm_info['ticketid']

                if v is None and w is None:
                    if rpaoutput['responsecode'] == "0":
                        if rpaoutput["status"] == "0":
                            error_message = 'RPA Error - ' + rpaoutput.get('exceptiondetail','Verify Logs')
                            cycleid = self.insert_alarmcycle(iactoken=rpaoutput["robotUID"], tasktype="Status Message",
                                                             resolutioncode=rpaoutput["responsecode"],
                                                             inputreceived=jsonid,
                                                             mmloutput=rpaoutput["mmlcommandoutput"],
                                                             message=error_message,
                                                             mmlcommand=rpaoutput["mmlcommand"],
                                                             parentid=rpaoutput["mmlcommandID"],
                                                             commandname=self.get_commandname(
                                                                 id=rpaoutput["mmlcommandID"]))
                            self.update_alarmstatus(iactoken=rpaoutput["robotUID"], status="Manual-Fail")
                        else:
                            if rpaoutput["mmlcommandoutput"] is None:
                                cycleid = self.insert_alarmcycle(iactoken=rpaoutput["robotUID"], tasktype="Status Message", resolutioncode=rpaoutput["responsecode"], inputreceived=jsonid, mmloutput=rpaoutput["mmlcommandoutput"], message=rpaoutput["exceptiondetail"], mmlcommand=rpaoutput["mmlcommand"], parentid=rpaoutput["mmlcommandID"], commandname=self.get_commandname(id=rpaoutput["mmlcommandID"]))
                                self.update_alarmstatus(iactoken=rpaoutput["robotUID"], status="Manual-Fail")
                                self.insert_alarmcycle(iactoken=rpaoutput["robotUID"], inputreceived=jsonid, parentid=cycleid, tasktype="Error", message="MML Output is empty")
                            else:
                                cycleid = self.insert_alarmcycle(iactoken=rpaoutput["robotUID"], tasktype="MML Output", resolutioncode=rpaoutput["responsecode"], inputreceived=jsonid, mmloutput=rpaoutput["mmlcommandoutput"], message=rpaoutput["exceptiondetail"], mmlcommand=rpaoutput["mmlcommand"], parentid=rpaoutput["mmlcommandID"], commandname=self.get_commandname(id=rpaoutput["mmlcommandID"]))
                                self.update_alarmstatus(iactoken=rpaoutput["robotUID"], status="Processing")
                                # self.process_mmloutput(jsoninput)
                                self.send_mmloutput_to_ps(rpaoutput['robotUID'])
                    elif rpaoutput['responsecode'] == "1":
                        cycleid = self.insert_alarmcycle(iactoken=rpaoutput["robotUID"], tasktype="Status Message", resolutioncode=rpaoutput["responsecode"], inputreceived=jsonid, mmloutput=rpaoutput["mmlcommandoutput"], message=rpaoutput["exceptiondetail"], mmlcommand=rpaoutput["mmlcommand"], parentid=rpaoutput["mmlcommandID"], commandname=self.get_commandname(id=rpaoutput["mmlcommandID"]))
                        if rpaoutput["status"] == "0":
                            self.update_alarmstatus(iactoken=rpaoutput["robotUID"], status="Manual-Fail")
                            self.insert_alarmcycle(iactoken=rpaoutput["robotUID"], inputreceived=jsonid, parentid=cycleid, tasktype="Error", message=rpaoutput["exceptiondetail"])
                        else:
                            self.update_alarmstatus(iactoken=rpaoutput["robotUID"], status="Resolved")

                            if alarm_dao.is_alarms_resolved_for_ticket(ticket_id):
                                self.update_ticketstatus(ticket_id, status="Resolved")
                                if alarm_info['nodegroup'] == 'NSS' and alarm_info['executionmode'] == 'Auto':
                                    close_ticket_input = {"ticketid": ticket_id, "resolutionstatus": 55,
                                                          "resolutionsummary": ''}
                                    self.close_ticket(close_ticket_input)
                                elif alarm_info['executionmode'] == 'Auto':
                                    self.update_ticketmessage(message='Ticket auto closure not enabled for BSS',
                                                              ticketid=ticket_id)
                            elif alarm_dao.is_alarms_operation_complete_for_ticket(ticket_id):
                                self.update_ticketstatus(ticket_id, status="iAC Operation Complete")
                                if alarm_info['nodegroup'] == 'NSS' and alarm_info['executionmode'] == 'Auto':
                                    attach_log_input = {"ticketid": ticket_id, "resolutionstatus": 12,
                                                        "resolutionsummary": ''}
                                    self.attach_log_ticket(attach_log_input)
                                elif alarm_info['executionmode'] == 'Auto':
                                    self.update_ticketmessage(message='Auto Attach log not enabled for BSS',
                                                              ticketid=ticket_id)
                    elif rpaoutput['responsecode'] == "7":
                        if rpaoutput["status"] == "0":
                            cycleid = self.insert_alarmcycle(iactoken=rpaoutput["robotUID"], tasktype="MML Output",
                                                             resolutioncode=rpaoutput["responsecode"],
                                                             inputreceived=jsonid,
                                                             mmloutput=rpaoutput["mmlcommandoutput"],
                                                             message=rpaoutput["exceptiondetail"],
                                                             mmlcommand=self.get_command(
                                                                 id=rpaoutput["mmlcommandID"]),
                                                             parentid=rpaoutput["mmlcommandID"],
                                                             commandname=self.get_commandname(
                                                                 id=rpaoutput["mmlcommandID"]))
                            # self.update_alarmstatus(iactoken=rpaoutput["robotUID"], status="Manual-Fail")
                            self.update_alarmstatus(iactoken=rpaoutput["robotUID"], status="Processing")
                            self.send_mmloutput_to_ps(rpaoutput['robotUID'])
                        elif rpaoutput["status"] == "2":
                            cycleid = self.insert_alarmcycle(iactoken=rpaoutput["robotUID"], tasktype="Status Message", resolutioncode=rpaoutput["responsecode"], inputreceived=jsonid, message=rpaoutput["mmlcommandoutput"], mmlcommand=rpaoutput["mmlcommand"], parentid=None, commandname=self.get_commandname(id=rpaoutput["mmlcommandID"]))
                        else:
                            if rpaoutput["mmlcommandoutput"] is None:
                                cycleid = self.insert_alarmcycle(iactoken=rpaoutput["robotUID"], tasktype="Status Message", resolutioncode=rpaoutput["responsecode"], inputreceived=jsonid, mmloutput=rpaoutput["mmlcommandoutput"], message=rpaoutput["exceptiondetail"], mmlcommand=rpaoutput["mmlcommand"], parentid=rpaoutput["mmlcommandID"], commandname=self.get_commandname(id=rpaoutput["mmlcommandID"]))
                                self.update_alarmstatus(iactoken=rpaoutput["robotUID"], status="Manual-Fail")
                                self.insert_alarmcycle(iactoken=rpaoutput["robotUID"], inputreceived=jsonid, parentid=cycleid, tasktype="Error", message="MML Output is empty")
                            else:
                                cycleid = self.insert_alarmcycle(iactoken=rpaoutput["robotUID"], tasktype="MML Output", resolutioncode=rpaoutput["responsecode"], inputreceived=jsonid, mmloutput=rpaoutput["mmlcommandoutput"], message=rpaoutput["exceptiondetail"], mmlcommand=rpaoutput["mmlcommand"], parentid=rpaoutput["mmlcommandID"], commandname=self.get_commandname(id=rpaoutput["mmlcommandID"]))
                                self.update_alarmstatus(iactoken=rpaoutput["robotUID"], status="Processing")
                                # self.process_mmloutput(jsoninput)
                                self.send_mmloutput_to_ps(rpaoutput['robotUID'])
                    else:
                        cycleid = self.insert_alarmcycle(iactoken=rpaoutput["robotUID"], tasktype="Status Message",
                                                         resolutioncode=rpaoutput["responsecode"], inputreceived=jsonid,
                                                         mmloutput=rpaoutput["mmlcommandoutput"],
                                                         message=rpaoutput["exceptiondetail"],
                                                         mmlcommand=rpaoutput["mmlcommand"],
                                                         parentid=rpaoutput["mmlcommandID"],
                                                         commandname=self.get_commandname(id=rpaoutput["mmlcommandID"]))
                        # self.process_mmloutput(jsoninput)
                        if rpaoutput["status"] == "0":
                            self.update_alarmstatus(iactoken=rpaoutput["robotUID"], status="Manual-Fail",
                                                    message=(self.get_resolution_status(rpaoutput['responsecode']) +
                                                             ' Failed'))
                        elif rpaoutput["status"] == "2":
                            self.update_alarmstatus(iactoken=rpaoutput["robotUID"], status="Processing",
                                                    message=(self.get_resolution_status(rpaoutput['responsecode']) +
                                                             ' In Process'))
                        else:
                            # TODO change the status and add message field
                            if rpaoutput['responsecode'] == 7:
                                self.update_alarmstatus(iactoken=rpaoutput["robotUID"], status="iAC Operation Complete",
                                                        message=(self.get_resolution_status(rpaoutput['responsecode'])))
                            else:
                                self.update_alarmstatus(iactoken=rpaoutput["robotUID"], status="iAC Operation Complete",
                                                        message=(self.get_resolution_status(rpaoutput['responsecode']) +
                                                                 ' Complete'))
                            if alarm_dao.is_alarms_operation_complete_for_ticket(ticket_id):
                                self.update_ticketstatus(ticket_id, status="iAC Operation Complete")
                                if alarm_info['executionmode'] == 'Auto':
                                    attach_log_input = {"ticketid": ticket_id, "resolutionstatus": 12,
                                                        "resolutionsummary": ''}
                                    self.attach_log_ticket(attach_log_input)
                else:
                    if checkForKeys(rpaoutput, ["robotUID"]) is None:
                        settings.logger.error(f"Invalid JSON from RPA, {w}, iactoken: {rpaoutput['robotUID']} ")
                        self.insert_alarmcycle(iactoken=rpaoutput["robotUID"], inputreceived=jsonid, tasktype="Error", message="Invalid JSON from RPA, " + w)
                        self.update_alarmstatus(iactoken=rpaoutput["robotUID"], status="Manual-Fail")
                    else:
                        settings.logger.error(f"robotUID is missing in RPA Output : {jsoninput}")
            else:
                print(f"JSON Error ----------- invalid json {jsoninput}")
        except BaseException as e:
            settings.logger.error(traceback.format_exc())
            settings.logger.error(jsoninput)
            if checkForKeys(jsoninput, ["robotUID"]) is None:
                self.insert_alarmcycle(jsoninput["robotUID"], tasktype="Error", inputreceived=self.insert_json(jsoninput={"errordetails": traceback.format_exc()}), message="Error while parsing MML Output, " + str(e))
                self.update_alarmstatus(iactoken=jsoninput["robotUID"], status="Manual-Fail")
            else:
                print("Error---------------------------robotUID is missing", jsoninput)
        self.process_mmloutput(jsoninput)

    # Method updated the ticket details table when RPA sends ticket acknowledge
    def update_ticketacknowledge(self, jsoninput):
        print("Started update_ticketacknowledge")
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    cur.execute("update ticketdetails set acktime= '{}',acknowledge=true,status={},message='{}',"
                                "updatedtime=now() "
                                "where ticketid='{}'"
                                .format(jsoninput['acknowledgedTime'], jsoninput['status'], jsoninput['exceptiondetail'],
                                        jsoninput['ticketID']))
                    return True

        except:
            iac1_resp = {}
            err = f"Exception while processing ticketacknowledge form RPA"
            print(f"{err} {traceback.format_exc()}")
            return False
        print("Completed update_ticketacknowledge {}".format(jsoninput['ticketID']))
