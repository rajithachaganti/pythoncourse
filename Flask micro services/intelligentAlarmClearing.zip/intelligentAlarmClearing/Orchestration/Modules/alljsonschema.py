ps_os={
  "definitions": {},
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "http://example.com/root.json",
  "type": "object",
  "title": "The Root Schema",
  "required": [
    "iACToken",
    "ParserOutput",
    "PredictorOutput",
    "SubstitutorOutput"
  ],
  "properties": {
    "iACToken": {
      "$id": "#/properties/iACToken",
      "type": "string",
      "title": "The Iactoken Schema",
      "pattern": "^(.*)$"
    },
    "ParserOutput": {
      "$id": "#/properties/ParserOutput",
      "type": "object",
      "title": "The Parseroutput Schema"
    },
    "PredictorOutput": {
      "$id": "#/properties/PredictorOutput",
      "type": "object",
      "title": "The Predictoroutput Schema",
      "required": [
        "debug",
        "traceback",
        "resolutionSummary",
        "resolutionStatus",
        "algorithmResponseInfo",
        "rules",
        "rulesResults",
        "mmlCommand",
        "similarityScore"
      ],
      "properties": {
        "debug": {
          "$id": "#/properties/PredictorOutput/properties/debug",
          "type": "string",
          "title": "The Debug Schema"
        },
        "traceback": {
          "$id": "#/properties/PredictorOutput/properties/traceback",
          "type": "string",
          "title": "The Traceback Schema"
        },
        "resolutionSummary": {
          "$id": "#/properties/PredictorOutput/properties/resolutionSummary",
          "type": "string",
          "title": "The Resolutionsummary Schema"
        },
        "resolutionStatus": {
          "$id": "#/properties/PredictorOutput/properties/resolutionStatus",
          "type": "integer",
          "title": "The Resolutionstatus Schema"

        },
        "algorithmResponseInfo": {
          "$id": "#/properties/PredictorOutput/properties/algorithmResponseInfo",
          "type": "string",
          "title": "The Algorithmresponseinfo Schema"
        },
        "rules": {
          "$id": "#/properties/PredictorOutput/properties/rules",
          "type": "array",
          "title": "The Rules Schema"
        },
        "rulesResults": {
          "$id": "#/properties/PredictorOutput/properties/rulesResults",
          "type": "array",
          "title": "The Rulesresults Schema"
        },
        "mmlCommand": {
          "$id": "#/properties/PredictorOutput/properties/mmlCommand",
          "type": "string",
          "title": "The Mmlcommand Schema",

          "pattern": "^(.*)$"
        },
        "similarityScore": {
          "$id": "#/properties/PredictorOutput/properties/similarityScore",
          "type": "object",
          "title": "The Similarityscore Schema",
          "required": [
            "similarityUI"
          ],
          "properties": {
            "similarityUI": {
              "$id": "#/properties/PredictorOutput/properties/similarityScore/properties/similarityUI",
              "type": "string",
              "title": "The Similarityui Schema"

            }
          }
        }
      }
    },
    "SubstitutorOutput": {
      "$id": "#/properties/SubstitutorOutput",
      "type": "object",
      "title": "The Substitutoroutput Schema",
      "required": [
        "debug",
        "mmlCommand",
        "resolutionStatus"
      ],
      "properties": {
        "debug": {
          "$id": "#/properties/SubstitutorOutput/properties/debug",
          "type": "string",
          "title": "The Debug Schema"

        },
        "mmlCommand": {
          "$id": "#/properties/SubstitutorOutput/properties/mmlCommand",
          "type": "string",
          "title": "The Mmlcommand Schema",
          "pattern": "^(.*)$"
        },
        "resolutionStatus": {
          "$id": "#/properties/SubstitutorOutput/properties/resolutionStatus",
          "type": "integer",
          "title": "The Resolutionstatus Schema"
        }
      }
    }
  }
}
rpa_os={
  "definitions": {},
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "http://example.com/root.json",
  "type": "object",
  "title": "The Root Schema",
  "required": [
    "Robot UID",
    "Command ID",
    "Command",
    "Response Code",
    "Command Output",
    "Status",
    "Exception detail"
  ],
  "properties": {
    "Robot UID": {
      "$id": "#/properties/Robot UID",
      "type": "string",
      "title": "The Robot uid Schema",
      "pattern": "^(.*)$"
    },
    "Command ID": {
      "$id": "#/properties/Command ID",
      "type": "string",
      "title": "The Command id Schema",
      "pattern": "^(.*)$"
    },
    "Command": {
      "$id": "#/properties/Command",
      "type": "string",
      "title": "The Command Schema",
      "default": "",
      "examples": [
        "ZEEI:BCF=790;"
      ],
      "pattern": "^(.*)$"
    },
    "Response Code": {
      "$id": "#/properties/Response Code",
      "type": "string",
      "title": "The Response code Schema",
      "default": "",
      "examples": [
        "0"
      ],
      "pattern": "^(.*)$"
    },
    "Command Output": {
      "$id": "#/properties/Command Output",
      "type": "string",
      "title": "The Command output Schema",
      "default": "",
      "examples": [
        "hgf<"
      ],
      "pattern": "^(.*)$"
    },
    "Status": {
      "$id": "#/properties/Status",
      "type": "string",
      "title": "The Status Schema",
      "default": "",
      "examples": [
        "1"
      ],
      "pattern": "^(.*)$"
    },
    "Exception detail": {
      "$id": "#/properties/Exception detail",
      "type": "string",
      "title": "The Exception detail Schema",
      "default": "",
      "examples": [
        ""
      ],
      "pattern": "^(.*)$"
    }
  }
}
gui_os={
  "definitions": {},
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "http://example.com/root.json",
  "type": "object",
  "title": "The Root Schema",
  "required": [
    "iactoken",
    "mmlcommand",
    "parentid",
    "tasktype",
    "username",
    "message",
    "resolutionstatus",
    "resolutionsummary"
  ],
  "properties": {
    "iactoken": {
      "$id": "#/properties/iactoken",
      "type": "string",
      "title": "The Iactoken Schema",
      "default": "",
      "examples": [
        "1234234-456"
      ],
      "pattern": "^(.*)$"
    },
    "mmlcommand": {
      "$id": "#/properties/mmlcommand",
      "type": "string",
      "title": "The Mmlcommand Schema",
      "default": "",
      "examples": [
        "ZEOL::NR=7767;"
      ],
      "pattern": "^(.*)$"
    },
    "parentid": {
      "$id": "#/properties/parentid",
      "type": "string",
      "title": "The Parentid Schema",
      "default": "",
      "examples": [
        "246"
      ],
      "pattern": "^(.*)$"
    },
    "tasktype": {
      "$id": "#/properties/tasktype",
      "type": "string",
      "title": "The Tasktype Schema",
      "default": "",
      "examples": [
        "User updated MML"
      ],
      "pattern": "^(.*)$"
    },
    "username": {
      "$id": "#/properties/username",
      "type": "string",
      "title": "The Username Schema",
      "default": "",
      "examples": [
        "arun"
      ],
      "pattern": "^(.*)$"
    },
    "message": {
      "$id": "#/properties/message",
      "type": "string",
      "title": "The Message Schema",
      "default": "",
      "examples": [
        "eres"
      ],
      "pattern": "^(.*)$"
    },
    "resolutionstatus": {
      "$id": "#/properties/resolutionstatus",
      "type": "integer",
      "title": "The Resolutionstatus Schema",
      "default": 0,
      "examples": [
        1
      ]
    },
    "resolutionsummary": {
      "$id": "#/properties/resolutionsummary",
      "type": "string",
      "title": "The Resolutionsummary Schema",
      "default": "",
      "examples": [
        ""
      ],
      "pattern": "^(.*)$"
    }
  }
}
all_alarm_schema={"Tickets":{
  "definitions": {},
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "http://example.com/root.json",
  "type": "object",
  "title": "Tickets",
  "required": [
    "Tickets"
  ],
  "properties": {
    "Tickets": {
      "$id": "#/properties/Tickets",
      "type": "array",
      "title": "Tickets",
      "minItems": 1
    }
  }
},"Alarms":{
  "definitions": {},
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "http://example.com/root.json",
  "type": "object",
  "title": "Alarms",
  "required": [
    "Alarms"
  ],
  "properties": {
    "Alarms": {
      "$id": "#/properties/Alarms",
      "type": "array",
      "title": "Alarms",
      "minItems": 1
    }
  }
},
"ticketjson":{
  "definitions": {},
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "title": "ticketjson",
  "required": [
    "TicketID",
    "TTSeverity",
    "Country",
    "CreateTime",
    "Title",
    "Alarms"
  ],
  "properties": {
    "TicketID": {
      "type": "string",
      "title": "TicketID",
      "pattern": "^(.*)$"
    },
    "TTSeverity": {
      "type": "string",
      "title": "TTSeverity",
      "pattern": "^(.*)$"
    },
    "Country": {
      "type": "string",
      "title": "Country",
      "pattern": "^(.*)$"
    },
    "CreateTime": {
      "type": "string",
      "title": "CreateTime",
      "pattern": "^(.*)$"
    },
    "Title": {
      "type": "string",
      "title": "Title",
      "pattern": "^(.*)$"
    },
    "Alarms": {
      "type": "array",
      "title": "Alarms",
      "minItems": 1
    }
  }
},
"alarmjson":{
  "definitions": {},
  "$schema": "http://json-schema.org/draft-07/schema#",
  "$id": "http://example.com/root.json",
  "type": "object",
  "title": "alarmjson",
  "required": [
    "additionalInfo",
    "alarmNumber",
    "alarmText",
    "bcfID",
    "customer",
    "eventTime",
    "nodeName",
    "nodeId",
    "nodeType",
    "ParentId",
    "vendorType",
    "NodeInDB"
  ],

  "properties": {
    "additionalInfo": {
      "$id": "#/properties/additionalInfo",
      "type": "string",
      "title": "additionalInfo",
      "pattern": "^(.*)$"
    },
    "alarmNumber": {
      "$id": "#/properties/alarmNumber",
      "type": ["string","null"],
      "title": "alarmNumber"
    },
    "alarmText": {
      "$id": "#/properties/alarmText",
      "type": "string",
      "title": "alarmText",
      "pattern": "^(.*)$"
    },
    "bcfID": {
      "$id": "#/properties/bcfID",
      "type": ["string","null"],
      "title": "bcfID",
      "pattern": "^(.*)$"
    },
    "btsID": {
      "$id": "#/properties/btsID",
      "type": ["string","null"],
      "title": "btsID",
      "pattern": "^(.*)$"
    },
    "countryName": {
      "$id": "#/properties/countryName",
      "type": "string",
      "title": "countryName",
      "pattern": "^(.*)$"
    },
    "customer": {
      "$id": "#/properties/customer",
      "type": "string",
      "title": "customer",
      "pattern": "^(.*)$"
    },
    "eventTime": {
      "$id": "#/properties/eventTime",
      "type": "string",
      "title": "eventTime",
      "pattern": "^(.*)$"
    },
    "fluctuationStatus": {
      "$id": "#/properties/fluctuationStatus",
      "type": ["string","null"],
      "title": "fluctuationStatus",
      "pattern": "^(.*)$"
    },
    "nodeName": {
      "$id": "#/properties/nodeName",
      "type": ["string","null"],
      "title": "nodeName",
      "pattern": "^(.*)$"
    },
    "nodeId": {
      "$id": "#/properties/nodeId",
      "type": ["string","null"],
      "title": "nodeId",
      "pattern": "^(.*)$"
    },
    "nodeType": {
      "$id": "#/properties/nodeType",
      "type": ["string","null"],
      "title": "nodeType",
      "pattern": "^(.*)$"
    },
    "ParentId": {
      "$id": "#/properties/ParentId",
      "type": ["string","null"],
      "title": "ParentId"
    },
    "robotUID": {
      "$id": "#/properties/robotUID",
      "type": ["string","null"],
      "title": "robotUID",
      "pattern": "^(.*)$"
    },
    "trxID": {
      "$id": "#/properties/trxID",
      "type": ["string","null"],
      "title": "trxID"
    },
    "vendorType": {
      "$id": "#/properties/vendorType",
      "type": "string",
      "title": "vendorType",
      "pattern": "^(.*)$"
    },
    "NodeInDB": {
      "$id": "#/properties/NodeInDB",
      "type": "boolean",
      "title": "NodeInDB"
    }
  }
}}