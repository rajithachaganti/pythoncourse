import sys
# from ..models import TicketDetails
from .Utilities import *
from .Commons import *
from .alarmhandler import AlarmHandler
from psycopg2 import DatabaseError
# from django.db.utils import IntegrityError
# from django.db import transaction
import traceback
class TicketHandler:
    def __init__(self):
        self.mandatoryTicketFields = ['TicketID', 'TTSeverity', 'Country', 'CreateTime', 'Title', 'Alarms']
        self.connection=getConnection()
        # self.connection.autocommit=False
    def __del__(self):
        self.connection.close()
    def insert_ticket(self,ticket):
        try:
            with self.connection as conn:
                with conn.cursor() as cur:
                    try:
                        ticket=ticket.replace({'-_-':None})
                        print(ticket)
                        cur.execute("insert into ticketdetails (ticketid,ttseverity,ttcountry,ttcreatetime,tttitle,iactttime,acknowledge) values(%s,%s,%s,%s,%s,now(),%s) on conflict(ticketid) do update set acknowledge=excluded.acknowledge,acktime=now() where ticketdetails.acknowledge=false and excluded.acknowledge=true", (ticket['TicketID'], ticket["TTSeverity"], ticket["Country"], ticket["CreateTime"], ticket["Title"],ticket['Acknowledge']))
                        print('--------inserting ticket')
                        ticket['iacstatus'] = 'Success'
                        ticket['iacerrordetails'] = ''
                    except DatabaseError as e:
                        traceback.print_exc()
                        print(e)
                        if "duplicate key" in e.args[0]:
                            print("sdfgfdsfdf")
                            ticket['iacstatus'] = 'Failed'
                            ticket['iacerrordetails'] = 'Duplicate Ticket'
                        else:
                            ticket['iacstatus'] = 'Failed'
                            ticket['iacerrordetails'] = 'Issue in storing ticket in DB, ' + str(sys.exc_info()[0])
        except BaseException as e:
            traceback.print_exc()
            ticket['iacstatus'] = 'Failed'
            ticket['iacerrordetails'] = 'Issue in storing ticket in DB, ' + str(sys.exc_info()[0])
            print("Error is here line no : "+lineno())
        finally:
            return ticket

    def process_ticket(self,ticketjson=None,inputjson=None):
        insertedAlarmsID = []
        inscopeiactokens=[]
        i=0
        try:
            if isinstance(ticketjson, list):
                for ticket in ticketjson:
                    v = checkForKeys(ticket, self.mandatoryTicketFields)
                    w= checkForValues(ticket,self.mandatoryTicketFields,v)
                    if v is None and w is None:
                        if isinstance(ticket['Alarms'],list):
                            if ticket['Alarms']:
                                with self.connection as conn:
                                    with conn.cursor() as cur:
                                        try:
                                            cur.execute("insert into ticketdetails(ticketid,ttseverity,ttcountry,ttcreatetime,tttitle,iactttime) values(%s,%s,%s,%s,%s,now())",(ticket['TicketID'],ticket["TTSeverity"], ticket["Country"], ticket["CreateTime"], ticket["Title"]))
                                            conn.commit()
                                            ticket['iacstatus'] = 'Success'
                                            ticket['iacerrordetails'] = ''
                                            alarmjson, insertid,inscopeid = AlarmHandler().process_alarm(ticket['Alarms'],ticket['TicketID'],inputjson)
                                            insertedAlarmsID = list(set(insertedAlarmsID + insertid))
                                            inscopeiactokens = list(set(inscopeiactokens + inscopeid))
                                            ticket['Alarms'] = alarmjson
                                            if len(insertid) == 0:
                                                raise AlarmError("Alarms having issues")
                                        except AlarmError as e:
                                            ticket['iacstatus'] = 'Failed'
                                            ticket['iacerrordetails'] = e.message
                                        except DatabaseError as e:
                                            if "duplicate key" in e.args[0]:
                                                print("-------Duplicate Ticket",ticket['TicketID'])
                                                ticket['iacstatus'] = 'Success'
                                                ticket['iacerrordetails'] = 'Duplicate Ticket'
                                                alarmjson, insertid, inscopeid = AlarmHandler().process_alarm(ticket['Alarms'], ticket['TicketID'],inputjson)
                                                insertedAlarmsID = list(set(insertedAlarmsID + insertid))
                                                inscopeiactokens = list(set(inscopeiactokens + inscopeid))
                                                ticket['Alarms'] = alarmjson
                                            else:
                                                print(ticket['TicketID'])
                                                traceback.print_exc()
                                                print("Ticket Rollbacked")
                                                ticket['iacstatus'] = 'Failed'
                                                ticket['iacerrordetails'] = 'Issue in storing ticket in DB, ' + str(sys.exc_info()[0])
                            else:
                                ticket['iacstatus'] = 'Failed'
                                ticket['iacerrordetails'] = "There is no alarms"
                        else:
                            ticket['iacstatus'] = 'Failed'
                            ticket['iacerrordetails'] = "Alarms must contain a list/array of alarms"
                    else:
                        ticket['iacstatus'] = 'Failed'
                        ticket['iacerrordetails'] = w
                    ticketjson[i]=ticket
                    i += 1
            else:
                ticketjson['iacstatus']='Failed'
                ticketjson['iacerrordetails']='The key "Tickets" must contain an array of object'
        except BaseException as e:
            ticketjson['iacstatus'] = 'Failed'
            ticketjson['iacerrordetails'] = str(e)
        return ticketjson,insertedAlarmsID,inscopeiactokens
