from Modules.Imports import *

class Logicservices(object):
	def on_get(self,req,resp,**kwargs):
		try:
			route_path = str(req.path)
			if isRoute(route_path,"/gui_services/api/getservice"):
					query = "select filtername as fname from alarmfilter where username='Siva'"
					connectFetchJSON(query,'',resp)
			elif isRoute(route_path,"/gui_services/api/alarms_filter_view"):
					token = req.get_header('token')
					query = "select username as uname from token where token='"+token+"'"
					uname = connectNativeArray(query)
					query = "select filtername as fname from alarmfilter where username='"+uname[0]+"'"
					connectFetchJSON(query,'',resp)
			elif isRoute(route_path,"/gui_services/api/galarm_column"):
					token = req.get_header('token')
					query = "select user_id from token a left join users b on a.username=b.username where a.token='"+token+"'"
					# print(query)
					user_id = connectNativeArray(query)
					# print(user_id)
					# print(user_id[0])

					query = "select user_id,alarminfo_column_det from user_config where user_id="+str(user_id[0])
					# print(query)
					alarm_column_det = connectNativeArray(query)
					connectFetchJSONWihtoutQueryData(query,resp)
			elif isRoute(route_path,"/gui_services/api/get_tickets"):
					token = req.get_header('token')
					query = "select username as uname from token where token='"+token+"'"
					uname = connectNativeArray(query)
					query = "select authorities from authorities where username='"+uname[0]+"'"
					roles = connectNativeArray(query)
					# all get params
					data = {}
					limit = "";
					orderby = " order by ";
					for key, value in req.params.items():
						data[key] = value
					# get the where condition formed
					if("limit" in data and "page" in data):
						limit = "limit "+str(data["limit"])+" offset "+str((int(data['page'])-1)*int(data["limit"]));
					if("sort" in data and "order" in data):
						orderby += getTicketColumnKey(data["sort"])+" "+ data["order"]
					else:
						orderby += "td.iactttime desc"
					cprint(roles)
					wherecondition = ""
					# if "ROLE_IAC_NSS" in roles:
					# 	wherecondition = "where nodegroup='NSS'"
					# elif "ROLE_IAC_BSS" in roles:
					# 	wherecondition = "where nodegroup='BSS'"
					filterConditions = "";
					if("filter" in data):
						filterConditions = getTicketFilterQueryCondition(data["filter"])
						# if where condition exist add with add
						if(filterConditions!=""):
							if(wherecondition==""):
								wherecondition = " where "+filterConditions
							else:
								wherecondition += " and "+filterConditions
					else:
						wherecondition = " where "+conditionRemoveClosedTickets()
					query = "select count(*) over() as count, td.ticketid, td.message, tttitle, ttseverity, ttcountry,acknowledge,acktime::text, ttcreatetime::text,iactttime::text,json_agg(distinct ai.scope) as scope,sc.status from ticketdetails td  left join statuscodes sc on td.status=sc.status_id left join alarminfo ai on ai.ticketid=td.ticketid "+str(wherecondition)+" group by td.ticketid, sc.status  "+orderby+" "+limit
					# print(query)
					cprint(query)
					connectFetchJSON(query,'',resp)
			elif isRoute(route_path,"/gui_services/api/get_alarms"):
					token = req.get_header('token')
					query = "select username as uname from token where token='"+token+"'"
					uname = connectNativeArray(query)
					query = "select authorities from authorities where username='"+uname[0]+"'"
					roles = connectNativeArray(query)
					# all get params
					data = {}
					limit = "";
					orderby = " order by ";
					for key, value in req.params.items():
						data[key] = value
					# get the where condition formed
					if("limit" in data and "page" in data):
						limit = "limit "+str(data["limit"])+" offset "+str((int(data['page'])-1)*int(data["limit"]));
					if("sort" in data and "order" in data):
						orderby += getAlarmColumnKey(data["sort"])+" "+ data["order"]
					else:
						orderby += "aa.iac_time desc"
					cprint(roles)
					wherecondition = ""
					if "ROLE_IAC_NSS" in roles:
						wherecondition = "where nodegroup='NSS'"
					elif "ROLE_IAC_BSS" in roles:
						wherecondition = "where nodegroup='BSS'"
					filterConditions = "";

					if ('alarmList' in data):
						alarmFiltered = getAlarmListCondition(data['alarmList']);
						# print(alarmFiltered )
						if(alarmFiltered!=''):
							if (wherecondition == ""):
								wherecondition = " where " + alarmFiltered
							else:
								wherecondition += " and (" + alarmFiltered +") "

					if("filter" in data):
						filterConditions = getAlarmFilterQueryCondition(data["filter"])
						# if where condition exist add with add 
						if(filterConditions!=""):
							if(wherecondition==""):
								wherecondition = " where "+filterConditions
							else:
								wherecondition += " and "+filterConditions
					else:
						if (wherecondition == ""):
							wherecondition = " where "+conditionRemoveClosedAlarms()
						else:
							wherecondition += " and " + conditionRemoveClosedAlarms()
					# conditionRemoveClosedAlarms

					# print(wherecondition);
					# query = "select count(*) OVER() AS count, ROW_NUMBER () OVER (ORDER BY scope) as sid,aa.iactoken,'' as eddel,customer, aa.additionalfields -> 'countryName' as country, aa.additionalinfo, aa.additionalfields, nodevendor,nodetype,nodegroup, nodeversion,alarmnumber,aa.message, alarmname,nodeid,nodename,nodeparent,updatedtime::text, eventtime::text,iac_time::text,scope,s.status,parentalarm,ticketid,iacalarmid,bb.mmlcommand as mml,bb.parentid,'' as acknowledge,executionmode from alarminfo aa left join (SELECT alarmcycle.iactoken,(case when alarmcycle.mmlcommand is null then '' else alarmcycle.mmlcommand end) as mmlcommand,alarmcycle.id as parentid,alarmcycle.tasktime FROM (SELECT iactoken, MAX(tasktime) AS tasktime FROM alarmcycle GROUP BY iactoken) AS latest_orders INNER JOIN alarmcycle ON alarmcycle.iactoken = latest_orders.iactoken AND alarmcycle.tasktime = latest_orders.tasktime) bb on aa.iactoken=bb.iactoken left join statuscodes s on aa.status=s.status_id  "+str(wherecondition)+" "+orderby+" "+limit

					query = "select count(*) over() as count, " \
							"aa.iactoken, customer, aa.additionalfields -> 'countryName' as country, " \
							"aa.additionalinfo, aa.additionalfields, nodevendor, nodetype, nodegroup, nodeversion, " \
							"alarmnumber, aa.message, alarmname, nodeid, nodename, nodeparent, updatedtime::text, " \
							"eventtime::text, iac_time::text, scope, s.status, parentalarm, ticketid, iacalarmid, " \
							"executionmode from alarminfo aa " \
							"left outer join statuscodes s on aa.status = s.status_id "\
							+str(wherecondition)+" "+orderby+" "+limit

					# print(query);
					cprint(query)
					connectFetchJSON(query,'',resp)
			elif isRoute(route_path,"/gui_services/api/delete_alarms_filter"):
					data = {}
					for key, value in req.params.items():
						data[key] = value
					token = req.get_header('token')
					query = "select username as uname from token where token='"+token+"'"
					uname = connectNativeArray(query)
					list = [] #["uname","jvalue","now","fname"]
					cprint(uname[0])
					list.append(uname[0])
					list.append(data['fname'])
					query_data = tuple(list)
					#cprint(query_data)
					query = "delete from alarmfilter where username='"+str(uname[0])+"' and filtername='"+str(data['fname'])+"'"
					# print (query)
					connectFetchJSON(query,'',resp)
			else:
				resp.body=response_wrapper(404,[]) #json.dumps({'error':str(e)})
				resp.status=falcon.HTTP_404
		except Exception as e:
			resp.body=response_wrapper(500,str(e)) #json.dumps({'error':str(e)})
			resp.status=falcon.HTTP_500
			
	def on_post(self,req,resp,**kwargs):
		try:
			print('Hello')
			route_path = str(req.path)
			#cprint(route_path)
			if isRoute(route_path,"/gui_services/api/alarms_filter"):
					token = req.get_header('token')
					query = "select username as uname from token where token='"+token+"'"
					uname = connectNativeArray(query)
					data = json.loads(req.context['data'].decode('utf-8'))
					data['now'] = "now()"
					query = "insert into alarmfilter (username,jsonvalue,modifiedtime,filtername) values(%s,%s,%s,%s);"
					list = [] #["uname","jvalue","now","fname"]
					#cprint(uname[0])
					list.append(uname[0])
					list.append(data['jvalue'])
					list.append(data['now'])
					list.append(data['fname'])
					query_data = tuple(list)
					#cprint(query_data)
					connectFetchJSON(query,query_data,resp)
			elif isRoute(route_path,"/gui_services/api/su_alarm_column"):
					token = req.get_header('token')
					query = "select user_id from token a left join users b on a.username=b.username where a.token='"+token+"'"
					print(query)
					user_id = connectNativeArray(query)
					# print(user_id)
					# print(user_id[0])

					
					query = "select user_id from user_config where user_id="+str(user_id[0])
					# print(query)
					alarm_column_det = connectNativeArray(query)

					
					data = json.loads(req.context['data'].decode('utf-8'))
					data['now'] = "now()"

					list = [] #["uname","jvalue","now","fname"]

					if len(alarm_column_det) > 0:
						query = "update user_config set alarminfo_column_det=%s,modified_at=%s where user_id=%s"
						list.append(json.dumps(data['alarm_column_info']))
						list.append(data['now'])
						list.append(str(user_id[0]))
					else:
						query = "insert into user_config (user_id,alarminfo_column_det,modified_at) values(%s,%s,%s);"
						list.append(str(user_id[0]))
						list.append(json.dumps(data['alarm_column_info']))
						list.append(data['now'])

					query_data = tuple(list)
					cprint(query_data)
					# print(query)
					# print(query_data)
					connectFetchJSON(query,query_data,resp)
			elif isRoute(route_path,"/gui_services/api/testing3"):
					#cprint(route_path)
					#data = json.loads(req.context['data'].decode('utf-8'))
					#data = req.context['request']
					data = json.loads(req.context['data'].decode('utf-8'))
					json_data = data
					resp.body=json.dumps(json_data)
					resp.status=falcon.HTTP_200
			elif isRoute(route_path,"/gui_services/api/rpa"):
					#cprint(route_path)
					data = json.loads(req.context['data'].decode('utf-8'))
					json_data = data
					resp.body=json.dumps(json_data)
					resp.status=falcon.HTTP_200
			elif isRoute(route_path,"/gui_services/api/predictive"):
					#cprint(route_path)
					data = json.loads(req.context['data'].decode('utf-8'))
					json_data = data
					resp.body=json.dumps(json_data)
					resp.status=falcon.HTTP_200
			elif isRoute(route_path,"/gui_services/api/orches"):
					#cprint(route_path)
					data = json.loads(req.context['data'].decode('utf-8'))
					json_data = FunctionMethos()
					resp.body=json.dumps(json_data)
					resp.status=falcon.HTTP_200
			elif isRoute(route_path,"/gui_services/api/tblconfig"):
					#cprint(route_path)
					data = json.loads(req.context['data'].decode('utf-8'))
					query = "select table_name,dependent_fields,columns,id_column from table_config where id={}".format(data['id'])
					arr  = connectNative(query)
					#cprint(arr)
					table_name = arr[0][0]
					dependent_fields = arr[0][1]
					columns = arr[0][2]
					id_column = arr[0][3]

					# columns = "*"
					lists = []
					for x in dependent_fields:
						dependent_tablename = x["dtablename"]
						dependent_value = x["dcolumn"]
						# columns = x["columns"]
						query = "select distinct "+dependent_value+" from "+dependent_tablename
						cprint(query)
						arrs  = connectNativeArray(query)
						cprint(arrs)
						lists.append({dependent_value:arrs})
				
					query = "select "+columns+" from "+arr[0][0]
					res = connectFetchJSONWihtoutQueryDataNoResponse(query,resp)
					json_data = {'data':res,'idcolumn':id_column,'dependent':lists}
					resp.body = response_wrapper(200,json_data)
					resp.status=falcon.HTTP_200
			elif isRoute(route_path,"/gui_services/api/ctblconfig"):
					cprint(route_path)
					data = json.loads(req.context['data'].decode('utf-8'))
					tble_config_id = data['tblid']
					arrTableData = data['tbldata']
					cprint(tble_config_id)
					cprint(arrTableData)
					query = "select table_name from table_config where id={}".format(tble_config_id)
					cprint(query)
					arrtablename  = connectNativeArray(query)
					cprint(arrtablename)
					cprint(arrtablename[0])
					#query = "select column_name from INFORMATION_SCHEMA.COLUMNS where table_name ='{}'".format(tblarr[0][0])
					#arr  = connectNativeArray(query)
					#cprint(arr)

					query = "select id_column from table_config where id={}".format(tble_config_id)
					arridcolumn  = connectNativeArray(query)
					cprint(arridcolumn[0])
					idColumn = arridcolumn[0]


					query = "insert into "+arrtablename[0]+"("
					cprint(query)
					i=0
					values = "("
					for x in arrTableData:
						cprint(x)
						if x == idColumn:
							i = i+1
							continue
						if i<len(arrTableData)-1:
							query += ""+x+","
							values += getValueFromList(x, arrTableData[x])+","
						else:
							query += ""+x+""
							values += getValueFromList(x, arrTableData[x])
						i = i+1
					query += ")"
					values += ")"
					values = values.replace(",)",")")
					query = query.replace(",)",")")
					query += " values"+values
					# print (query)
					# print(arrTableData)
					cprint(query)
					connectFetchJSONWihtoutQueryData(query,resp)
			elif isRoute(route_path,"/gui_services/api/utblconfig"):
					cprint(route_path)
					data = json.loads(req.context['data'].decode('utf-8'))
					tble_config_id = data['tblid']
					arrTableData = data['tbldata']
					query = "select table_name from table_config where id={}".format(tble_config_id)
					arrtablename  = connectNativeArray(query)
					cprint(arrtablename[0])
					tblName = arrtablename[0]

					query = "select id_column from table_config where id={}".format(tble_config_id)
					arridcolumn  = connectNativeArray(query)
					cprint(arridcolumn[0])
					idColumn = arridcolumn[0]

					#query = "select column_name from INFORMATION_SCHEMA.COLUMNS where table_name ='{}'".format(tblarr[0][0])
					#arr  = connectNativeArray(query)
					#cprint(arr)
					query = "update "+tblName+" set "
					i=0
					whereCondition = " "
					values = ""
					for x in arrTableData:
						if (x == idColumn) or (x=="setpassword"):
							i = i+1
							continue
						if i<len(arrTableData)-1:
							query += " "+x+" = "+getValueFromList(x, arrTableData[x]) + ","
						else:
							query += " "+x+" = "+getValueFromList(x, arrTableData[x])
						i = i+1

					query += " where "+idColumn+" = "+str(arrTableData[idColumn])
					query = query.replace(", where"," where")
					# print(query);
					cprint(query)
					connectFetchJSONWihtoutQueryData(query,resp)
			else:
				resp.body=response_wrapper(404,[]) #json.dumps({'error':str(e)})
				resp.status=falcon.HTTP_404
		except Exception as e:
			resp.body=response_wrapper(500,str(e)) #json.dumps({'error':str(e)})
			resp.status=falcon.HTTP_500

def formStringOrInt(txt):
	try:
		value = int(txt)
		return str(value)
	except ValueError:
		return "'"+txt+"'"
		pass  # it was a string, not an int.
		
def getValueFromList(key, val):
	try:
		if(key=="password"):
			return "crypt("+formStringOrInt(val)+", gen_salt('bf'))";
		else:
			return formStringOrInt(val);
	except ValueError:
		return ""
		pass  # it was a string, not an int.

# get the ticket columns with table reference if required
def getTicketColumnKey(key):
	try:
		if(key=="ticketid"):
			key = "td.ticketid"
		elif(key=="status"):
			key = "sc.status"
		elif(key=="scope"):
			key = "ai.scope"
		elif (key == "ttcreatetime"):
			key = "td.ttcreatetime"
		else:
			key = "td."+key;
		return key;
	except Exception as err:
		print(err);
		return key;

def getAlarmColumnKey(key):
	try:
		if(key=="iactoken"):
			key = "aa.iactoken"
		elif(key=="status"):
			key = "s.status"
		elif(key=="eventtime"):
			key = "aa.eventtime"
		elif(key=="updatedtime"):
			key = "aa.updatedtime"
		elif (key == "iac_time"):
			key = "aa.iac_time"
		elif (key == "country"):
			key = "aa.additionalfields->'countryName'"
		return key;
	except Exception as err:
		print(err);
		return key;

# get the filter conditions required for get alarms
def getTicketFilterQueryCondition(filter):
	try:
		filter = json.loads(filter);
		condition = "";
		isAndReq = None;
		isCloseStatusRequested = False;
		for key, val in filter.items():
			if(isAndReq):
				condition += " and "
			isAndReq = True;
			if(key=='status' and val.lower()=='closed'):
				isCloseStatusRequested = True;
			key = getTicketColumnKey(key)
			# check if json parsing replace -> with ->> for where condition
			if (key.find('->') != -1):
				key = key.replace('->', '->>')
			# check time to change where condition
			if(key.find("time")!=-1):
				newVal = "to_char("+key+", 'DD-Mon-YYYY')"+" Ilike '%%"+val+"%%'"
				condition += newVal;
			elif(key=="td.acknowledge"):
				if(val.find("f")!=-1):
					val = 'false'
				else:
					val = 'true'
				condition += key + " = "+val
			else:
				condition += key+" Ilike '%%"+val+"%%'"
		if not (isCloseStatusRequested):
			if (isAndReq):
				condition += " and "
			condition += conditionRemoveClosedTickets();
		return condition;
	except Exception as err:
		print("error")
		print(err);
		return "";

# Filter all the closed tickets that are 30 min behind current time
def conditionRemoveClosedTickets():
	try:
		return " (lower(sc.status) is distinct from 'closed') or (lower(sc.status)='closed' and  (NOW() < (td.updatedtime + INTERVAL '30 min') or (td.updatedtime is null)) ) "
	except Exception as err:
		print(err);
		return "";

# Filter all the closed alarms that are 30 min behind current time
# TODO check on the filtering logic
def conditionRemoveClosedAlarms():
	try:
		return " ((lower(s.status) is distinct from 'closed' and lower(s.status) is distinct from 'resolved')" \
			   " or (lower(s.status)='closed' and  (NOW() < (aa.updatedtime + INTERVAL '15 days')" \
			   " or (aa.updatedtime is null)) ) or(lower(s.status)='resolved' and" \
			   " (NOW() < (aa.updatedtime + INTERVAL '15 days') or (aa.updatedtime is null)) ))"
	except Exception as err:
		print(err);
		return "";

def getAlarmListCondition(list):
	try:
		list = list.split('|')
		condition = ''
		for item in list:
			if(condition!=''):
				condition += " or "
			condition += (getAlarmColumnKey('iactoken')+"='"+item+"'")
		return condition
	except Exception as err:
		print("error")
		print(err);
		return "";


# get the filter conditions required for get alarms
def getAlarmFilterQueryCondition(filter):
	try:
		filter = json.loads(filter);
		condition = "";
		isAndReq = None;
		isCloseStatusRequested = False;
		for key, val in filter.items():
			if(isAndReq):
				condition += " and "
			isAndReq = True;
			if (key == 'status' and (val.lower() == 'closed' or val.lower() == 'resolved')):
				isCloseStatusRequested = True;
			key = getAlarmColumnKey(key)
			# check if json parsing replace -> with ->> for where condition
			if (key.find('->') != -1):
				key = key.replace('->', '->>')
			# check time to change where condition
			if(key.find("time")!=-1):
				newVal = "to_char("+key+", 'DD-Mon-YYYY')"+" Ilike '%%"+val+"%%'"
				condition += newVal;
			else:
				condition += key+" Ilike '%%"+val+"%%'"

		if not (isCloseStatusRequested):
			if (isAndReq):
				condition += " and "
			condition += conditionRemoveClosedAlarms();
		return condition;
	except Exception as err:
		print("error")
		print(err);
		return "";