import logging.handlers
from LoggingContextFilter import *

def init_logger(lgrname):
    print('Initializing logs')
    LOG_FILENAME = '/logs/'+ lgrname + '.log'

    logger = logging.getLogger(lgrname)
    scrnLgr = logging.StreamHandler()

    # Add the log message handler to the logger
    filehandler = logging.handlers.RotatingFileHandler(
        LOG_FILENAME, maxBytes=2147483648, backupCount=5)

    formatter = logging.Formatter(
        '%(asctime)s.%(msecs)03d | %(levelname)s | %(thread)d |  %(iacToken)-15s | %(filename)s | %(funcName)s |%(message)s',
        "%d-%b-%Y %H:%M:%S")
    formatter.default_msec_format = '%s.%03d'
    scrnLgr.setFormatter(formatter)
    filehandler.setFormatter(formatter)

    logger.setLevel(logging.DEBUG)
    logging.basicConfig(handlers={scrnLgr, filehandler})
    f = LoggingContextFilter()
    logger.addFilter(f)
    return logger


logger = init_logger('iac_orchestration')
logger.info("Logger module initialized");

