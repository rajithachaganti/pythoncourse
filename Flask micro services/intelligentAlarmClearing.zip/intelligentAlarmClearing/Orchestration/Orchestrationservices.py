import json
import time
import traceback
from concurrent.futures import ThreadPoolExecutor

import falcon
from prometheus_client import multiprocess
from prometheus_client import generate_latest, CollectorRegistry, CONTENT_TYPE_LATEST, Gauge

from Modules.Commons import *
from Modules.alarmhandler import AlarmHandler
from Modules.businessrulehandler import BusinessRuleHandler
from Modules.jsonvalidator import JSONValidator
from Modules.mmlhandler import MmlHandler
from Modules.EmailHandler import EmailHandler

orch_worker_pool = ThreadPoolExecutor(max_workers=3)


class Orchestrationservices(object):
    def __init__(self):
        self.mmlhandler=MmlHandler()
        self.jsonhandler=JSONValidator()
        self.alarmhandler=AlarmHandler()
    def on_get(self, req, resp, **kwargs):
        route_path = str(req.path)
        print('-----')
        if isRoute(route_path,"/orch/api/metrics"):
            data=generate_latest()
            resp.body = data
            resp.status = falcon.HTTP_200
            resp.content_type=CONTENT_TYPE_LATEST
        elif isRoute(route_path, "/orch/api/heartbeat"):
            resp.body = json.dumps({"status": "Alive"})
            resp.status = falcon.HTTP_200
            
    def on_post(self, req, resp, **kwargs):
        try:
            raw_data = req.context["data"].decode('utf-8').encode('ascii', 'ignore')
            # .encode('ascii', 'ignore')
            if not isinstance(raw_data, dict):
                json_data = json.loads(raw_data)
            else:
                json_data = raw_data
            route_path = str(req.path)
            #settings.logger.info(json_data)
            settings.logger.debug(json_data['mobileno'])
            print("----Data----",json_data)
            if isRoute(route_path, "/orch/api/processalarms"):

                settings.logger.debug("Entering in processalarm -------------------------")
                jsonresp, alarms = self.jsonhandler.validate_alarm(json_data)

                # for index in range(len(alarms)):
                #     orch_worker_pool.submit(self.mmlhandler.process_alarms, alarms.iloc[index:(index+1)])
                orch_worker_pool.submit(self.mmlhandler.process_alarms, alarms)
                resp.status = falcon.HTTP_200
                resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
                settings.logger.debug("Exiting from processalarm ------------------------")
            elif isRoute(route_path, "/orch/api/heartbeat"):
                resp.body = json.dumps({"status": "Alive"})
                resp.status = falcon.HTTP_200
            elif isRoute(route_path, "/orch/api/processmml"):
                settings.logger.debug("Entering in processmml -------------------------")
                orch_worker_pool.submit(self.mmlhandler.process_mml_from_ps, json_data)
                resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting from processmml ------------------------")

            elif isRoute(route_path, "/orch/api/processmmloutput"):
                settings.logger.debug("Entering in processmmloutput -------------------------")
                # orch_worker_pool.submit(self.mmlhandler.process_mmloutput, json_data)
                orch_worker_pool.submit(self.mmlhandler.process_mmloutput_from_rpa, json_data)
                resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting from processmmloutput ------------------------")
            elif isRoute(route_path, "/orch/api/movetomanual"):
                settings.logger.debug("Entering in movetomanual -------------------------")
                # orch_worker_pool.submit(self.mmlhandler.process_mmloutput, json_data)
                orch_worker_pool.submit(self.mmlhandler.update_alarmstatus, json_data["iactoken"],"Manual")
                resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting from movetomanual ------------------------")
            elif isRoute(route_path, "/orch/api/changemode"):
                settings.logger.debug("Entering in changemode -------------------------")
                # orch_worker_pool.submit(self.mmlhandler.process_mmloutput, json_data)
                orch_worker_pool.submit(self.mmlhandler.change_executionmode, json_data)
                resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting from changemode ------------------------")
            elif isRoute(route_path, "/orch/api/pric"):
                settings.logger.debug("Entering in updatemml -------------------------")
                token = req.get_header('token')
                query = "select username as uname from token where token='" + token + "'"
                uname = connectNativeArray(query)
                orch_worker_pool.submit(self.mmlhandler.process_mml_from_gui, json_data, uname[0])

                resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting from updatemml ------------------------")
            elif isRoute(route_path, "/orch/api/closeticket"):
                settings.logger.debug("Entering in Close Ticket ------------------------")
                orch_worker_pool.submit(self.mmlhandler.close_ticket, json_data)

                resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting in Close Ticket ------------------------")
            elif isRoute(route_path, "/orch/api/closeticketoutput"):
                settings.logger.debug("Entering in closeticketoutput -------------------------")
                orch_worker_pool.submit(self.mmlhandler.close_ticket_response, json_data)
                resp.body = json.dumps({"iacstatus": "Success"})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting from closeticketoutput ------------------------")
            elif isRoute(route_path, "/orch/api/attachlog"):
                settings.logger.debug("Entering in Attach log ------------------------")
                orch_worker_pool.submit(self.mmlhandler.attach_log_ticket, json_data)

                resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting in Attach Log ------------------------")
            elif isRoute(route_path, "/orch/api/attachlogoutput"):
                settings.logger.debug("Entering in attachlogoutput -------------------------")
                orch_worker_pool.submit(self.mmlhandler.attach_log_ticket_response, json_data)
                resp.body = json.dumps({"iacstatus": "Success"})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting from Attach Log ------------------------")
            elif isRoute(route_path, "/orch/api/getalarm"):
                settings.logger.debug("Entering in getalarm -------------------------")
                resp.body = json.dumps(self.alarmhandler.generate_alarmjson2(json_data["iactoken"]))
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting from getalarm ------------------------")
            elif isRoute(route_path, "/orch/api/deleteall"):
                settings.logger.debug("Entering in deleteall ------------------------")
                deleteall()
                resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting from deleteall ------------------------")
            elif isRoute(route_path, "/orch/api/updatekm"):
                settings.logger.debug("Entering in updatekm -------------------------")
                orch_worker_pool.submit(self.mmlhandler.update_km, json_data)
                resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting from updatekm ------------------------")
            elif isRoute(route_path, "/orch/api/testjson"):
                settings.logger.debug("Entering in testjson ------------------------")
                ss = BusinessRuleHandler().coorelate_alarm(json_data["data"])
                resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting from testjson ------------------------")
            elif isRoute(route_path, "/orch/api/dummy"):
                settings.logger.debug("Entering in dummy ------------------------")
                resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting from dummy ------------------------")
            elif isRoute(route_path, "/orch/api/dummytoken"):
                settings.logger.debug("Entering in token ------------------------")
                resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting from testjson ------------------------")
            elif isRoute(route_path, "/orch/api/km_response"):
                settings.logger.debug("Entering in km_response ------------------------")
                orch_worker_pool.submit(self.mmlhandler.process_km_response, json_data)
                resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting from km_response ------------------------")
            # elif isRoute(route_path, "/orch/api/attachlog"):
            #     settings.logger.debug("Entering in Attach log ------------------------")
            #     orch_worker_pool.submit(self.mmlhandler.process_mml_from_gui, json_data)
            #     resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
            #     resp.status = falcon.HTTP_200
            #     settings.logger.debug("Exiting in Attach log ------------------------")
            elif isRoute(route_path, "/orch/api/closealarm"):
                settings.logger.debug("Entering in Close Alarm ------------------------")
                orch_worker_pool.submit(self.mmlhandler.process_mml_from_gui, json_data)
                resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting in Close Alarm ------------------------")
            elif isRoute(route_path, "/orch/api/ticketacknowledged"):
                settings.logger.debug("Entering in Ticket acknowledged ------------------------")
                orch_worker_pool.submit(self.mmlhandler.process_ticketacknowledge, json_data)
                resp.body = json.dumps({"iacstatus": "Success", "iacerrordetails": ""})
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting in Ticket acknowledged ------------------------")
            elif isRoute(route_path, "/orch/api/sendmail"):
                settings.logger.debug("Entering the Mail Sender ------------------------")
                testmail = EmailHandler()
                resp.body = testmail.send_mail(json_data)
                resp.status = falcon.HTTP_200
                settings.logger.debug("Exiting the Mail Sender ------------------------")
            else:
                settings.logger.debug("Entering in unknown ------------------------")
                resp.body = json.dumps({"iacstatus": "Failed", "iacerrordetails": "Page not found"})
                resp.status = falcon.HTTP_404
                settings.logger.debug("Exiting from unknown ------------------------")
        except BaseException as e:
            settings.logger.error(f"Exception {e} while processing the packet {traceback.format_exc()}")
            resp.body = json.dumps({"iacstatus": "Failed", "iacerrordetails": str(e)})  # json.dumps({'error':str(e)})
            resp.status = falcon.HTTP_500

