ALARM_ADD_EMAIL_SUBJECT='New alarms added to iAC - {}'
ALARM_ADD_EMAIL_BODY='<b>Following alarms are added to iAC</b><br /><br />{}'
PERFORMANCE_REPORT_EMAIL_SUBJECT='iAC Performance report - {}'
PERFORMANCE_REPORT_EMAIL_BODY='Hi,<br/> Performance report for the date {} is attached.<br/><br/> -iAC'