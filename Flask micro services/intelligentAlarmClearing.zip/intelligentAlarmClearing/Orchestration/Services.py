from Modules.Imports import *

# PostgreSQL DB Settings
# common.database="iac"
# common.user="postgres"
# common.password="postgres"
# common.host="93.183.28.198"
# common.port="5432"

# BASE_PATH = "gui_services"	#It will route /gui_services/....

# GET Method Calls -> Common
# Format ==> {"PATH" : "Query String"}
GET_JSON = {
    # "/gui_services/get_alarms":"select ROW_NUMBER () OVER (ORDER BY scope) as sid,aa.iactoken,'' as eddel,customer,nodevendor,nodetype,nodeversion,alarmnumber,alarmname,nodeid,nodename,nodeparent,to_char(eventtime,'DD-Mon-YYYY HH24:MI:SS') as eventtime,to_char(iac_time,'DD-Mon-YYYY HH24:MI:SS') as iac_time,scope,status,parentalarm,ticketid,iacalarmid,bb.mmlcommand as mml,'' as acknowledge from alarminfo aa left join (SELECT alarmcycle.iactoken,(case when alarmcycle.mmlcommand is null then '' else alarmcycle.mmlcommand end) as mmlcommand,alarmcycle.tasktime FROM (SELECT iactoken, MAX(tasktime) AS tasktime FROM alarmcycle GROUP BY iactoken) AS latest_orders INNER JOIN alarmcycle ON alarmcycle.iactoken = latest_orders.iactoken AND alarmcycle.tasktime = latest_orders.tasktime) bb on aa.iactoken=bb.iactoken where eventtime > NOW() - INTERVAL '25 days'",
    "/gui_services/get_alarms": "select ROW_NUMBER () OVER (ORDER BY scope) as sid,aa.iactoken,'' as eddel,customer,nodevendor,nodetype,nodegroup, nodeversion,alarmnumber,alarmname,nodeid,nodename,nodeparent,to_char(updatedtime,'DD-Mon-YYYY HH24:MI:SS') as updatedtime, to_char(eventtime,'DD-Mon-YYYY HH24:MI:SS') as eventtime,to_char(iac_time,'DD-Mon-YYYY HH24:MI:SS') as iac_time,scope,s.status,parentalarm,ticketid,iacalarmid,bb.mmlcommand as mml,bb.parentid,'' as acknowledge,executionmode,updatedtime::text from alarminfo aa left join (SELECT alarmcycle.iactoken,(case when alarmcycle.mmlcommand is null then '' else alarmcycle.mmlcommand end) as mmlcommand,alarmcycle.id as parentid,alarmcycle.tasktime FROM (SELECT iactoken, MAX(tasktime) AS tasktime FROM alarmcycle GROUP BY iactoken) AS latest_orders INNER JOIN alarmcycle ON alarmcycle.iactoken = latest_orders.iactoken AND alarmcycle.tasktime = latest_orders.tasktime) bb on aa.iactoken=bb.iactoken left join statuscodes s on aa.status=s.status_id order by aa.iac_time desc",
    "/gui_services/get_piechart": "select scope as name,count(scope) as value from alarminfo group by scope",
    "/gui_services/get_piechart_status": "select (case when status is null then 'Empty' else status end) as name,count(case when status is null then 'Empty' else status end) as y from alarminfo group by status",
    # "/gui_services/alarms_filter_view":"select filtername as fname from alarmfilter where username='Siva'",
    # "/gui_services/get_tickets":"select aaa.ticketid,ttseverity,ttcountry,ttcreatetime::text,tttitle,iactttime::text,bbb.scope,bbb.status from ticketdetails aaa left join (select a.ticketid,array_agg(distinct b.scope)as scope,array_agg(distinct b.status) as status from (select ticketid from ticketdetails) a left join alarminfo b on a.ticketid=b.ticketid group by a.ticketid) bbb on aaa.ticketid=bbb.ticketid",
    # "/gui_services/get_tickets":"select aaa.ticketid,ttseverity,ttcountry,ttcreatetime::text,tttitle,iactttime::text,bbb.scope,status from ticketdetails aaa left join (select a.ticketid,array_agg(distinct b.scope)as scope,array_agg(distinct b.bstatus) as status from (select ticketid from ticketdetails) a left join (select *,s.status as bstatus from alarminfo tt left join statuscodes s on tt.status=s.status_id) b on a.ticketid=b.ticketid group by a.ticketid) bbb on aaa.ticketid=bbb.ticketid",
    "/gui_services/get_tickets": "select aaa.ticketid,ttseverity,ttcountry,ttcreatetime::text,tttitle,iactttime::text,bbb.scope,bbb.status, acknowledge, to_char(acktime,'DD-Mon-YYYY HH24:MI:SS') as acktime from ticketdetails aaa left join (select a.ticketid,array_agg(distinct b.scope)as scope,array_agg(distinct b.bstatus) as status from (select ticketid from ticketdetails) a left join (select *,s.status as bstatus from alarminfo tt left join statuscodes s on tt.status=s.status_id) b on a.ticketid=b.ticketid group by a.ticketid) bbb on aaa.ticketid=bbb.ticketid order by iactttime desc",
    "/gui_services/tickets": "select ticketid from ticketdetails",
    "/gui_services/mmlcommands": "select commanddictionary from alarmkeycolumns where alarmnumber='7767'",
    "/gui_services/resstatus": "select resolutioncode as code,resolutionstatus as value from resolutioncodes",
    "/gui_services/gconfigs": "select id,name from table_config",
    "/gui_services/report_alarminfo": "select ai.iactoken, ai.customer, ai.alarmnumber, ai.alarmname, json_agg(ac.mmlcommand) as mmlcommand, json_agg(ac.additionalinfo) as additionalInfo  from alarminfo ai left join alarmcycle ac on ai.iactoken=ac.iactoken where ai.scope='In' group by ai.iactoken order by ai.eventtime",
    "/gui_services/alarmtrendbydate": "select alarmname, json_agg(alrmdt) as date, json_agg(alrm_cnt) as count from alarmtrendbynameanddate group by alarmname"
}

# POST Method Calls -> Common
# Format ==> {"PATH" : ["Query String",["param1","param2"]]}
POST_JSON = {
    "/gui_services/get_alarmDetails": ["select ROW_NUMBER () OVER (ORDER BY tasktime::text) as sid,iactoken,t.taskname as tasktype,tasktime::text,mmlcommand, commandname, id, message, resolutionsummary, username, a.rsname, rs.rsformat, additionalinfo,mmloutput, rc.resolutioncode, rc.resolutionstatus from alarmcycle a left join tasktypes t on a.tasktype::int=t.taskid left join resolutioncodes rc on a.resolutioncode::int=rc.resolutioncode left join resolutionsummary rs on a.rsname=rs.rsname where iactoken=%s order by tasktime", ["alarmid"]],
    "/gui_services/alarms_filter": ["insert into alarmfilter (username,jsonvalue,modifiedtime,filtername) values(%s,%s,%s,%s);", ["uname", "jvalue", "now", "fname"]],
    "/gui_services/alarms_filter_det": ["select jsonvalue as jvalue from alarmfilter where username=%s and filtername=%s", ["uname", "fname"]],
    "/gui_services/mmlcommands": ["select commandformat, commandname, displayname from alarmcommandruledetails where alarmname in (select alarmname from alarmkeycolumns where iacalarmid=%s)", ["alarmid"]],
    "/gui_services/rs_list": ["select rsname, rsformat, displayname from resolutionsummary where rsid in (select rsid from alarmrsmapping where iacalarmid=%s)", ["alarmid"]],
    "/gui_services/tthandlingreport": ["select * from tthandlingreport(%s)", ["duration"]],
    "/gui_services/performancereport": ["select * from getPerformanceReport(%s) order by report_date::timestamp desc, nodegroup asc", ["duration"]]
}

# If Any Logical Services handled in => Logicservices.py

JSON_VALLIDATION = {
    "/gui_services/api/testing3": ['folder_name', 'test2'],
    "/orch/api/testing3": [],
    "/orch/api/processalarms": [],
    # "/orch/api/processalarms_internal":[],
    "/orch/api/processmml": [],
    # "/orch/api/processmml_internal":[],
    "/orch/api/processmmloutput": [],
    # "/orch/api/processmmloutput_internal":[],
    "/orch/api/updatemml": [],
    # "/orch/api/updatemml_internal":[],
    "/orch/api/updatekm": []
}

# This MAPPING is used for SKIP Token for particular Services
SKIP_TOKEN = {
    "/gui_services/ctoken": "",
    "/orch/api/metrics": "",
    "/gui_services/api/get_alarms": "",
    "/gui_services/api/get_alarmDetails": "",
    "/orch/api/heartbeat": ""
}
CREATE_USER = "/gui_services/cuser"
CREATE_AUTH = "/gui_services/cauth"
