import threading
import time
import socket
import traceback
import sys, os
sys.path.append(os.path.abspath(os.path.join('..', 'config')))

import settings
import requests
# from Modules.mmlhandler import MmlHandler
import psycopg2 as p
from Modules.Utilities import DB_Handler

from concurrent.futures import ThreadPoolExecutor

orch_worker_pool = ThreadPoolExecutor(max_workers=2)


# from Modules.Commons import *


class ThreadingExample(object):
    def __init__(self, interval=10):
        self.connection = self.getConnection()
        self.interval = interval
        self.ipaddress = socket.gethostbyname(socket.gethostname())
        # print(self.ipaddress)
        self.listofalarms = ["asfd", "asdfasf"]
        self.dbhandler= DB_Handler()
        # thread = threading.Thread(target=self.run, args=())
        # thread.daemon = True  # Daemonize thread
        # thread.start()  # Start the execution
        # self.connection = getConnection()

    def getConnection(self):
        # print("Getting DB connection")
        try:
            return p.connect("dbname='" + settings.DATABASE_CONFIG["DATABASE"] + "' user='" + settings.DATABASE_CONFIG["USERNAME"] + "' password='" + settings.DATABASE_CONFIG["PASSWORD"] + "' host='" + settings.DATABASE_CONFIG["HOST"] + "' port='" + settings.DATABASE_CONFIG["PORT"] + "'")
        except BaseException as e:
            traceback.print_exc()

    def run(self):
        # while True:
        #     i = 1
        #     if i == 1:
        try:

            with self.connection:
                with self.connection.cursor() as cur:

                    cur.execute("select id,mmlcommand,iactoken,iactime,executiontime,commandname,parentid from waitingcommands where ipaddress='{}' and status=1 and executiontime < now()".format(self.ipaddress))
                    # print("select id,mmlcommand,iactoken,iactime,executiontime,commandname,parentid from waitingcommands where ipaddress='{}' and status=1 and executiontime < now()".format(self.ipaddress))
                    res = cur.fetchall()
                    if len(res) != 0:
                        # print(res)
                        settings.logger.info(f'Sending {len(res)} commands to RPA...', self.listofalarms)
                        for row in res:
                            orch_worker_pool.submit(self.execute_mml_to_rpa, iactoken=row[2], parentid=row[6], resolutioncode="0", mmlcommand=row[1], commandname=row[5],rowid=row[0])
                        settings.logger.info("Executed RPA from command reattempt")

        except BaseException as e:
            traceback.print_exc()
            settings.logger.error(f"Error while inserting traceback:{traceback.format_exc()}")
            # time.sleep(self.interval)

    def update_commandstatus(self, iactoken=None, status=None, message=None,rowid=None):
        try:
            with self.connection:
                with self.connection.cursor() as cur:
                    if message is None:
                        message = ''
                    cur.execute("update waitingcommands set status= {},message='{}',updatedtime=now() where id={}".format(self.dbhandler.get_statuscode(status=status), message, rowid))
                    settings.logger.info(f"Updated iactoken:{iactoken} status:{status} traceback: {traceback.format_exc()}")
                    return True
        except BaseException as e:
            traceback.print_exc()
            self.dbhandler.insert_alarmcycle(iactoken=iactoken, tasktype="Error", message="Error while updating waiting command, " + str(e))
            settings.logger.error(f"Error while updating command status for iactoken:{iactoken} status:{status} traceback: {traceback.format_exc()}")
            return False
    def execute_mml_to_rpa(self, iactoken=None, parentid=None, resolutioncode=None, resolutionsummary=None, mmlcommand=None, commandname=None, rsname=None,rowid=None):
        try:
            mmlexcid = self.dbhandler.insert_alarmcycle(iactoken=iactoken, tasktype="MML to Execution", resolutioncode=resolutioncode, resolutionsummary=resolutionsummary, parentid=parentid, mmlcommand=mmlcommand, commandname=commandname, rsname=rsname)
            jsoninput = {"robotuid": iactoken, "mmlcommandID": mmlexcid, "mmlcommand": mmlcommand, "resolutioncode": resolutioncode, "resolutionsummary": resolutionsummary}
            jsonid = self.dbhandler.insert_json(jsoninput)
            with self.connection as conn:
                with conn.cursor() as cur:
                    cur.execute("update alarmcycle set inputreceived=%s where id=%s",(jsonid, mmlexcid))
                    conn.commit()
                    try:
                        r = requests.post(settings.RPA_MML_URL, headers={"Authorization": settings.RPA_TOKEN, "Content-type": "application/json"}, json=jsoninput, proxies=settings.NO_PROXY)
                        if r.status_code == 401:
                            s = settings.refresh_rpa_token()
                            if s:
                                r = requests.post(settings.RPA_MML_URL, headers={"Authorization": settings.RPA_TOKEN, "Content-type": "application/json"}, json=jsoninput, proxies=settings.NO_PROXY)
                                if r.status_code == 200:
                                    self.dbhandler.update_message(message="Sending to RPA success", cycleid=mmlexcid)
                                    self.update_commandstatus(iactoken=iactoken,status="Closed",message="Success",rowid=rowid)
                                elif r.status_code == 401:
                                    self.dbhandler.insert_alarmcycle(iactoken, tasktype="Error", parentid=mmlexcid, resolutioncode=resolutioncode, inputreceived=jsonid, resolutionsummary=resolutionsummary, mmlcommand=mmlcommand, commandname=commandname, message="Failed to connect RPA while Token refresh")
                                    self.dbhandler.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")
                                    self.update_commandstatus(iactoken=iactoken,status="Closed",message="Failed",rowid=rowid)
                                else:
                                    self.dbhandler.insert_alarmcycle(iactoken, tasktype="Error", parentid=mmlexcid, resolutioncode=resolutioncode, inputreceived=jsonid, resolutionsummary=resolutionsummary, mmlcommand=mmlcommand, commandname=commandname, message="Failed to send MML to RPA")
                                    self.dbhandler.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")
                                    self.update_commandstatus(iactoken=iactoken,status="Closed",message="Failed",rowid=rowid)
                            else:
                                self.dbhandler.insert_alarmcycle(iactoken, tasktype="Error", parentid=mmlexcid, resolutioncode=resolutioncode, inputreceived=jsonid, resolutionsummary=resolutionsummary, mmlcommand=mmlcommand, commandname=commandname, message="Failed to connect RPA while Token refresh")
                                self.dbhandler.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")
                                self.update_commandstatus(iactoken=iactoken, status="Closed", message="Failed", rowid=rowid)

                        elif r.status_code == 200:
                            self.dbhandler.update_message(message="Sending to RPA success", cycleid=mmlexcid)
                            self.update_commandstatus(iactoken=iactoken,status="Closed",message="Success",rowid=rowid)
                        else:
                            self.dbhandler.insert_alarmcycle(iactoken, tasktype="Error", parentid=mmlexcid, resolutioncode=resolutioncode, inputreceived=jsonid, resolutionsummary=resolutionsummary, mmlcommand=mmlcommand, commandname=commandname, message="Failed to send MML to RPA")
                            self.dbhandler.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")
                            self.update_commandstatus(iactoken=iactoken,status="Closed",message="Failed",rowid=rowid)
                    except requests.exceptions.RequestException as e:
                        self.dbhandler.insert_alarmcycle(iactoken, tasktype="Error", parentid=mmlexcid, resolutioncode=resolutioncode, inputreceived=jsonid, resolutionsummary=resolutionsummary, mmlcommand=mmlcommand, commandname=commandname, message="Failed to send MML to RPA")
                        self.dbhandler.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")
                        self.update_commandstatus(iactoken=iactoken,status="Closed",message="Failed",rowid=rowid)

        except BaseException as e:
            traceback.print_exc()
            if iactoken is not None:
                self.dbhandler.insert_alarmcycle(iactoken, tasktype="Error", inputreceived=self.insert_json(jsoninput={"errordetails": traceback.format_exc()}), message="Error while sending mml to RPA, " + str(e))
                self.dbhandler.update_alarmstatus(iactoken=iactoken, status="Manual-Fail")



if __name__ == '__main__':
    try:
        print("Waiting command process running.... ")
        while True:
            testrun=ThreadingExample(interval=10)
            testrun.run()
            time.sleep(10)
    except KeyboardInterrupt:
        print('Orchestration thread module shutting down.')
        try:
            sys.exit(0)
        except SystemExit:
            os._exit(0)
    # exam.listofalarms.append("asdfasfasfdasfsafsaf")
